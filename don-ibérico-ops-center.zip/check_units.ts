import 'dotenv/config';
import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function run() {
  try {
    await sql.connect(dbConfig);
    const result = await sql.query`
      SELECT TOP 5 Unidades, Unidades2_, CodigoArticulo
      FROM MovimientoStock 
      WHERE OrigenMovimiento = 'F'
    `;
    console.log(result.recordset);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();
