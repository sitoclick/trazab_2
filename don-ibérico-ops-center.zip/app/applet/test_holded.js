const fs = require('fs');
async function test() {
  const res = await fetch('http://localhost:3000/api/holded/invoices?paid=all&starttmp=1704067200&endtmp=1735689599');
  const data = await res.json();
  console.log(JSON.stringify(data.slice(0, 2).map(i => ({ id: i.id, salesChannel: i.salesChannel, customFields: i.customFields })), null, 2));
}
test();
