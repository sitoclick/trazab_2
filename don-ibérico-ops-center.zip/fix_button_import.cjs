const fs = require('fs');

let content = fs.readFileSync('src/components/Sales.tsx', 'utf8');
content = content.replace("import { Button } from './ui/button';", "import { Button } from './Button';");
fs.writeFileSync('src/components/Sales.tsx', content);
console.log('Fixed Button import in Sales.tsx');
