import { deleteReglaComisionQuery } from './sqlQueries';
import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER || '',
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function testDeleteRule() {
  try {
    await sql.connect(config);
    await deleteReglaComisionQuery(9);
    console.log('Deleted successfully');
  } catch (e) {
    console.log('Error:', e.message);
  } finally {
    process.exit(0);
  }
}

testDeleteRule();
