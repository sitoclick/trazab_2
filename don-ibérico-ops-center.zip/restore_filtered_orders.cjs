const fs = require('fs');

let content = fs.readFileSync('App.tsx', 'utf8');

const filteredOrdersCode = `
  const filteredOrders = useMemo(() => {
    return pendingOrders.filter(order => {
      const matchContact = (order.RazonSocial || '').toLowerCase().includes(pendingOrdersFilters.contactName.toLowerCase());
      const matchDoc = (order.NumeroPedido?.toString() || '').toLowerCase().includes(pendingOrdersFilters.docNumber.toLowerCase());
      return matchContact && matchDoc;
    });
  }, [pendingOrders, pendingOrdersFilters]);
`;

const insertIdx = content.indexOf("  const handleSort = (key: string) => {");
if (insertIdx !== -1) {
  content = content.substring(0, insertIdx) + filteredOrdersCode + "\n" + content.substring(insertIdx);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully restored filteredOrders');
} else {
  console.log('Could not find insertion point');
}
