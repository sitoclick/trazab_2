import { execSync } from 'child_process';

try {
  const log = execSync('git log -p -10 src/App.tsx').toString();
  const match = log.match(/const initialCommissionRules = \[([\s\S]*?)\];/);
  if (match) {
    console.log(match[0]);
  } else {
    console.log("Not found in last 10 commits");
  }
} catch (e) {
  console.log(e.message);
}
