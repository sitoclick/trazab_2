import { createReglaComisionQuery } from './sqlQueries';
import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER || '',
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function testCreateRule() {
  try {
    await sql.connect(config);
    const result = await createReglaComisionQuery(1, 'jamon', 'pieza', 10, '', '', 'Test rule', undefined, undefined);
    console.log('Result:', result.recordset);
  } catch (e) {
    console.log('Error:', e.message);
  } finally {
    process.exit(0);
  }
}

testCreateRule();
