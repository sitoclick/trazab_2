const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const startStr = "    if (activeTab === 'maestros') {";
const endStr = "    } else if (activeTab === 'sales') {";
const startIdx = content.indexOf(startStr);
const endIdx = content.indexOf(endStr);

if (startIdx !== -1 && endIdx !== -1) {
  content = content.substring(0, startIdx) + "    if (activeTab === 'sales') {\n" + content.substring(endIdx + endStr.length);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully removed maestros block in useEffect');
} else {
  console.log('Could not find maestros block in useEffect');
}
