const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const stateToAdd = `
  // Restored States
  const [holdedProducts, setHoldedProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [uniqueCategoria2, setUniqueCategoria2] = useState<string[]>([]);
  const [uniqueFormato, setUniqueFormato] = useState<string[]>([]);
  const [holdedContacts, setHoldedContacts] = useState<any[]>([]);
  const [salesSubTab, setSalesSubTab] = useState<'pending' | 'overdue' | 'paid' | 'all'>('pending');
  const [holdedPaidInvoices, setHoldedPaidInvoices] = useState<any[]>([]);
  const [holdedUnpaidInvoices, setHoldedUnpaidInvoices] = useState<any[]>([]);
  const [unpaidInvoicesFilters, setUnpaidInvoicesFilters] = useState({
    contactName: '',
    agentName: '',
    docNumber: ''
  });
  const [salesSort, setSalesSort] = useState<{field: string, direction: 'asc' | 'desc'}>({field: 'dueDate', direction: 'asc'});
  const [salesDateRange, setSalesDateRange] = useState({ start: '', end: '' });
  const [maestrosSubTab, setMaestrosSubTab] = useState<'products' | 'clients'>('products');
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [isProductDetailLoading, setIsProductDetailLoading] = useState(false);

  const handleLoadHoldedContacts = async () => {
    try {
      const response = await fetch('/api/holded/contacts');
      if (response.ok) {
        const data = await response.json();
        setHoldedContacts(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error("Load Holded Contacts Error:", error);
    }
  };
`;

const insertIdx = content.indexOf("  // Tarifas State");
if (insertIdx !== -1) {
  content = content.substring(0, insertIdx) + stateToAdd + "\n" + content.substring(insertIdx);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully restored states');
} else {
  console.log('Could not find insertion point');
}
