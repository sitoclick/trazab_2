import 'dotenv/config';

async function run() {
  try {
    const res = await fetch('http://localhost:3000/api/orders/pending?sent=false&year=2026');
    const data = await res.json();
    console.log(Array.isArray(data) ? `Got ${data.length} orders` : data);
  } catch (err) {
    console.error(err);
  }
}

run();
