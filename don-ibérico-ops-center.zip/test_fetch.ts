const url = 'https://script.google.com/macros/s/AKfycbwN3Kg93Tadoi9x7K4FJbjsEudbCuMhipBMUe1bUDokQyDdlVVjCGcpHgyDegY3QF_-4A/exec?accion=sync';
fetch(url)
  .then(res => res.text())
  .then(text => console.log("Response:", text))
  .catch(err => console.error("Error:", err));
