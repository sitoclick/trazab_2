const fs = require('fs');

const appFile = fs.readFileSync('App.tsx', 'utf-8');

// We will extract the Traceability logic.
// Since it's complex to parse, I will just copy the relevant parts manually into a new file using string replacements.

let newTraceability = `import React, { useState, useMemo } from 'react';
import { 
  RefreshCw, Send, Package, CheckCircle2, AlertCircle, Loader2, ArrowUp, ArrowDown, ArrowUpDown, Eye, ChevronDown, ChevronRight, Printer, Lock, RotateCcw, Unlock, Database, Search, FileText, Download, Table as TableIcon
} from 'lucide-react';
import { Button } from '../Button';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { CALICER_LOGO, FIRMA_LOGO } from '../../assets/images';

interface TraceabilityProps {
  user: any;
  setConfirmDialog: any;
}

export default function Traceability({ user, setConfirmDialog }: TraceabilityProps) {
`;

// Extract states from line 281 to 469
const lines = appFile.split('\n');
const states1 = lines.slice(280, 469).join('\n');
const states2 = lines.slice(1331, 1334).join('\n'); // simpleQueryData
const asiciClients = lines.slice(1335, 1340).join('\n'); // ASICI_CLIENTS
const handlers = lines.slice(1341, 2225).join('\n'); // handleRunPesadasQuery to handleReopenOrder

newTraceability += states1 + '\n' + states2 + '\n' + asiciClients + '\n' + handlers + '\n';

// Extract JSX
const jsxStart = lines.findIndex(l => l.includes('{/* Traceability View */}'));
const jsxEnd = lines.findIndex(l => l.includes('{activeTab === \'agents\' && ('));

let jsx = lines.slice(jsxStart + 1, jsxEnd - 1).join('\n');
// Remove the outer condition `{activeTab === 'traceability' && user?.role !== 'Ventas' && (`
jsx = jsx.replace(/{activeTab === 'traceability' && user\?\.role !== 'Ventas' && \(/, '');
// Remove the last `)}`
jsx = jsx.substring(0, jsx.lastIndexOf(')}'));

newTraceability += `  return (\n    ${jsx}\n  );\n}\n`;

fs.writeFileSync('src/components/Traceability/Traceability.tsx', newTraceability);

// Now remove the extracted parts from App.tsx
let newApp = appFile.replace(states1 + '\n', '');
newApp = newApp.replace(states2 + '\n', '');
newApp = newApp.replace(asiciClients + '\n', '');
newApp = newApp.replace(handlers + '\n', '');

const oldJsx = lines.slice(jsxStart, jsxEnd).join('\n');
const newJsx = `        {/* Traceability View */}
        {activeTab === 'traceability' && user?.role !== 'Ventas' && (
          <Traceability user={user} setConfirmDialog={setConfirmDialog} />
        )}`;

newApp = newApp.replace(oldJsx, newJsx);

// Add import
newApp = newApp.replace(`import PedidosOnline from './components/PedidosOnline/PedidosOnline';`, `import PedidosOnline from './components/PedidosOnline/PedidosOnline';\nimport Traceability from './components/Traceability/Traceability';`);

fs.writeFileSync('App.tsx', newApp);
console.log('Done');
