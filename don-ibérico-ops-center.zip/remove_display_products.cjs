const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const startStr = "const handleViewProductDetail = async (productId: string) => {";
const endStr = "const getAgentForInvoice = (inv: any) => {";
const startIdx = content.indexOf(startStr);
const endIdx = content.indexOf(endStr);

if (startIdx !== -1 && endIdx !== -1) {
  content = content.substring(0, startIdx) + content.substring(endIdx);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully removed displayProducts and handleViewProductDetail');
} else {
  console.log('Could not find displayProducts block');
}
