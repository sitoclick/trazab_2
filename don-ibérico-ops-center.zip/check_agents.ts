import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER || '',
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function checkAgents() {
  try {
    await sql.connect(config);
    const res = await sql.query`SELECT * FROM Agentes`;
    console.log('Agentes:', res.recordset);
  } catch (e) {
    console.log('Error:', e.message);
  } finally {
    process.exit(0);
  }
}

checkAgents();
