import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER || 'holded',
  password: process.env.DB_PASSWORD || 'erp1234',
  server: process.env.DB_SERVER || 'sitoclick.ddns.net',
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE || 'CARNICAS',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 30000,
  },
};

const prices = [
  { sku: 'P-JAM-BE-100-PASS', price: 40.90 }, 
  { sku: 'P-JAM-BE-100_', price: 39.90 }, 
  { sku: 'P-JAM-BE-PASS', price: 37.50 }, 
  { sku: 'P-JAM-BE', price: 33.00 }, 
  { sku: 'P-JAM-CC', price: 22.90 }, 
  { sku: 'P-PAL-BE-100-PASS', price: 23.80 }, 
  { sku: 'P-PAL-BE-100', price: 23.30 }, 
  { sku: 'P-PAL-CC', price: 17.50 }, 
  { sku: 'P-JAM-BE-100-DESH', price: 78.00 }, 
  { sku: 'P-JAM-BE-DESH', price: 65.90 }, 
  { sku: 'P-JAM-CC-DESH', price: 41.90 }, 
  { sku: 'P-PAL-BE-100-DESH', price: 45.90 }, 
  { sku: 'P-PAL-BE-DESH', price: 45.90 }, 
  { sku: 'P-PAL-CC-DESH', price: 35.90 }, 
  { sku: 'P-EM-LOM-BE-ROSCAL', price: 51.90 }, 
  { sku: 'P-EM-LOM-BE-100', price: 47.90 }, 
  { sku: 'P-EM-LOM-BE', price: 47.90 }, 
  { sku: 'P-EM-LOM-BE-MITO', price: 56.90 }, 
  { sku: 'P-EM-LOM-BE-COPP', price: 35.90 }, 
  { sku: 'P-EM-SAL-BE-CULR', price: 27.50 }, 
  { sku: 'P-EM-CH-BE-CULR', price: 26.50 }, 
  { sku: 'P-EM-CH-VELA_CHAR', price: 24.00 }, 
  { sku: 'P-EM-SAL-VE-CHAR', price: 24.00 }, 
  { sku: 'P-EM-CH-LONG', price: 26.00 }, 
  { sku: 'P-EM-CH-LONG-PIC', price: 26.00 }, 
  { sku: 'P-EM-LOM-BE-SOLOM', price: 34.00 }, 
  { sku: 'U-EM-CH-BE-VELA-200', price: 5.20 }, 
  { sku: 'U-EM-SAL-BE-200', price: 5.20 }, 
  { sku: 'U-EM-CH-BE-VELA-200-PIC', price: 5.20 }, 
];

async function run() {
  try {
    await sql.connect(dbConfig);
    
    // Create Tarifa
    const tarifaResult = await sql.query`
      INSERT INTO Tarifa (Nombre, Descripcion, Activa)
      OUTPUT INSERTED.Id
      VALUES ('TARIFA DON IBÉRICO ARTESANOS DEL CERDO IBÉRICO, S. L. 2026', 'Tarifa importada desde PDF', 1)
    `;
    
    const tarifaId = tarifaResult.recordset[0].Id;
    console.log('Created Tarifa ID:', tarifaId);
    
    // Insert Prices
    for (const item of prices) {
      await sql.query`
        INSERT INTO PreciosTarifa (TarifaId, ProductoId, PrecioTarifa)
        VALUES (${tarifaId}, ${item.sku}, ${item.price})
      `;
      console.log(`Inserted price for ${item.sku}: ${item.price}`);
    }
    
    console.log('Done!');
  } catch (err) {
    console.error(err);
  } finally {
    await (sql as any).close?.();
  }
}

run();
