const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const startStr = "  useEffect(() => {\n    if (showCommissionsReport";
const endStr = "  // --- Render Login ---";
const startIdx = content.indexOf(startStr);
const endIdx = content.indexOf(endStr);

if (startIdx !== -1 && endIdx !== -1) {
  content = content.substring(0, startIdx) + content.substring(endIdx);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully removed showCommissionsReport useEffect');
} else {
  console.log('Could not find showCommissionsReport useEffect');
}
