const fs = require('fs');
let content = fs.readFileSync('src/components/Agentes/Agentes.tsx', 'utf8');

// Fix import
content = content.replace("import { SqlAgent, CommissionRule } from '../../types';", "import { SqlAgent, CommissionRule } from '../../../types';");

// Fix TableIcon
content = content.replace("import { \n  Users, Plus, Edit, Trash2, ChevronDown, ChevronRight, FileText, \n  Calculator, Download, AlertCircle, Loader2, CheckCircle2, DollarSign, Percent\n} from 'lucide-react';", "import { \n  Users, Plus, Edit, Trash2, ChevronDown, ChevronRight, FileText, \n  Calculator, Download, AlertCircle, Loader2, CheckCircle2, DollarSign, Percent, Table\n} from 'lucide-react';");
content = content.replace("<TableIcon size={16} />", "<Table size={16} />");

// Fix qData typing
content = content.replace(/qData\.invoices/g, "(qData as any).invoices");
content = content.replace(/qData\.adjustments/g, "(qData as any).adjustments");
content = content.replace(/qData\.totalSales/g, "(qData as any).totalSales");
content = content.replace(/qData\.totalCommission/g, "(qData as any).totalCommission");
content = content.replace(/qData\.name/g, "(qData as any).name");

fs.writeFileSync('src/components/Agentes/Agentes.tsx', content);
console.log('Successfully fixed Agentes.tsx');
