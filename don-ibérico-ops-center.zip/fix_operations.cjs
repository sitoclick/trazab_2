const fs = require('fs');

let content = fs.readFileSync('src/components/Operations/Operations.tsx', 'utf8');

// Add missing imports
if (!content.includes("import PedidosOnline")) {
  content = content.replace("import { Button } from '../Button';", "import { Button } from '../Button';\nimport PedidosOnline from '../../../components/PedidosOnline/PedidosOnline';");
}

// Add missing states
const missingStates = `
  const [isPedidosHoldedOpen, setIsPedidosHoldedOpen] = useState(true);
  const [isPedidosOnlineOpen, setIsPedidosOnlineOpen] = useState(true);
`;

const insertIdx = content.indexOf("export default function Operations({ user, setConfirmDialog }: OperationsProps) {") + 81;
content = content.substring(0, insertIdx) + "\n" + missingStates + content.substring(insertIdx);

// Fix activeTab
content = content.replace("activeTab={activeTab}", "activeTab={'operations'}");

// Fix the trailing )} issue
content = content.replace("        )}\n\n        {/* Traceability View */}", "");

fs.writeFileSync('src/components/Operations/Operations.tsx', content);
console.log('Fixed Operations.tsx');
