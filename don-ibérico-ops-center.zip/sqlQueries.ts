import sql from 'mssql';
import crypto from 'crypto';

// 1. Get Production Data
export const getProductionDataQuery = () => {
  return sql.query`
    SELECT TOP 50 
      MS.Fecha as FechaRegistro, 
      MS.OrigenMovimiento as Tipo, 
      MS.CodigoArticulo as Codigo, 
      A.DescripcionArticulo as Descripcion, 
      MS.Partida, 
      MS.Serie, 
      MS.Unidades, 
      MS.Unidades2_ as Peso 
    FROM MovimientoStock MS WITH (NOLOCK)
    LEFT JOIN Articulos A WITH (NOLOCK) ON MS.CodigoArticulo = A.CodigoArticulo
    WHERE MS.OrigenMovimiento = 'F'
    ORDER BY MS.Fecha DESC, MS.FechaRegistro DESC
  `;
};

// 2. Get Database Schema
export const getSchemaQuery = () => {
  return sql.query`
    SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME NOT LIKE 'sys%' AND TABLE_NAME NOT LIKE 'MS%'
  `;
};

// 3. Specific Pesadas Query
export const getPesadasQuery = (ejercicioPedido: number, seriePedido: string, numeroPedido: number) => {
  return sql.query`
    SELECT NumeroCaja, OrdenBulto_, CodigoArticulo, Unidades, Peso, Partida, NumeroSerieLc, FechaRegistro 
    FROM USR_Pesospedidocliente
    WHERE ejerciciopedido = ${ejercicioPedido}
    AND seriepedido = ${seriePedido}
    AND NumeroPedido = ${numeroPedido}
    ORDER BY FechaRegistro
  `;
};

// 3.1 Get Order Lines Query
export const getOrderLinesQuery = (ejercicioPedido: number, seriePedido: string, numeroPedido: number) => {
  return sql.query`
    SELECT L.LineasPosicion, CASE WHEN L.Estado<>2 then 'Pend.' else 'Serv.' end as Estado,  L.Orden,case when L.StatusCerradoExpediciones=0 then 'NO' else 'SI' end Cerrado , L.CodigoArticulo as Codigo, L.DescripcionArticulo + ' ' + L.Descripcion2Articulo as Articulo,L.Partida, 
    (select SUM(Unidades) from USR_PesosPedidoCliente with(nolock) where LineaPedido=L.LineasPosicion)   as UnidadesPesadas, (select SUM(Peso) from USR_PesosPedidoCliente with(nolock) where LineaPedido=L.LineasPosicion)   as Unidades2_Pesadas
    ,L.Precio,a.TratamientoPartidas,a.TrataNumerosSerieLc,L.Descripcion2Articulo, L.Comentario ,L.DescripcionLinea,L.Observaciones,A.usrPiezasKilosBascula, 
    CASE WHEN C.StatusCerradoExpediciones=0 THEN 'NO' ELSE 'SI' END as StatusCerradoCabecera,
    L.usrBultosBascula as BultosBascula,
    L.UnidadesPedidas
    FROM LineasPedidoCliente L with(nolock) 
    LEFT JOIN CabeceraPedidoCliente C with(nolock) ON(L.CodigoEmpresa=C.CodigoEmpresa  AND L.EjercicioPedido=C.EjercicioPedido AND L.SeriePedido =C.SeriePedido   AND L.NumeroPedido =C.NumeroPedido) LEFT JOIN Articulos A with(nolock) ON(A.CodigoEmpresa =1 and L.CodigoArticulo =A.CodigoArticulo) LEFT JOIN Clientes Cl with(nolock)   ON (Cl.CodigoEmpresa=1   AND C.CodigoCliente=Cl.CodigoCliente) left join Rutas_ R with(nolock) on(C.CodigoEmpresa=R.CodigoEMpresa and c.codigoruta_=R.codigoruta_) left join Transportistas T on(C.CodigoEmpresa=T.CodigoEMpresa and c.CodigoTransportistaEnvios=T.CodigoTransportista) 
    WHERE C.Codigoempresa=1 and A.TipoArticulo NOT IN ('C')
    and C.EjercicioPedido=${ejercicioPedido} and C.SeriePedido=${seriePedido} and C.NumeroPedido=${numeroPedido} order by L.Orden
  `;
};

// 3.2 Get Pesadas Linea Query
export const getPesadasLineaQuery = (ejercicioPedido: number, seriePedido: string, numeroPedido: number, codigoArticulo: string) => {
  return sql.query`
    SELECT NumeroCaja, OrdenBulto_, Unidades, Peso, Partida, NumeroSerieLc, FechaRegistro 
    FROM USR_Pesospedidocliente
    WHERE ejerciciopedido = ${ejercicioPedido}
    AND seriepedido = ${seriePedido}
    AND NumeroPedido = ${numeroPedido}
    and CodigoArticulo = ${codigoArticulo}
    ORDER BY FechaRegistro
  `;
};

// 4. Calicer Query
export const getCalicerQuery = (year: number) => {
  return sql.query`
    WITH DatosLimpios AS (
        SELECT 
            MONTH(p.FechaRegistro) AS MesNumero,
            DATENAME(month, p.FechaRegistro) AS MesNombre,
            LOWER(LTRIM(RTRIM(a.TipoArticuloEscandallo))) AS TipoArticulo,
            UPPER(LTRIM(RTRIM(cap.Raza))) AS Raza,
            UPPER(LTRIM(RTRIM(cap.Alimentacion))) AS Alimentacion,
            CAST(1 AS INT) AS Cantidad
        FROM USR_PesosPedidoCliente AS p WITH (NOLOCK) 
        INNER JOIN ARticulos AS a WITH (NOLOCK)  
            ON p.CodigoArticulo = a.codigoArticulo
        INNER JOIN Movimientoarticuloserie AS mas WITH (NOLOCK)  
            ON p.NumeroserielC = mas.numeroserielc AND mas.Origendocumento = 0 
        INNER JOIN CabeceraAlbaranproveedor AS cap WITH (NOLOCK)  
            ON mas.Codigoempresa = cap.Codigoempresa 
            AND mas.EjercicioDocumento = cap.EjercicioAlbaran 
            AND mas.seriedocumento = cap.SerieAlbaran 
            AND mas.Documento = cap.Numeroalbaran
        WHERE 
            p.EjercicioPedido = ${year}
            AND p.SeriePedido not in ('PTR26','DI26')
            AND p.NumeroSerieLc IS NOT NULL
            AND p.NumeroSerieLc != ''
            AND p.NumeroSerieLc != '9'
            AND LOWER(LTRIM(RTRIM(a.TipoArticuloEscandallo))) IN ('jamón', 'paleta')
            
        UNION ALL
        
        SELECT 
            MONTH(p.FechaRegistro) AS MesNumero,
            DATENAME(month, p.FechaRegistro) AS MesNombre,
            LOWER(LTRIM(RTRIM(a.TipoArticuloEscandallo))) AS TipoArticulo,
            UPPER(LTRIM(RTRIM(cap.Raza))) AS Raza,
            UPPER(LTRIM(RTRIM(cap.Alimentacion))) AS Alimentacion,
            CAST(p.Unidades AS INT) AS Cantidad
        FROM USR_PesosPedidoCliente AS p WITH (NOLOCK) 
        INNER JOIN ARticulos AS a WITH (NOLOCK)  
            ON p.CodigoArticulo = a.codigoArticulo
        INNER JOIN CabeceraAlbaranProveedor AS cap WITH (NOLOCK) 
            ON p.Partida = cap.Partida
        WHERE 
            p.EjercicioPedido = ${year}
            AND p.SeriePedido not in ('PTR26','DI26')
            AND LOWER(LTRIM(RTRIM(a.TipoArticuloEscandallo))) = 'lomo'
            AND p.CodigoArticulo NOT IN ('P-EM-LOM-BE-COPP','P-EM-LOM-BE-MITO')
    )
    SELECT 
        MesNumero,
        UPPER(MesNombre) AS MES,
        
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'CEBO' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_Cebo_50,
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'CEBO' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_Cebo_75,
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'CEBO' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_Cebo_100,
        
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_CCampo_50,
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_CCampo_75,
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_CCampo_100,

        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'BELLOTA' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_Bellota_50,
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'BELLOTA' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_Bellota_75,
        SUM(CASE WHEN TipoArticulo = 'jamón' AND Alimentacion = 'BELLOTA' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Jamon_Bellota_100,

        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'CEBO' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_Cebo_50,
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'CEBO' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_Cebo_75,
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'CEBO' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_Cebo_100,
        
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_CCampo_50,
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_CCampo_75,
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_CCampo_100,

        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'BELLOTA' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_Bellota_50,
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'BELLOTA' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_Bellota_75,
        SUM(CASE WHEN TipoArticulo = 'paleta' AND Alimentacion = 'BELLOTA' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Paleta_Bellota_100,

        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'CEBO' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_Cebo_50,
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'CEBO' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_Cebo_75,
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'CEBO' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_Cebo_100,
        
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_CCampo_50,
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_CCampo_75,
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'CEBO DE CAMPO' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_CCampo_100,

        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'BELLOTA' AND Raza = '50% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_Bellota_50,
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'BELLOTA' AND Raza = '75% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_Bellota_75,
        SUM(CASE WHEN TipoArticulo = 'lomo' AND Alimentacion = 'BELLOTA' AND Raza = '100% IBERICO' THEN Cantidad ELSE 0 END) AS Lomo_Bellota_100

    FROM DatosLimpios
    GROUP BY 
        MesNumero, 
        MesNombre
    ORDER BY 
        MesNumero ASC;
  `;
};

// 5. Clear Orders Query (Legacy, keeping for reference if needed)
export const getClearOrdersQuery = () => {
  return sql.query`
    UPDATE CabeceraPedidoCliente
    SET Estado = 2
    WHERE Estado != 2
    AND codigocliente != '69b036936005caa'
  `;
};

// 5.1 Get Pending Orders
export const getPendingOrdersQuery = (sent: boolean = false, year: number = 2026) => {
  if (sent) {
    return sql.query`
      SELECT 
        C.CodigoCliente,
        C.FechaPedido as [F.Pedido],
        case when c.StatusCerradoExpediciones=0 then 'NO' else 'SI' end as Cerrado,
        C.CodigoEmpresa,
        C.EjercicioPedido,
        C.SeriePedido,
        C.NumeroPedido,
        C.RazonSocial + '-' + C.Nombre + isnull(char(13) + char(10) + 'Ruta:' + R.Ruta_,'') as [Razon Social],
        isnull(T.Transportista,'') as Transportista,
        c.usrBultosEnvio as BultosEnvio,
        C.Estado
      FROM CabeceraPedidoCliente C with(nolock)
      left join Transportistas T with(nolock) on(C.CodigoEmpresa=T.CodigoEMpresa and c.CodigoTransportistaEnvios=T.CodigoTransportista) 
      left join Rutas_ R with(nolock) on(C.CodigoEmpresa=R.CodigoEMpresa and c.CodigoRuta_=R.CodigoRuta_) 
      WHERE C.Codigoempresa=1 
      AND C.Estado = 2
      AND C.EjercicioPedido = ${year}
      ORDER BY C.FechaPedido desc, C.CodigoEmpresa, C.EjercicioPedido, C.SeriePedido, C.NumeroPedido
    `;
  } else {
    return sql.query`
      SELECT 
        C.CodigoCliente,
        C.FechaPedido as [F.Pedido],
        case when c.StatusCerradoExpediciones=0 then 'NO' else 'SI' end as Cerrado,
        C.CodigoEmpresa,
        C.EjercicioPedido,
        C.SeriePedido,
        C.NumeroPedido,
        C.RazonSocial + '-' + C.Nombre + isnull(char(13) + char(10) + 'Ruta:' + R.Ruta_,'') as [Razon Social],
        isnull(T.Transportista,'') as Transportista,
        c.usrBultosEnvio as BultosEnvio,
        C.Estado
      FROM CabeceraPedidoCliente C with(nolock)
      left join Transportistas T with(nolock) on(C.CodigoEmpresa=T.CodigoEMpresa and c.CodigoTransportistaEnvios=T.CodigoTransportista) 
      left join Rutas_ R with(nolock) on(C.CodigoEmpresa=R.CodigoEMpresa and c.CodigoRuta_=R.CodigoRuta_) 
      WHERE C.Codigoempresa=1 
      AND C.Estado <> 2
      AND C.EjercicioPedido = ${year}
      AND C.FechaNecesaria <= GETDATE()
      ORDER BY C.FechaPedido desc, C.CodigoEmpresa, C.EjercicioPedido, C.SeriePedido, C.NumeroPedido
    `;
  }
};

export const getReservasQuery = () => {
  return sql.query`
    SELECT
      C.CodigoCliente,
      C.FechaPedido as [F.Pedido],
      case when c.StatusCerradoExpediciones=0 then 'NO' else 'SI' end as Cerrado,
      C.CodigoEmpresa,
      C.EjercicioPedido,
      C.SeriePedido,
      C.NumeroPedido,
      C.RazonSocial + '-' + C.Nombre + isnull(char(13) + char(10) + 'Ruta:' + R.Ruta_,'') as [Razon Social],
      isnull(T.Transportista,'') as Transportista,
      c.usrBultosEnvio as BultosEnvio
    FROM CabeceraPedidoCliente C with(nolock)
    left join Transportistas T with(nolock) on(C.CodigoEmpresa=T.CodigoEMpresa and c.CodigoTransportistaEnvios=T.CodigoTransportista)
    left join Rutas_ R with(nolock) on(C.CodigoEmpresa=R.CodigoEMpresa and c.CodigoRuta_=R.CodigoRuta_)
    WHERE C.Codigoempresa=1
    AND (C.SeriePedido like 'RS%' OR C.SeriePedido like 'DP%')
    ORDER BY C.FechaPedido desc, C.CodigoEmpresa, C.EjercicioPedido, C.SeriePedido, C.NumeroPedido
  `;
};

// 5.1.2 Get DEPC Data
export const getDEPCQuery = (ejercicioPedido: number, seriePedido: string, numeroPedido: number) => {
  return sql.query`
    SELECT        M.CodigoEmpresa, M.Comentario, M.NumeroSerieLc, C.EjercicioAlbaran, C.SerieAlbaran, C.NumeroAlbaran, A.CodigoArticulo, A.DescripcionArticulo, V.Unidades, V.Peso, V.FechaRegistro, V.Partida,
    C.RazonSocial AS proveedor, C.Finca, C.ExplotacionGanadera, C.CodigoEntidadInspeccion, C.NroCertificado, C.LoteExplotacion, C.ReferenciaAnimales, C.NroAnimales,
    C.Raza, C.LoteSacrificio, C.FechaEntradaMatadero, C.FechaSacrificio, C.CodigoEntidadAnalitica, C.NroAnalitica, C.Calidad, C.TipoCerdos, C.PiezasCerdos,
    C.EntidadInspeccion, C.Matadero, C.EntidadAnalitica, C.Alimentacion, TR.FechaSalazon,
    CP.EjercicioPedido,CP.SeriePedido,CP.NumeroPedido,Cp.FechaPedido,CP.Codigocliente,   CP.RazonSocial,   CP.Domicilio,CP.Municipio,   CP.CodigoPostal,   CP.Provincia,  CP.RazonSocialEnvios,CP.RazonSocial2Envios,   CP.DomicilioEnvios,   CP.MunicipioEnvios,   CP.CodigoPostalEnvios,
    CP.ProvinciaEnvios,  CP.ObservacionesPedido
    FROM            dbo.Usr_pesospedidocliente AS V
    INNER JOIN   dbo.MovimientoArticuloSerie AS M ON M.CodigoEmpresa = V.CodigoEmpresa AND M.NumeroSerieLc = V.NumeroSerieLc
    INNER JOIN  dbo.CabeceraAlbaranProveedor AS C ON M.CodigoEmpresa = C.CodigoEmpresa AND M.EjercicioDocumento = C.EjercicioAlbaran AND M.SerieDocumento = C.SerieAlbaran AND M.Documento = C.NumeroAlbaran
    INNER JOIN  dbo.USR_TrazabPartidas AS TR ON M.MovPosicionOrigen = TR.LineasPosicion
    INNER JOIN  dbo.Articulos as A on M.CodigoArticulo = A.CodigoArticulo and M.CodigoEmpresa = A.CodigoEmpresa
    INNER JOIN dbo.CabeceraPedidoCliente as CP on CP.CodigoEmpresa = V.CodigoEmpresa and CP.EjercicioPedido = V.EjercicioPedido and CP.SeriePedido = V.SeriePedido AND V.NumeroPedido = CP.NumeroPedido
    WHERE        (M.OrigenDocumento = 0)
    and V.EjercicioPedido = ${ejercicioPedido}
    and CP.SeriePedido = ${seriePedido} and CP.NumeroPedido = ${numeroPedido}
    order by cp.FechaPedido desc
  `;
};

// 5.3 Force Close Order Query
export const forceCloseOrderQuery = async (empresa: number, ejercicio: number, serie: string, numero: number) => {
  return sql.query`
    EXEC sp_set_session_context N'BypassTrigger', 1;
    UPDATE [dbo].[CabeceraPedidoCliente]
    SET StatusCerradoExpediciones = -1
    WHERE StatusCerradoExpediciones <> -1 
    AND CodigoEmpresa = ${empresa}
    AND EjercicioPedido = ${ejercicio}
    AND SeriePedido = ${serie}
    AND NumeroPedido = ${numero};
    EXEC sp_set_session_context N'BypassTrigger', 0;
  `;
};

// 5.2 Update Selected Orders
export const updateSelectedOrdersQuery = async (orders: { CodigoEmpresa: number, EjercicioPedido: number, SeriePedido: string, NumeroPedido: number }[]) => {
  const request = new sql.Request();
  
  // Build a dynamic query with parameters for each order to prevent SQL injection
  let queryParts = [];
  for (let i = 0; i < orders.length; i++) {
    const order = orders[i];
    request.input(`empresa_${i}`, sql.Int, order.CodigoEmpresa);
    request.input(`ejercicio_${i}`, sql.Int, order.EjercicioPedido);
    request.input(`serie_${i}`, sql.VarChar, order.SeriePedido);
    request.input(`numero_${i}`, sql.Int, order.NumeroPedido);
    
    queryParts.push(`(CodigoEmpresa = @empresa_${i} AND EjercicioPedido = @ejercicio_${i} AND SeriePedido = @serie_${i} AND NumeroPedido = @numero_${i})`);
  }
  
  if (queryParts.length === 0) return { rowsAffected: [0] };

  const finalQuery = `
    UPDATE CabeceraPedidoCliente
    SET Estado = 2
    WHERE ${queryParts.join(' OR ')}
  `;
  
  return request.query(finalQuery);
};

export const closeAndPrintSelectedOrdersQuery = async (orders: { CodigoEmpresa: number, EjercicioPedido: number, SeriePedido: string, NumeroPedido: number }[]) => {
  const request = new sql.Request();
  
  // Build a dynamic query with parameters for each order to prevent SQL injection
  let queryParts = [];
  for (let i = 0; i < orders.length; i++) {
    const order = orders[i];
    request.input(`empresa_${i}`, sql.Int, order.CodigoEmpresa);
    request.input(`ejercicio_${i}`, sql.Int, order.EjercicioPedido);
    request.input(`serie_${i}`, sql.VarChar, order.SeriePedido);
    request.input(`numero_${i}`, sql.Int, order.NumeroPedido);
    
    queryParts.push(`(CodigoEmpresa = @empresa_${i} AND EjercicioPedido = @ejercicio_${i} AND SeriePedido = @serie_${i} AND NumeroPedido = @numero_${i})`);
  }
  
  if (queryParts.length === 0) return { rowsAffected: [0] };

  const finalQuery = `
    UPDATE [dbo].[CabeceraPedidoCliente]
    SET StatusCerradoExpediciones = -1
    WHERE StatusCerradoExpediciones <> -1 AND (${queryParts.join(' OR ')})
  `;
  
  return request.query(finalQuery);
};

// 5.4 Revert Order to Pending Query
export const revertOrderToPendingQuery = async (empresa: number, ejercicio: number, serie: string, numero: number) => {
  return sql.query`
    UPDATE CabeceraPedidoCliente
    SET Estado = 1
    WHERE CodigoEmpresa = ${empresa}
    AND EjercicioPedido = ${ejercicio}
    AND SeriePedido = ${serie}
    AND NumeroPedido = ${numero};
  `;
};

// 5.5 Reopen Order Query
export const reopenOrderQuery = async (empresa: number, ejercicio: number, serie: string, numero: number) => {
  return sql.query`
    EXEC sp_set_session_context N'BypassTrigger', 1;
    UPDATE [dbo].[CabeceraPedidoCliente]
    SET StatusCerradoExpediciones = 0
    WHERE CodigoEmpresa = ${empresa}
    AND EjercicioPedido = ${ejercicio}
    AND SeriePedido = ${serie}
    AND NumeroPedido = ${numero};
    EXEC sp_set_session_context N'BypassTrigger', 0;
  `;
};

// 6. ASICI Query
export const getAsiciQuery = (cliente: string, fechaDesde: string, fechaHasta: string) => {
  return sql.query`
    SELECT NumeroserieLC as 'PRECINTO_DESDE', '' as 'PRECINTO_HASTA' 
    FROM USR_PesosPedidoCliente as p
    LEFT OUTER JOIN CabeceraPedidoCliente as cac 
      ON p.EjercicioPedido = cac.ejerciciopedido 
      AND p.Seriepedido = cac.Seriepedido 
      AND p.Numeropedido = cac.numeropedido
    WHERE cac.codigocliente = ${cliente}
    AND cac.FechaPedido >= ${fechaDesde}
    AND cac.fechapedido <= ${fechaHasta}
  `;
};

export const cambiarPesadasPedido = async (
  ejercicioOrigen: number,
  serieOrigen: string,
  numeroOrigen: number,
  lineaOrigen: string,
  codigoArticulo: string,
  ejercicioDestino: number,
  serieDestino: string,
  numeroDestino: number
) => {
  // 1. Find the LineaPedido in the destination order for the same CodigoArticulo
  const destLineResult = await sql.query`
    SELECT TOP 1 LineasPosicion 
    FROM LineasPedidoCliente 
    WHERE EjercicioPedido = ${ejercicioDestino} 
      AND SeriePedido = ${serieDestino} 
      AND NumeroPedido = ${numeroDestino} 
      AND CodigoArticulo = ${codigoArticulo}
  `;

  if (destLineResult.recordset.length === 0) {
    throw new Error('No se encontró el artículo en el pedido de destino.');
  }

  const lineaDestino = destLineResult.recordset[0].LineasPosicion;

  // 2. Update USR_PesosPedidoCliente
  await sql.query`
    UPDATE USR_PesosPedidoCliente
    SET EjercicioPedido = ${ejercicioDestino},
        SeriePedido = ${serieDestino},
        NumeroPedido = ${numeroDestino},
        LineaPedido = ${lineaDestino}
    WHERE EjercicioPedido = ${ejercicioOrigen}
      AND SeriePedido = ${serieOrigen}
      AND NumeroPedido = ${numeroOrigen}
      AND LineaPedido = ${lineaOrigen}
      AND CodigoArticulo = ${codigoArticulo}
  `;
};

export const corregirPrecintoLote = async (lote: string, tipo: string, precinto: string) => {
  const prefix = tipo === 'Jamon' ? '1' : '2';
  
  // Find a valid entry movement for this lot and type
  const result = await sql.query`
    SELECT TOP 1 * 
    FROM MovimientoArticuloSerie 
    WHERE Partida = ${lote} 
      AND OrigenDocumento = 0 
      AND NumeroSerieLc LIKE ${prefix + '%'}
  `;

  if (result.recordset.length === 0) {
    throw new Error('Lote erróneo o no se encontró una pieza de ese tipo en el lote de entrada.');
  }

  const row = result.recordset[0];
  
  // Generate a new GUID for MovPosicionSerie
  const newMovPosicionSerie = crypto.randomUUID().toUpperCase();

  // Insert the duplicated row with the new serial number
  await sql.query`
    INSERT INTO MovimientoArticuloSerie (
      CodigoEmpresa, CodigoArticulo, NumeroSerieLc, MovPosicion, Fecha, FechaRegistro,
      StatusAcumulado, OrigenDocumento, EjercicioDocumento, SerieDocumento, Documento,
      MovPosicionOrigen, CodigoColor_, CodigoTalla01_, CodigoAlmacen, Ubicacion, Partida,
      UnidadMedida1_, UnidadesSerie, NumeroSerieFabricante, EmpresaOrigen, CodigoCliente,
      CodigoProveedor, MovPosicionSerie, Comentario, Peso
    ) VALUES (
      ${row.CodigoEmpresa}, ${row.CodigoArticulo}, ${precinto}, ${row.MovPosicion}, ${row.Fecha}, GETDATE(),
      ${row.StatusAcumulado}, ${row.OrigenDocumento}, ${row.EjercicioDocumento}, ${row.SerieDocumento}, ${row.Documento},
      ${row.MovPosicionOrigen}, ${row.CodigoColor_}, ${row.CodigoTalla01_}, ${row.CodigoAlmacen}, ${row.Ubicacion}, ${row.Partida},
      ${row.UnidadMedida1_}, ${row.UnidadesSerie}, ${precinto}, ${row.EmpresaOrigen}, ${row.CodigoCliente},
      ${row.CodigoProveedor}, ${newMovPosicionSerie}, ${row.Comentario}, ${row.Peso}
    )
  `;
  
  return { success: true, message: 'Precinto corregido y añadido correctamente.' };
};

// 8. Agentes Queries
export const initializeTables = async () => {
  try {
    // Add ClientId and ClientName to Comisiones if they don't exist
    try {
      await sql.query`
        IF NOT EXISTS (
          SELECT * FROM sys.columns 
          WHERE object_id = OBJECT_ID('Comisiones') AND name = 'ClientId'
        )
        BEGIN
          ALTER TABLE Comisiones ADD ClientId NVARCHAR(50);
          ALTER TABLE Comisiones ADD ClientName NVARCHAR(255);
        END
      `;
    } catch (err) {
      console.error('Error altering Comisiones table:', err);
    }

    // Create Agentes table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Agentes' and xtype='U')
      CREATE TABLE Agentes (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Nombre NVARCHAR(100) NOT NULL,
        Email NVARCHAR(100),
        Telefono NVARCHAR(20),
        Activo BIT DEFAULT 1,
        FechaAlta DATETIME DEFAULT GETDATE()
      )
    `;

    // Create ReglasComision table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ReglasComision' and xtype='U')
      CREATE TABLE ReglasComision (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        AgenteId INT FOREIGN KEY REFERENCES Agentes(Id),
        Categoria NVARCHAR(255),
        Formato NVARCHAR(255),
        Porcentaje DECIMAL(5,2) NOT NULL,
        FechaInicio DATE,
        FechaFin DATE,
        Descripcion NVARCHAR(500),
        ClientId NVARCHAR(50),
        ClientName NVARCHAR(255),
        FechaCreacion DATETIME DEFAULT GETDATE()
      )
    `;
    // Create Tarifa table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Tarifa' and xtype='U')
      CREATE TABLE Tarifa (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Nombre NVARCHAR(100) NOT NULL,
        Descripcion NVARCHAR(255),
        Activa BIT DEFAULT 1,
        FechaCreacion DATETIME DEFAULT GETDATE()
      )
    `;

    // Create PreciosTarifa table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='PreciosTarifa' and xtype='U')
      CREATE TABLE PreciosTarifa (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        TarifaId INT NOT NULL FOREIGN KEY REFERENCES Tarifa(Id) ON DELETE CASCADE,
        ProductoId NVARCHAR(50) NOT NULL,
        PrecioTarifa DECIMAL(18,2) NOT NULL,
        AjusteFijo DECIMAL(18,2) DEFAULT 0,
        AjustePorcentaje DECIMAL(5,2) DEFAULT 0,
        UltimaModificacion DATETIME DEFAULT GETDATE(),
        UNIQUE(TarifaId, ProductoId)
      )
    `;
    // Create ComisionesCalculadas table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ComisionesCalculadas' and xtype='U')
      CREATE TABLE ComisionesCalculadas (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        AgenteId INT FOREIGN KEY REFERENCES Agentes(Id),
        Trimestre NVARCHAR(10) NOT NULL,
        Anio INT NOT NULL,
        TotalComision DECIMAL(18,2) NOT NULL,
        DetallesJson NVARCHAR(MAX) NOT NULL,
        FechaCalculo DATETIME DEFAULT GETDATE(),
        UNIQUE(AgenteId, Trimestre, Anio)
      )
    `;
    // Create ComisionesOverrides table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ComisionesOverrides' and xtype='U')
      CREATE TABLE ComisionesOverrides (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        InvoiceId NVARCHAR(50) NOT NULL,
        AgentId INT FOREIGN KEY REFERENCES Agentes(Id),
        Removed BIT DEFAULT 0,
        LinesData NVARCHAR(MAX),
        FechaModificacion DATETIME DEFAULT GETDATE(),
        UNIQUE(InvoiceId, AgentId)
      )
    `;

    // Create ComisionesAdjustments table if it doesn't exist
    await sql.query`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ComisionesAdjustments' and xtype='U')
      CREATE TABLE ComisionesAdjustments (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        AgentId INT FOREIGN KEY REFERENCES Agentes(Id),
        Year INT NOT NULL,
        Quarter NVARCHAR(10) NOT NULL,
        Amount DECIMAL(10,2) NOT NULL,
        Description NVARCHAR(255) NOT NULL,
        CreatedAt DATETIME DEFAULT GETDATE()
      )
    `;
    console.log('Tables initialized successfully');
  } catch (err) {
    console.error('Error initializing tables:', err);
  }
};

export const getComisionesOverridesQuery = (agentId: number) => {
  return sql.query`SELECT InvoiceId as invoiceId, Removed as removed, LinesData as linesData FROM ComisionesOverrides WHERE AgentId = ${agentId}`;
};

export const getComisionesAdjustmentsQuery = (agentId: number, year: number) => {
  return sql.query`SELECT Id as id, Quarter as quarter, Amount as amount, Description as description FROM ComisionesAdjustments WHERE AgentId = ${agentId} AND Year = ${year}`;
};

export const createComisionesAdjustmentQuery = (agentId: number, year: number, quarter: string, amount: number, description: string) => {
  return sql.query`INSERT INTO ComisionesAdjustments (AgentId, Year, Quarter, Amount, Description) VALUES (${agentId}, ${year}, ${quarter}, ${amount}, ${description})`;
};

export const deleteComisionesAdjustmentQuery = (id: number) => {
  return sql.query`DELETE FROM ComisionesAdjustments WHERE Id = ${id}`;
};

export const upsertComisionesOverrideQuery = (invoiceId: string, agentId: number, removed: boolean, linesData: string | null) => {
  return sql.query`
    IF EXISTS (SELECT 1 FROM ComisionesOverrides WHERE InvoiceId = ${invoiceId} AND AgentId = ${agentId})
    BEGIN
      UPDATE ComisionesOverrides 
      SET Removed = ${removed}, LinesData = ${linesData}, FechaModificacion = GETDATE()
      WHERE InvoiceId = ${invoiceId} AND AgentId = ${agentId}
    END
    ELSE
    BEGIN
      INSERT INTO ComisionesOverrides (InvoiceId, AgentId, Removed, LinesData)
      VALUES (${invoiceId}, ${agentId}, ${removed}, ${linesData})
    END
  `;
};

export const deleteComisionesOverrideQuery = (invoiceId: string, agentId: number) => {
  return sql.query`DELETE FROM ComisionesOverrides WHERE InvoiceId = ${invoiceId} AND AgentId = ${agentId}`;
};

export const deleteAllComisionesOverridesQuery = (agentId: number) => {
  return sql.query`DELETE FROM ComisionesOverrides WHERE AgentId = ${agentId}`;
};

export const getTarifasQuery = () => {
  return sql.query`SELECT Id as id, Nombre as name, Descripcion as description, Activa as active FROM Tarifa ORDER BY Nombre`;
};

export const createTarifaQuery = (nombre: string, descripcion: string, activo: boolean) => {
  return sql.query`
    INSERT INTO Tarifa (Nombre, Descripcion, Activa)
    OUTPUT INSERTED.Id as id, INSERTED.Nombre as name, INSERTED.Descripcion as description, INSERTED.Activa as active
    VALUES (${nombre}, ${descripcion}, ${activo ? 1 : 0})
  `;
};

export const updateTarifaQuery = (id: number, nombre: string, descripcion: string, activo: boolean) => {
  return sql.query`
    UPDATE Tarifa
    SET Nombre = ${nombre}, Descripcion = ${descripcion}, Activa = ${activo ? 1 : 0}
    OUTPUT INSERTED.Id as id, INSERTED.Nombre as name, INSERTED.Descripcion as description, INSERTED.Activa as active
    WHERE Id = ${id}
  `;
};

export const deleteTarifaQuery = (id: number) => {
  return sql.query`DELETE FROM Tarifa WHERE Id = ${id}`;
};

export const getPreciosTarifaQuery = (tarifaId?: number) => {
  if (tarifaId !== undefined) {
    return sql.query`SELECT Id as id, TarifaId as tarifaId, ProductoId as productId, PrecioTarifa as precio FROM PreciosTarifa WHERE TarifaId = ${tarifaId}`;
  }
  return sql.query`SELECT Id as id, TarifaId as tarifaId, ProductoId as productId, PrecioTarifa as precio FROM PreciosTarifa`;
};

export const updatePrecioTarifaQuery = (tarifaId: number, productoId: string, precio: number) => {
  return sql.query`
    MERGE PreciosTarifa AS target
    USING (SELECT ${tarifaId} AS TarifaId, ${productoId} AS ProductoId, ${precio} AS PrecioTarifa) AS source
    ON target.TarifaId = source.TarifaId AND target.ProductoId = source.ProductoId
    WHEN MATCHED THEN
      UPDATE SET PrecioTarifa = source.PrecioTarifa, UltimaModificacion = GETDATE()
    WHEN NOT MATCHED THEN
      INSERT (TarifaId, ProductoId, PrecioTarifa)
      VALUES (source.TarifaId, source.ProductoId, source.PrecioTarifa)
    OUTPUT INSERTED.Id as id, INSERTED.TarifaId as tarifaId, INSERTED.ProductoId as productId, INSERTED.PrecioTarifa as precio;
  `;
};

export const deletePrecioTarifaQuery = (id: number) => {
  return sql.query`DELETE FROM PreciosTarifa WHERE Id = ${id}`;
};

export const getAgentesQuery = () => {
  return sql.query`SELECT Id as id, Nombre as name, Email as email, Telefono as phone, Activo as active FROM Agentes ORDER BY Nombre`;
};

export const createAgenteQuery = (nombre: string, email: string, telefono: string, activo: boolean) => {
  return sql.query`
    INSERT INTO Agentes (Nombre, Email, Telefono, Activo)
    OUTPUT INSERTED.Id as id, INSERTED.Nombre as name, INSERTED.Email as email, INSERTED.Telefono as phone, INSERTED.Activo as active
    VALUES (${nombre}, ${email}, ${telefono}, ${activo ? 1 : 0})
  `;
};

export const updateAgenteQuery = (id: number, nombre: string, email: string, telefono: string, activo: boolean) => {
  return sql.query`
    UPDATE Agentes
    SET Nombre = ${nombre}, Email = ${email}, Telefono = ${telefono}, Activo = ${activo ? 1 : 0}
    OUTPUT INSERTED.Id as id, INSERTED.Nombre as name, INSERTED.Email as email, INSERTED.Telefono as phone, INSERTED.Activo as active
    WHERE Id = ${id}
  `;
};

export const deleteAgenteQuery = (id: number) => {
  return sql.query`DELETE FROM Agentes WHERE Id = ${id}`;
};

// 9. Comisiones Queries
export const getReglasComisionQuery = () => {
  return sql.query`
    SELECT r.Id as id, r.AgenteId as agentId, a.Nombre as agentName, r.Categoria as category, r.Formato as format, r.Porcentaje as rate, 
           CONVERT(varchar, r.FechaInicio, 23) as startDate, CONVERT(varchar, r.FechaFin, 23) as endDate, r.Descripcion as description,
           r.ClientId as clientId, r.ClientName as clientName
    FROM ReglasComision r
    JOIN Agentes a ON r.AgenteId = a.Id
    ORDER BY r.FechaCreacion DESC
  `;
};

export const createReglaComisionQuery = (agenteId: number, categoria: string, formato: string, porcentaje: number, fechaInicio: string, fechaFin: string, descripcion: string, clientId?: string, clientName?: string) => {
  return sql.query`
    DECLARE @Salida TABLE (
      Id INT,
      AgenteId INT,
      Categoria NVARCHAR(MAX),
      Formato NVARCHAR(MAX),
      Porcentaje DECIMAL(18,2),
      FechaInicio DATE,
      FechaFin DATE,
      Descripcion NVARCHAR(MAX),
      ClientId NVARCHAR(50),
      ClientName NVARCHAR(255)
    );

    INSERT INTO ReglasComision (AgenteId, Categoria, Formato, Porcentaje, FechaInicio, FechaFin, Descripcion, ClientId, ClientName)
    OUTPUT INSERTED.Id, INSERTED.AgenteId, INSERTED.Categoria, INSERTED.Formato, 
           INSERTED.Porcentaje, INSERTED.FechaInicio, INSERTED.FechaFin, INSERTED.Descripcion, INSERTED.ClientId, INSERTED.ClientName
    INTO @Salida
    VALUES (${agenteId}, ${categoria}, ${formato}, ${porcentaje}, ${fechaInicio ? fechaInicio : null}, ${fechaFin ? fechaFin : null}, ${descripcion}, ${clientId || null}, ${clientName || null});

    SELECT 
      s.Id as id, 
      s.AgenteId as agentId, 
      a.Nombre as agentName, 
      s.Categoria as category, 
      s.Formato as format, 
      s.Porcentaje as rate, 
      CONVERT(varchar, s.FechaInicio, 23) as startDate, 
      CONVERT(varchar, s.FechaFin, 23) as endDate, 
      s.Descripcion as description,
      s.ClientId as clientId,
      s.ClientName as clientName
    FROM @Salida s
    LEFT JOIN Agentes a ON s.AgenteId = a.Id;
  `;
};

export const updateReglaComisionQuery = (id: number, agenteId: number, categoria: string, formato: string, porcentaje: number, fechaInicio: string, fechaFin: string, descripcion: string, clientId?: string, clientName?: string) => {
  return sql.query`
    DECLARE @Salida TABLE (
      Id INT,
      AgenteId INT,
      Categoria NVARCHAR(MAX),
      Formato NVARCHAR(MAX),
      Porcentaje DECIMAL(18,2),
      FechaInicio DATE,
      FechaFin DATE,
      Descripcion NVARCHAR(MAX),
      ClientId NVARCHAR(50),
      ClientName NVARCHAR(255)
    );

    UPDATE ReglasComision
    SET AgenteId = ${agenteId}, Categoria = ${categoria}, Formato = ${formato}, Porcentaje = ${porcentaje}, 
        FechaInicio = ${fechaInicio ? fechaInicio : null}, FechaFin = ${fechaFin ? fechaFin : null}, Descripcion = ${descripcion},
        ClientId = ${clientId || null}, ClientName = ${clientName || null}
    OUTPUT INSERTED.Id, INSERTED.AgenteId, INSERTED.Categoria, INSERTED.Formato, 
           INSERTED.Porcentaje, INSERTED.FechaInicio, INSERTED.FechaFin, INSERTED.Descripcion, INSERTED.ClientId, INSERTED.ClientName
    INTO @Salida
    WHERE Id = ${id};

    SELECT 
      s.Id as id, 
      s.AgenteId as agentId, 
      a.Nombre as agentName, 
      s.Categoria as category, 
      s.Formato as format, 
      s.Porcentaje as rate, 
      CONVERT(varchar, s.FechaInicio, 23) as startDate, 
      CONVERT(varchar, s.FechaFin, 23) as endDate, 
      s.Descripcion as description,
      s.ClientId as clientId,
      s.ClientName as clientName
    FROM @Salida s
    LEFT JOIN Agentes a ON s.AgenteId = a.Id;
  `;
};

export const deleteReglaComisionQuery = (id: number) => {
  return sql.query`DELETE FROM ReglasComision WHERE Id = ${id}`;
};

export const syncReglasComisionQuery = async (rules: any[]) => {
  const transaction = new sql.Transaction();
  await transaction.begin();
  try {
    const request = new sql.Request(transaction);
    await request.query('DELETE FROM ReglasComision');
    
    for (const rule of rules) {
      const catStr = Array.isArray(rule.category) ? rule.category.join(',') : (rule.category || '');
      const formStr = Array.isArray(rule.formats) ? rule.formats.join(',') : (rule.formats || '');
      
      // Find agentId based on agentName if agentId is missing
      let agentId = rule.agentId;
      if (!agentId && rule.agentName) {
        const agentReq = new sql.Request(transaction);
        agentReq.input('agentName', sql.NVarChar, rule.agentName);
        const agentRes = await agentReq.query('SELECT Id FROM Agentes WHERE Nombre = @agentName');
        if (agentRes.recordset.length > 0) {
          agentId = agentRes.recordset[0].Id;
        }
      }
      
      if (agentId) {
        const insertReq = new sql.Request(transaction);
        insertReq.input('agentId', sql.Int, agentId);
        insertReq.input('category', sql.NVarChar, catStr);
        insertReq.input('format', sql.NVarChar, formStr);
        insertReq.input('rate', sql.Decimal(5, 2), rule.rate || 0);
        insertReq.input('startDate', sql.Date, rule.startDate || null);
        insertReq.input('endDate', sql.Date, rule.endDate || null);
        insertReq.input('description', sql.NVarChar, rule.description || '');
        
        await insertReq.query(`
          INSERT INTO ReglasComision (AgenteId, Categoria, Formato, Porcentaje, FechaInicio, FechaFin, Descripcion)
          VALUES (@agentId, @category, @format, @rate, @startDate, @endDate, @description)
        `);
      }
    }
    
    await transaction.commit();
    return { success: true };
  } catch (err) {
    await transaction.rollback();
    throw err;
  }
};

