const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');
const lines = content.split('\n');
const newLines = [...lines.slice(0, 1070), ...lines.slice(1694)];
fs.writeFileSync('App.tsx', newLines.join('\n'));
console.log('Successfully removed duplicate lines');
