const fs = require('fs');

let content = fs.readFileSync('src/components/Sales.tsx', 'utf8');
content = content.replace(/\\`/g, '`');
content = content.replace(/\\\$/g, '$');
fs.writeFileSync('src/components/Sales.tsx', content);
console.log('Fixed Sales.tsx');

let appContent = fs.readFileSync('App.tsx', 'utf8');
appContent = appContent.replace("    reader.readAsDataURL(blob);\n};\n", "    reader.readAsDataURL(blob);\n  });\n};\n");
appContent = appContent.replace("  const [uniqueFormato, setUniqueFormato] = useState<string[]>([]);\n  });\n  const [maestrosSubTab", "  const [uniqueFormato, setUniqueFormato] = useState<string[]>([]);\n  const [maestrosSubTab");
fs.writeFileSync('App.tsx', appContent);
console.log('Fixed App.tsx');
