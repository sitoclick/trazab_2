const { execSync } = require('child_process');
try {
  const output = execSync('git show HEAD:App.tsx').toString();
  require('fs').writeFileSync('App_old.tsx', output);
  console.log('Saved App_old.tsx');
} catch (e) {
  console.log('Error:', e.message);
}
