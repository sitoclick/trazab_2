const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const stateStart = "const [commissionRules, setCommissionRules] = useState<CommissionRule[]>([]);";
const stateEnd = "// Tarifas State";

const startIdx = content.indexOf(stateStart);
const endIdx = content.indexOf(stateEnd);

if (startIdx !== -1 && endIdx !== -1) {
  const newContent = content.substring(0, startIdx) + content.substring(endIdx);
  fs.writeFileSync('App.tsx', newContent);
  console.log('Successfully removed Agentes state');
} else {
  console.log('Could not find state start or end index');
}
