import 'dotenv/config';
import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function run() {
  try {
    await sql.connect(dbConfig);
    const tables = ['LineasPedidoCliente', 'CabeceraPedidoCliente', 'Articulos', 'Clientes', 'Rutas_', 'Transportistas', 'USR_PesosPedidoCliente'];
    for (const table of tables) {
      const result = await sql.query`
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = ${table} AND COLUMN_NAME = 'Unidades'
      `;
      if (result.recordset.length > 0) {
        console.log(`Table ${table} HAS column Unidades`);
      } else {
        console.log(`Table ${table} DOES NOT have column Unidades`);
      }
    }
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();
