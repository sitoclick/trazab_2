import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER || '',
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function checkRules() {
  try {
    await sql.connect(config);
    const res = await sql.query`
      SELECT r.Id as id, r.AgenteId as agentId, a.Nombre as agentName, r.Categoria as category, r.Formato as format, r.Porcentaje as rate, 
             CONVERT(varchar, r.FechaInicio, 23) as startDate, CONVERT(varchar, r.FechaFin, 23) as endDate, r.Descripcion as description,
             r.ClientId as clientId, r.ClientName as clientName
      FROM ReglasComision r
      JOIN Agentes a ON r.AgenteId = a.Id
      ORDER BY r.FechaCreacion DESC
    `;
    console.log('Rules:', res.recordset);
  } catch (e) {
    console.log('Error:', e.message);
  } finally {
    process.exit(0);
  }
}

checkRules();
