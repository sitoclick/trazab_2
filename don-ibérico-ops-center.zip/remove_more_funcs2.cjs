const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const handleRemoveInvoiceStart = "const handleRemoveInvoiceFromCommissions = async (invoiceId: string) => {";
const handleRemoveInvoiceEnd = "const handleLoadTarifas = async () => {";
const startIdx2 = content.indexOf(handleRemoveInvoiceStart);
const endIdx2 = content.indexOf(handleRemoveInvoiceEnd);
if (startIdx2 !== -1 && endIdx2 !== -1) {
  content = content.substring(0, startIdx2) + content.substring(endIdx2);
}

const useEffectStart2 = "useEffect(() => {\n    if (showCommissionsReport";
const useEffectEnd2 = "useEffect(() => {\n    if (activeTab === 'traceability') {";
const startIdx4 = content.indexOf(useEffectStart2);
const endIdx4 = content.indexOf(useEffectEnd2);
if (startIdx4 !== -1 && endIdx4 !== -1) {
  content = content.substring(0, startIdx4) + content.substring(endIdx4);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully removed more functions');
