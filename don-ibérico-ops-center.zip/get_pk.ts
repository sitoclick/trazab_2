import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER || 'holded',
  password: process.env.DB_PASSWORD || 'erp1234',
  server: process.env.DB_SERVER || 'sitoclick.ddns.net',
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE || 'CARNICAS',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 30000,
  },
};

async function run() {
  try {
    await sql.connect(dbConfig);
    const result = await sql.query`
      SELECT c.COLUMN_NAME
      FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
      JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.CONSTRAINT_NAME
      JOIN INFORMATION_SCHEMA.COLUMNS c ON c.TABLE_NAME = tc.TABLE_NAME AND c.COLUMN_NAME = ccu.COLUMN_NAME
      WHERE tc.TABLE_NAME = 'MovimientoArticuloSerie' AND tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
    `;
    console.log(result.recordset);
  } catch (err) {
    console.error(err);
  } finally {
    await (sql as any).close?.();
  }
}

run();
