const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');
const startStr = "{activeTab === 'agents' && (";
const endStr = "{activeTab === 'maestros' && (";
const startIdx = content.indexOf(startStr);
const endIdx = content.indexOf(endStr);
if (startIdx !== -1 && endIdx !== -1) {
  const newContent = content.substring(0, startIdx) + "{activeTab === 'agents' && (\n          <Agentes user={user} setConfirmDialog={setConfirmDialog} />\n        )}\n\n        " + content.substring(endIdx);
  fs.writeFileSync('App.tsx', newContent);
  console.log('Successfully replaced Agentes UI');
} else {
  console.log('Could not find start or end index');
}
