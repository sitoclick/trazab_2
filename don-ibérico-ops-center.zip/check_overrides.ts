import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER || '',
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

async function checkOverrides() {
  try {
    await sql.connect(config);
    const res1 = await sql.query`SELECT * FROM ComisionesOverrides`;
    console.log('Overrides:', res1.recordset);
    const res2 = await sql.query`SELECT * FROM ComisionesAdjustments`;
    console.log('Adjustments:', res2.recordset);
  } catch (e) {
    console.log('Error:', e.message);
  } finally {
    process.exit(0);
  }
}

checkOverrides();
