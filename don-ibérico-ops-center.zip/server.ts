import 'dotenv/config';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import sql from 'mssql';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { PDFDocument } from 'pdf-lib';
import {
  getProductionDataQuery,
  getSchemaQuery,
  getPesadasQuery,
  getOrderLinesQuery,
  getPesadasLineaQuery,
  cambiarPesadasPedido,
  getCalicerQuery,
  getClearOrdersQuery,
  getPendingOrdersQuery,
  getReservasQuery,
  getDEPCQuery,
  updateSelectedOrdersQuery,
  closeAndPrintSelectedOrdersQuery,
  forceCloseOrderQuery,
  revertOrderToPendingQuery,
  reopenOrderQuery,
  getAsiciQuery,
  getAgentesQuery,
  createAgenteQuery,
  updateAgenteQuery,
  deleteAgenteQuery,
  getReglasComisionQuery,
  createReglaComisionQuery,
  updateReglaComisionQuery,
  deleteReglaComisionQuery,
  syncReglasComisionQuery,
  getComisionesOverridesQuery,
  getComisionesAdjustmentsQuery,
  createComisionesAdjustmentQuery,
  deleteComisionesAdjustmentQuery,
  upsertComisionesOverrideQuery,
  deleteComisionesOverrideQuery,
  deleteAllComisionesOverridesQuery,
  getTarifasQuery,
  createTarifaQuery,
  updateTarifaQuery,
  deleteTarifaQuery,
  getPreciosTarifaQuery,
  updatePrecioTarifaQuery,
  deletePrecioTarifaQuery,
  initializeTables
} from './sqlQueries.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Database Configuration
const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE,
  options: {
    encrypt: false, // Use true for Azure
    trustServerCertificate: true // Change to true for local dev / self-signed certs
  }
};

// 1. Holded Proxy Endpoints
const HOLDED_API_KEY = process.env.HOLDED_API_KEY;

// Shopify Token Cache
const shopifyTokens: Record<string, { token: string | null, expiry: number }> = {
  '1': { token: null, expiry: 0 },
  '2': { token: null, expiry: 0 }
};

async function getShopifyToken(storeIndex: string) {
  const shopUrl = process.env[`SHOPIFY_STORE_${storeIndex}_URL`];
  const clientId = process.env[`SHOPIFY_STORE_${storeIndex}_CLIENT_ID`];
  const clientSecret = process.env[`SHOPIFY_STORE_${storeIndex}_CLIENT_SECRET`];
  const existingToken = process.env[`SHOPIFY_STORE_${storeIndex}_TOKEN`];

  // If we already have a direct access token (shpat_), use it
  if (existingToken && existingToken.startsWith('shpat_')) {
    return existingToken;
  }

  // If we have a cached token that is still valid (with 5 min margin)
  const cached = shopifyTokens[storeIndex];
  if (cached.token && Date.now() < cached.expiry - 300000) {
    return cached.token;
  }

  if (!shopUrl || !clientId || !clientSecret) {
    // If not configured, we just return null and skip this store
    return null;
  }

  const cleanShopUrl = shopUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
  const authUrl = `https://${cleanShopUrl}/admin/oauth/access_token`;

  console.log(`Exchanging Shopify credentials for Store ${storeIndex} token at: ${authUrl}`);

  try {
    const response = await fetch(authUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: clientId,
        client_secret: clientSecret,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Shopify Auth Error Store ${storeIndex}: ${response.status} ${errorText}`);
      return null;
    }

    const data = await response.json();
    shopifyTokens[storeIndex] = {
      token: data.access_token,
      expiry: Date.now() + (data.expires_in * 1000)
    };
    
    console.log(`Shopify token for Store ${storeIndex} obtained successfully`);
    return data.access_token;
  } catch (err) {
    console.error(`Error fetching token for Store ${storeIndex}:`, err);
    return null;
  }
}

// Shopify Orders Endpoint
app.get('/api/shopify/orders', async (req, res) => {
  try {
    const allOrders: any[] = [];
    const stores = ['1', '2'];

    for (const storeIndex of stores) {
      const shopUrl = process.env[`SHOPIFY_STORE_${storeIndex}_URL`];
      if (!shopUrl) continue;

      const token = await getShopifyToken(storeIndex);
      if (!token) continue;

      const cleanShopUrl = shopUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
      const finalUrl = `https://${cleanShopUrl}/admin/api/2024-01/orders.json?status=open`;
      
      console.log(`Fetching Shopify orders from Store ${storeIndex}: ${finalUrl}`);

      try {
        const response = await fetch(finalUrl, {
          headers: {
            'X-Shopify-Access-Token': token,
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          const errorText = await response.text();
          if (response.status === 403 || response.status === 401) {
            shopifyTokens[storeIndex] = { token: null, expiry: 0 };
          }
          console.error(`Shopify API Error Store ${storeIndex}: ${response.status} ${errorText}`);
          continue;
        }

        const data = await response.json();
        const orders = (data.orders || []).map((o: any) => ({
          ...o,
          store_index: storeIndex,
          store_name: cleanShopUrl.split('.')[0]
        }));
        allOrders.push(...orders);
      } catch (err) {
        console.error(`Error fetching orders from Store ${storeIndex}:`, err);
      }
    }

    // Sort all orders by date descending
    allOrders.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    
    res.json(allOrders);
  } catch (err: any) {
    console.error('Shopify Orders Aggregate Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/contacts', async (req, res) => {
  console.log('GET /api/holded/contacts');
  try {
    const response = await fetch('https://api.holded.com/api/invoicing/v1/contacts', {
      headers: {
        'key': HOLDED_API_KEY,
        'Content-Type': 'application/json'
      }
    });
    
    console.log(`Holded API Response Status: ${response.status}`);
    const contentType = response.headers.get('content-type');
    console.log(`Holded API Content-Type: ${contentType}`);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Holded API Error Body: ${errorText}`);
      throw new Error(`Holded API Error: ${response.status} ${errorText}`);
    }
    
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    console.error('Holded Contacts Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/invoices', async (req, res) => {
  const { paid, starttmp, endtmp } = req.query; // 0, 1, or 2. If not provided, we fetch 0 and 2 (unpaid/partial)
  console.log(`GET /api/holded/invoices?paid=${paid}&starttmp=${starttmp}&endtmp=${endtmp}`);
  
  try {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const endOfYear = new Date(now.getFullYear(), 11, 31, 23, 59, 59);
    
    const startTmp = starttmp ? parseInt(starttmp as string) : Math.floor(startOfYear.getTime() / 1000);
    const endTmp = endtmp ? parseInt(endtmp as string) : Math.floor(endOfYear.getTime() / 1000);

    const fetchInvoices = async (paidStatus: string | number) => {
      let allData: any[] = [];
      let page = 1;
      const limit = 100; // Holded max limit is usually 100 or 500
      let hasMore = true;

      while (hasMore) {
        const url = new URL('https://api.holded.com/api/invoicing/v1/documents/invoice');
        url.searchParams.append('starttmp', startTmp.toString());
        url.searchParams.append('endtmp', endTmp.toString());
        if (paidStatus !== 'all') {
          url.searchParams.append('paid', paidStatus.toString());
        }
        url.searchParams.append('sort', 'created-desc');
        url.searchParams.append('page', page.toString());
        url.searchParams.append('limit', limit.toString());

        const response = await fetch(url.toString(), {
          headers: {
            'key': HOLDED_API_KEY,
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Holded API Error (paid=${paidStatus}, page=${page}): ${response.status} ${errorText}`);
        }

        const data = await response.json();
        if (Array.isArray(data)) {
          if (data.length > 0 && page === 1) {
            console.log('Sample Invoice from Holded:', JSON.stringify(data[0], null, 2));
          }
          allData = allData.concat(data);
          if (data.length < limit) {
            hasMore = false;
          } else {
            page++;
          }
        } else {
          hasMore = false;
        }
      }

      // Ensure each invoice has a 'paid' property calculated if missing
      return allData.map((inv: any) => {
        if (inv.paid !== undefined) return inv;
        
        let calculatedPaid = 0;
        const pending = parseFloat(inv.paymentsPending || 0);
        const total = parseFloat(inv.total || 0);
        
        if (pending === 0) {
          calculatedPaid = 1;
        } else if (pending < total && pending > 0) {
          calculatedPaid = 2;
        } else {
          calculatedPaid = 0;
        }
        
        return { ...inv, paid: calculatedPaid };
      });
    };

    let result;
    if (paid === 'all') {
      result = await fetchInvoices('all');
    } else if (paid === '1') {
      // Fetch paid and filter to be 100% sure we only get fully paid
      const rawResult = await fetchInvoices(1);
      result = rawResult.filter((inv: any) => inv.paid === 1);
    } else if (paid === '0') {
      result = await fetchInvoices(0);
    } else if (paid === '2') {
      result = await fetchInvoices(2);
    } else {
      // Default: fetch both unpaid (0) and partially paid (2)
      const [unpaid, partiallyPaid] = await Promise.all([
        fetchInvoices(0),
        fetchInvoices(2)
      ]);
      result = [...unpaid, ...partiallyPaid];
      // Ensure we don't have fully paid ones here
      result = result.filter((inv: any) => inv.paid !== 1);
      result.sort((a, b) => (b.date || 0) - (a.date || 0));
    }

    res.json(result);
  } catch (err: any) {
    console.error('Holded Invoices Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/creditnotes', async (req, res) => {
  const { starttmp, endtmp } = req.query;
  console.log(`GET /api/holded/creditnotes?starttmp=${starttmp}&endtmp=${endtmp}`);
  
  try {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const endOfYear = new Date(now.getFullYear(), 11, 31, 23, 59, 59);
    
    const startTmp = starttmp ? parseInt(starttmp as string) : Math.floor(startOfYear.getTime() / 1000);
    const endTmp = endtmp ? parseInt(endtmp as string) : Math.floor(endOfYear.getTime() / 1000);

    let allData: any[] = [];
    let page = 1;
    const limit = 100;
    let hasMore = true;

    while (hasMore) {
      const url = new URL('https://api.holded.com/api/invoicing/v1/documents/creditnote');
      url.searchParams.append('starttmp', startTmp.toString());
      url.searchParams.append('endtmp', endTmp.toString());
      url.searchParams.append('sort', 'created-desc');
      url.searchParams.append('page', page.toString());
      url.searchParams.append('limit', limit.toString());

      const response = await fetch(url.toString(), {
        headers: {
          'key': HOLDED_API_KEY,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Holded API Error (creditnote, page=${page}): ${response.status} ${errorText}`);
      }

      const data = await response.json();
      if (Array.isArray(data)) {
        allData = allData.concat(data);
        if (data.length < limit) {
          hasMore = false;
        } else {
          page++;
        }
      } else {
        hasMore = false;
      }
    }

    res.json(allData);
  } catch (err: any) {
    console.error('Holded Credit Notes Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/invoices/:id/pdf', async (req, res) => {
  const { id } = req.params;
  console.log(`GET /api/holded/invoices/${id}/pdf`);
  
  try {
    // docType is 'invoice' for these documents
    const response = await fetch(`https://api.holded.com/api/invoicing/v1/documents/invoice/${id}/pdf`, {
      headers: {
        'key': HOLDED_API_KEY,
        'accept': 'application/json'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Holded PDF Error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    console.log('Holded PDF Response keys:', Object.keys(data));
    res.json(data);
  } catch (err: any) {
    console.error('Holded PDF Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/invoices/:id', async (req, res) => {
  const { id } = req.params;
  console.log(`GET /api/holded/invoices/${id}`);
  
  try {
    const response = await fetch(`https://api.holded.com/api/invoicing/v1/documents/invoice/${id}`, {
      headers: {
        'key': HOLDED_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Holded Invoice Detail Error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    console.error('Holded Invoice Detail Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/salesorders', async (req, res) => {
  console.log('GET /api/holded/salesorders');
  try {
    const response = await fetch('https://api.holded.com/api/invoicing/v1/documents/salesorder', {
      headers: {
        'key': HOLDED_API_KEY,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Holded API Error: ${response.status} ${errorText}`);
    }
    
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    console.error('Holded Sales Orders Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/products', async (req, res) => {
  console.log('GET /api/holded/products');
  try {
    const response = await fetch('https://api.holded.com/api/invoicing/v1/products', {
      headers: {
        'key': HOLDED_API_KEY,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Holded API Error: ${response.status} ${errorText}`);
    }
    
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    console.error('Holded Products Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/holded/products/:id', async (req, res) => {
  const { id } = req.params;
  console.log(`GET /api/holded/products/${id}`);
  try {
    const response = await fetch(`https://api.holded.com/api/invoicing/v1/products/${id}`, {
      headers: {
        'key': HOLDED_API_KEY,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Holded API Error: ${response.status} ${errorText}`);
    }
    
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    console.error(`Holded Product ${id} Error:`, err);
    res.status(500).json({ error: err.message });
  }
});

// 2. Get Production Data (Mock query for now, assuming table name)
app.get('/api/production', async (req, res) => {
  try {
    const result = await getProductionDataQuery();
    res.json(result.recordset);
  } catch (err: any) {
    console.error('SQL Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 2. Get Database Schema
app.get('/api/schema', async (req, res) => {
  try {
    const schemaResult = await getSchemaQuery();
    
    const schemaSummary = schemaResult.recordset.reduce((acc: any, row: any) => {
      if (!acc[row.TABLE_NAME]) acc[row.TABLE_NAME] = [];
      acc[row.TABLE_NAME].push(`${row.COLUMN_NAME} (${row.DATA_TYPE})`);
      return acc;
    }, {});

    res.json({ schema: JSON.stringify(schemaSummary, null, 2) });
  } catch (err: any) {
    console.error('Schema Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 3. Execute SQL Query
app.post('/api/query', async (req, res) => {
  const { query } = req.body;
  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  try {
    console.log('Executing SQL:', query);
    const sqlResult = await sql.query(query);
    res.json({ results: sqlResult.recordset });
  } catch (err: any) {
    console.error('Query Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 3. Specific Simple Query Endpoint
app.post('/api/queries/pesadas', async (req, res) => {
  const { ejercicioPedido, seriePedido, numeroPedido } = req.body;
  if (!ejercicioPedido || !seriePedido || !numeroPedido) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }

  try {
    const result = await getPesadasQuery(ejercicioPedido, seriePedido, numeroPedido);
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Pesadas Query Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 3.1 Get Order Lines Endpoint
app.get('/api/orders/lines', async (req, res) => {
  const { ejercicioPedido, seriePedido, numeroPedido } = req.query;
  
  if (!ejercicioPedido || !seriePedido || !numeroPedido) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }

  try {
    const result = await getOrderLinesQuery(Number(ejercicioPedido), String(seriePedido), Number(numeroPedido));
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Order Lines Query Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 3.2 Get Pesadas Linea Endpoint
app.get('/api/orders/pesadas-linea', async (req, res) => {
  const { ejercicioPedido, seriePedido, numeroPedido, codigoArticulo } = req.query;
  
  if (!ejercicioPedido || !seriePedido || !numeroPedido || !codigoArticulo) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }

  try {
    const result = await getPesadasLineaQuery(Number(ejercicioPedido), String(seriePedido), Number(numeroPedido), String(codigoArticulo));
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Pesadas Linea Query Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 3.3 Cambiar Pesadas a otro pedido
app.post('/api/orders/cambiar-pesadas', async (req, res) => {
  const { 
    ejercicioOrigen, serieOrigen, numeroOrigen, lineaOrigen, codigoArticulo,
    ejercicioDestino, serieDestino, numeroDestino 
  } = req.body;

  if (!ejercicioOrigen || !serieOrigen || !numeroOrigen || !lineaOrigen || !codigoArticulo || !ejercicioDestino || !serieDestino || !numeroDestino) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }

  try {
    await cambiarPesadasPedido(
      Number(ejercicioOrigen), String(serieOrigen), Number(numeroOrigen), String(lineaOrigen), String(codigoArticulo),
      Number(ejercicioDestino), String(serieDestino), Number(numeroDestino)
    );
    res.json({ success: true, message: 'Pesadas cambiadas correctamente' });
  } catch (err: any) {
    console.error('Cambiar Pesadas Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 4. Calicer Query Endpoint
app.get('/api/queries/calicer', async (req, res) => {
  const year = req.query.year ? parseInt(req.query.year as string) : 2026;
  
  try {
    const result = await getCalicerQuery(year);
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Calicer Query Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5. Clear Orders Endpoint (Legacy)
app.post('/api/clear-orders', async (req, res) => {
  try {
    const result = await getClearOrdersQuery();
    res.json({ success: true, rowsAffected: result.rowsAffected[0] });
  } catch (err: any) {
    console.error('Clear Orders Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.1 Get Pending Orders Endpoint
app.get('/api/orders/pending', async (req, res) => {
  const sent = req.query.sent === 'true';
  const year = req.query.year ? parseInt(req.query.year as string) : new Date().getFullYear();
  try {
    const result = await getPendingOrdersQuery(sent, year);
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Pending Orders Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.1.1 Get Reservas Endpoint
app.get('/api/orders/reservas', async (req, res) => {
  try {
    const result = await getReservasQuery();
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Reservas Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.1.2 Get DEPC Data
app.get('/api/depc', async (req, res) => {
  const { ejercicio, serie, numero } = req.query;
  if (!ejercicio || !serie || !numero) {
    return res.status(400).json({ error: 'Faltan parámetros: ejercicio, serie, numero' });
  }
  try {
    const result = await getDEPCQuery(Number(ejercicio), String(serie), Number(numero));
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get DEPC Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.2 Update Selected Orders Endpoint
app.post('/api/orders/clear-selected', async (req, res) => {
  const { orders } = req.body;
  if (!orders || !Array.isArray(orders) || orders.length === 0) {
    return res.status(400).json({ error: 'No orders provided' });
  }

  try {
    const result = await updateSelectedOrdersQuery(orders);
    res.json({ success: true, rowsAffected: result.rowsAffected[0] });
  } catch (err: any) {
    console.error('Update Selected Orders Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/orders/close-and-print-selected', async (req, res) => {
  const { orders } = req.body;
  if (!orders || !Array.isArray(orders) || orders.length === 0) {
    return res.status(400).json({ error: 'No orders provided' });
  }

  try {
    const result = await closeAndPrintSelectedOrdersQuery(orders);
    res.json({ success: true, rowsAffected: result.rowsAffected[0] });
  } catch (err: any) {
    console.error('Close and Print Selected Orders Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.3 Force Close Order Endpoint
app.post('/api/orders/force-close', async (req, res) => {
  const { empresa, ejercicio, serie, numero } = req.body;
  if (!empresa || !ejercicio || !serie || !numero) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }
  try {
    await forceCloseOrderQuery(empresa, ejercicio, serie, numero);
    res.json({ success: true });
  } catch (err: any) {
    console.error('Force Close Order Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.4 Revert Order to Pending Endpoint
app.post('/api/orders/revert-pending', async (req, res) => {
  const { empresa, ejercicio, serie, numero } = req.body;
  if (!empresa || !ejercicio || !serie || !numero) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }
  try {
    await revertOrderToPendingQuery(empresa, ejercicio, serie, numero);
    res.json({ success: true });
  } catch (err: any) {
    console.error('Revert Order to Pending Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5.5 Reopen Order Endpoint
app.post('/api/orders/reopen', async (req, res) => {
  const { empresa, ejercicio, serie, numero } = req.body;
  if (!empresa || !ejercicio || !serie || !numero) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }
  try {
    await reopenOrderQuery(empresa, ejercicio, serie, numero);
    res.json({ success: true });
  } catch (err: any) {
    console.error('Reopen Order Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 6. ASICI Query Endpoint
app.post('/api/queries/asici', async (req, res) => {
  const { cliente, fechaDesde, fechaHasta } = req.body;
  if (!cliente || !fechaDesde || !fechaHasta) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }
  
  try {
    const result = await getAsiciQuery(cliente, fechaDesde, fechaHasta);
    res.json(result.recordset);
  } catch (err: any) {
    console.error('ASICI Query Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/trazabilidad/corregir-precinto', async (req, res) => {
  const { lote, tipo, precinto } = req.body;
  if (!lote || !tipo || !precinto) {
    return res.status(400).json({ error: 'Faltan parámetros' });
  }
  
  try {
    const { corregirPrecintoLote } = await import('./sqlQueries.js');
    const result = await corregirPrecintoLote(lote, tipo, precinto);
    res.json(result);
  } catch (err: any) {
    console.error('Corregir Precinto Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 8. Agentes Endpoints
app.get('/api/agentes', async (req, res) => {
  try {
    const result = await getAgentesQuery();
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Agentes Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agentes', async (req, res) => {
  const { name, email, phone, active } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });
  try {
    const result = await createAgenteQuery(name, email || '', phone || '', active !== false);
    res.json(result.recordset[0]);
  } catch (err: any) {
    console.error('Create Agente Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/agentes/:id', async (req, res) => {
  const { id } = req.params;
  const { name, email, phone, active } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });
  try {
    const result = await updateAgenteQuery(parseInt(id), name, email || '', phone || '', active !== false);
    if (result.recordset.length === 0) return res.status(404).json({ error: 'Agente no encontrado' });
    res.json(result.recordset[0]);
  } catch (err: any) {
    console.error('Update Agente Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/agentes/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await deleteAgenteQuery(parseInt(id));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete Agente Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 9. Reglas de Comision Endpoints
app.get('/api/comisiones/overrides/:agentId', async (req, res) => {
  try {
    const { agentId } = req.params;
    const result = await getComisionesOverridesQuery(parseInt(agentId));
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Comisiones Overrides Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/comisiones/overrides', async (req, res) => {
  try {
    const { invoiceId, agentId, removed, linesData } = req.body;
    await upsertComisionesOverrideQuery(invoiceId, parseInt(agentId), !!removed, linesData ? JSON.stringify(linesData) : null);
    res.json({ success: true });
  } catch (err: any) {
    console.error('Upsert Comisiones Overrides Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/comisiones/overrides/:agentId/:invoiceId', async (req, res) => {
  try {
    const { agentId, invoiceId } = req.params;
    await deleteComisionesOverrideQuery(invoiceId, parseInt(agentId));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete Comisiones Override Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/comisiones/overrides/:agentId', async (req, res) => {
  try {
    const { agentId } = req.params;
    await deleteAllComisionesOverridesQuery(parseInt(agentId));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete All Comisiones Overrides Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/comisiones/adjustments/:agentId/:year', async (req, res) => {
  try {
    const { agentId, year } = req.params;
    const result = await getComisionesAdjustmentsQuery(parseInt(agentId), parseInt(year));
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Comisiones Adjustments Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/comisiones/adjustments', async (req, res) => {
  try {
    const { agentId, year, quarter, amount, description } = req.body;
    await createComisionesAdjustmentQuery(parseInt(agentId), parseInt(year), quarter, parseFloat(amount), description);
    res.json({ success: true });
  } catch (err: any) {
    console.error('Create Comisiones Adjustment Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/comisiones/adjustments/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`DELETE /api/comisiones/adjustments/${id}`);
    await deleteComisionesAdjustmentQuery(parseInt(id));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete Comisiones Adjustment Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/comisiones/reglas', async (req, res) => {
  try {
    const result = await getReglasComisionQuery();
    const rules = result.recordset.map(r => ({
      ...r,
      category: r.category ? r.category.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
      formats: r.format ? r.format.split(',').map((s: string) => s.trim()).filter(Boolean) : []
    }));
    res.json(rules);
  } catch (err: any) {
    console.error('Get Reglas Comision Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/comisiones/reglas', async (req, res) => {
  const { agentId, category, formats, rate, startDate, endDate, description, clientId, clientName } = req.body;
  if (!agentId || rate === undefined) return res.status(400).json({ error: 'Agent ID and rate are required' });
  try {
    const catStr = Array.isArray(category) ? category.join(',') : (category || '');
    const formStr = Array.isArray(formats) ? formats.join(',') : (formats || '');
    const result = await createReglaComisionQuery(parseInt(agentId), catStr, formStr, parseFloat(rate), startDate, endDate, description || '', clientId, clientName);
    const r = result.recordset[0];
    res.json({
      ...r,
      category: r.category ? r.category.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
      formats: r.format ? r.format.split(',').map((s: string) => s.trim()).filter(Boolean) : []
    });
  } catch (err: any) {
    console.error('Create Regla Comision Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/comisiones/reglas/:id', async (req, res) => {
  const { id } = req.params;
  const { agentId, category, formats, rate, startDate, endDate, description, clientId, clientName } = req.body;
  if (!agentId || rate === undefined) return res.status(400).json({ error: 'Agent ID and rate are required' });
  try {
    const catStr = Array.isArray(category) ? category.join(',') : (category || '');
    const formStr = Array.isArray(formats) ? formats.join(',') : (formats || '');
    const result = await updateReglaComisionQuery(parseInt(id), parseInt(agentId), catStr, formStr, parseFloat(rate), startDate, endDate, description || '', clientId, clientName);
    const r = result.recordset[0];
    res.json({
      ...r,
      category: r.category ? r.category.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
      formats: r.format ? r.format.split(',').map((s: string) => s.trim()).filter(Boolean) : []
    });
  } catch (err: any) {
    console.error('Update Regla Comision Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/comisiones/reglas/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await deleteReglaComisionQuery(parseInt(id));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete Regla Comision Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/comisiones/sync', async (req, res) => {
  const { rules } = req.body;
  try {
    await syncReglasComisionQuery(rules);
    res.json({ success: true });
  } catch (err: any) {
    console.error('Sync Reglas Comision Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 10. Comisiones Calculadas Endpoints
app.get('/api/comisiones/calculadas/:agentId/:year', async (req, res) => {
  const { agentId, year } = req.params;
  try {
    const result = await sql.query`
      SELECT Id as id, AgenteId as agentId, Trimestre as quarter, Anio as year, 
             TotalComision as totalCommission, DetallesJson as detailsJson, FechaCalculo as calculatedAt
      FROM ComisionesCalculadas
      WHERE AgenteId = ${parseInt(agentId)} AND Anio = ${parseInt(year)}
    `;
    
    const parsed = result.recordset.map(r => ({
      ...r,
      details: JSON.parse(r.detailsJson)
    }));
    
    res.json(parsed);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/comisiones/calculadas', async (req, res) => {
  const { agentId, quarter, year, totalCommission, details } = req.body;
  if (!agentId || !quarter || !year || totalCommission === undefined || !details) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  
  try {
    const detailsJson = JSON.stringify(details);
    
    // Upsert logic
    await sql.query`
      MERGE ComisionesCalculadas AS target
      USING (SELECT ${agentId} as AgenteId, ${quarter} as Trimestre, ${year} as Anio) AS source
      ON (target.AgenteId = source.AgenteId AND target.Trimestre = source.Trimestre AND target.Anio = source.Anio)
      WHEN MATCHED THEN
        UPDATE SET TotalComision = ${totalCommission}, DetallesJson = ${detailsJson}, FechaCalculo = GETDATE()
      WHEN NOT MATCHED THEN
        INSERT (AgenteId, Trimestre, Anio, TotalComision, DetallesJson)
        VALUES (source.AgenteId, source.Trimestre, source.Anio, ${totalCommission}, ${detailsJson});
    `;
    
    res.json({ success: true });
  } catch (err: any) {
    console.error('Error saving calculated commission:', err);
    res.status(500).json({ error: err.message });
  }
});

// 11. Tarifas Endpoints
app.get('/api/tarifas', async (req, res) => {
  try {
    const result = await getTarifasQuery();
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Tarifas Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tarifas', async (req, res) => {
  const { name, description, active } = req.body;
  try {
    const result = await createTarifaQuery(name, description, active);
    res.json(result.recordset[0]);
  } catch (err: any) {
    console.error('Create Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/tarifas/:id', async (req, res) => {
  const { id } = req.params;
  const { name, description, active } = req.body;
  try {
    const result = await updateTarifaQuery(parseInt(id), name, description, active);
    res.json(result.recordset[0]);
  } catch (err: any) {
    console.error('Update Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/tarifas/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await deleteTarifaQuery(parseInt(id));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 11. Precios Tarifa Endpoints
app.get('/api/precios-tarifa', async (req, res) => {
  const tarifaId = req.query.tarifaId ? parseInt(req.query.tarifaId as string) : undefined;
  try {
    const result = await getPreciosTarifaQuery(tarifaId);
    res.json(result.recordset);
  } catch (err: any) {
    console.error('Get Precios Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/precios-tarifa', async (req, res) => {
  const { tarifaId, productId, precio } = req.body;
  try {
    const result = await updatePrecioTarifaQuery(tarifaId, productId, precio);
    res.json(result.recordset[0]);
  } catch (err: any) {
    console.error('Update Precio Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/precios-tarifa/bulk', async (req, res) => {
  const { precios } = req.body;
  try {
    for (const p of precios) {
      await updatePrecioTarifaQuery(p.tarifaId, p.productId, p.precio);
    }
    res.json({ success: true });
  } catch (err: any) {
    console.error('Bulk Update Precio Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/precios-tarifa/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await deletePrecioTarifaQuery(parseInt(id));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Delete Precio Tarifa Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 7. Get Filtered Logs
app.post('/api/logs', async (req, res) => {
  const { orderNumber } = req.body;
  if (!orderNumber) {
    return res.status(400).json({ error: 'Order number is required' });
  }

  try {
    // Fetch the CSV export of the Google Sheet
    const sheetUrl = 'https://docs.google.com/spreadsheets/d/1fxlpi44GeAF_PE4Qz2gf8hyD5xBBYZHvFyYnXDQrdzY/export?format=csv&gid=528103335';
    const sheetRes = await fetch(sheetUrl);
    
    if (!sheetRes.ok) {
      throw new Error('No se pudo acceder al documento de logs.');
    }
    
    const csvText = await sheetRes.text();
    const lines = csvText.split('\n');
    
    if (lines.length === 0) {
      return res.json({ logs: null, message: 'El documento de logs está vacío.' });
    }

    const header = lines[0];
    // Filter lines that contain the order number (case-insensitive)
    const searchTerm = orderNumber.toLowerCase();
    const filteredLines = lines.filter(line => line.toLowerCase().includes(searchTerm));

    if (filteredLines.length === 0) {
      return res.json({ logs: null, message: `No he encontrado ningún registro en los logs para el pedido **${orderNumber}**.` });
    }

    const logsForGemini = [header, ...filteredLines].join('\n');
    res.json({ logs: logsForGemini });

  } catch (err: any) {
    console.error('Logs Error:', err);
    res.status(500).json({ error: err.message });
  }
});

import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

// Helper function to sign Miravia API requests
function signMiraviaRequest(apiPath: string, params: Record<string, string>, appSecret: string): string {
  // 1. Sort all request parameters (excluding sign) by key
  const sortedKeys = Object.keys(params).sort();
  
  // 2. Concatenate the sorted parameters and their values
  let signString = apiPath;
  for (const key of sortedKeys) {
    signString += key + params[key];
  }
  
  // 3. Generate HMAC-SHA256 signature
  const hmac = crypto.createHmac('sha256', appSecret);
  hmac.update(signString);
  return hmac.digest('hex').toUpperCase();
}

// Global cache for Miravia access token
let cachedMiraviaAccessToken = '50000101512c15ldirBVQl7j1c2143adExhsxYEGgNKzlVSneznpwcvPWxxQRY2';
let cachedMiraviaRefreshToken = process.env.MIRAVIA_REFRESH_TOKEN || '50001100612rc0hLesiLlwWu19df1f12ThC6lYEIsdVskBBEr6Ps1eHEuo7HMV7';
let tokenExpirationTime = Date.now() + (1209600 * 1000); // 14 días de validez inicial

// Helper function to dynamically generate/refresh Miravia access token
async function getMiraviaAccessToken(appKey: string, appSecret: string): Promise<string> {
  const refreshToken = cachedMiraviaRefreshToken;

  // Si el usuario ha puesto el access token fijo en el .env, lo usamos temporalmente si no hay refresh token
  if (process.env.MIRAVIA_ACCESS_TOKEN && !refreshToken) {
    return process.env.MIRAVIA_ACCESS_TOKEN;
  }

  if (!refreshToken) {
    throw new Error("AUTH_REQUIRED: No hay refresh token disponible. Es necesario vincular la cuenta.");
  }

  // Si tenemos un token cacheado y no ha expirado (damos un margen de 5 minutos)
  if (cachedMiraviaAccessToken && Date.now() < tokenExpirationTime - 300000) {
    return cachedMiraviaAccessToken;
  }

  console.log("Generando nuevo access token de Miravia usando refresh token...");
  const apiPath = "/auth/token/refresh";
  const timestamp = Date.now().toString();

  const params: Record<string, string> = {
    app_key: appKey,
    timestamp: timestamp,
    sign_method: "sha256",
    refresh_token: refreshToken
  };

  const sign = signMiraviaRequest(apiPath, params, appSecret);
  params.sign = sign;

  const queryString = new URLSearchParams(params).toString();
  const url = `https://api.miravia.es/rest${apiPath}?${queryString}`;

  try {
    // La API de Miravia requiere POST para refrescar el token
    const response = await fetch(url, { method: 'POST' });
    const data = await response.json();
    
    if (data.code !== "0" && data.code !== 0) {
      throw new Error(`Miravia Token Refresh Error: ${data.message || JSON.stringify(data)}`);
    }
    
    cachedMiraviaAccessToken = data.access_token;
    if (data.refresh_token) {
      cachedMiraviaRefreshToken = data.refresh_token; // Actualizamos el refresh token si nos dan uno nuevo
    }
    // expires_in suele venir en segundos (ej. 2592000 para 30 días)
    const expiresIn = data.expires_in || 86400; 
    tokenExpirationTime = Date.now() + (expiresIn * 1000);
    
    console.log("Access token generado correctamente.");
    return cachedMiraviaAccessToken;
  } catch (error) {
    console.error("Error generando token de Miravia:", error);
    throw error;
  }
}

// Endpoint para importar el token directamente desde el JSON del Excel
app.post('/api/miravia/import-token', async (req, res) => {
  try {
    const { jsonString } = req.body;
    
    // Intentamos parsear el string que pegue el usuario
    let data;
    try {
      data = JSON.parse(jsonString);
    } catch (e) {
      throw new Error("El texto introducido no es un JSON válido. Asegúrate de copiar todo el contenido de la celda A1.");
    }

    if (!data.refresh_token) {
      throw new Error("El JSON no contiene la propiedad 'refresh_token'.");
    }

    // Guardamos los tokens en memoria
    cachedMiraviaRefreshToken = data.refresh_token;
    if (data.access_token) {
      cachedMiraviaAccessToken = data.access_token;
    }
    
    // Le damos un tiempo de expiración por defecto para forzar el refresco pronto si es necesario
    tokenExpirationTime = Date.now() + (3600 * 1000); 
    
    console.log("Token importado desde Excel con éxito.");
    res.json({ success: true });
  } catch (err: any) {
    console.error('Miravia Import Error:', err);
    res.status(400).json({ error: err.message });
  }
});

// Endpoint para intercambiar el código de autorización por los tokens iniciales
app.post('/api/miravia/auth', async (req, res) => {
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'El código de autorización es obligatorio' });
  }

  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;

  if (!appKey || !appSecret) {
    return res.status(500).json({ error: 'Miravia credentials are not configured in the server.' });
  }

  const apiPath = "/auth/token/create";
  const timestamp = Date.now().toString();

  const params: Record<string, string> = {
    app_key: appKey,
    timestamp: timestamp,
    sign_method: "sha256",
    code: code
  };

  const sign = signMiraviaRequest(apiPath, params, appSecret);
  params.sign = sign;

  const queryString = new URLSearchParams(params).toString();
  const url = `https://api.miravia.es/rest${apiPath}?${queryString}`;

  try {
    const response = await fetch(url, { method: 'POST' });
    const data = await response.json();
    
    if (data.code !== "0" && data.code !== 0) {
      throw new Error(`Error de Autorización Miravia: ${data.message || JSON.stringify(data)}`);
    }
    
    // Guardamos los tokens en memoria
    cachedMiraviaAccessToken = data.access_token;
    cachedMiraviaRefreshToken = data.refresh_token;
    const expiresIn = data.expires_in || 86400; 
    tokenExpirationTime = Date.now() + (expiresIn * 1000);
    
    console.log("Cuenta de Miravia vinculada con éxito. Tokens guardados en memoria.");
    res.json({ success: true });
  } catch (err: any) {
    console.error('Miravia Auth Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Endpoint para exportar pedidos de Miravia a Excel
app.get('/api/miravia/orders/export', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;

  if (!appKey || !appSecret) {
    return res.status(500).json({ error: 'Miravia credentials are not configured in the server.' });
  }

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/orders/get';
    const timestamp = Date.now().toString();
    
    // Fetch all orders (simplified for now, might need pagination)
    const ninetyDaysAgo = Math.floor((Date.now() - 90 * 24 * 60 * 60 * 1000) / 1000).toString();
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: timestamp,
      sign_method: 'sha256',
      access_token: accessToken,
      limit: '100',
      offset: '0',
      created_after: ninetyDaysAgo
    };

    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;

    const queryString = new URLSearchParams(params).toString();
    const url = `https://api.miravia.es/rest${apiPath}?${queryString}`;

    const response = await fetch(url, { method: 'GET' });
    const data = await response.json();
    
    if (data.code !== "0" && data.code !== 0) {
      throw new Error(`Miravia API Error: ${data.message || JSON.stringify(data)}`);
    }

    const orders = data.data?.orders || [];
    
    // Fetch items for all orders
    if (orders.length > 0) {
      const orderIds = orders.map((o: any) => o.order_id);
      const itemsApiPath = '/orders/items/get';
      const itemsParams: Record<string, string> = {
        app_key: appKey,
        timestamp: Date.now().toString(),
        sign_method: 'sha256',
        access_token: accessToken,
        order_ids: JSON.stringify(orderIds)
      };
      
      const itemsSign = signMiraviaRequest(itemsApiPath, itemsParams, appSecret);
      itemsParams.sign = itemsSign;
      
      const itemsQueryString = new URLSearchParams(itemsParams).toString();
      const itemsUrl = `https://api.miravia.es/rest${itemsApiPath}?${itemsQueryString}`;
      
      const itemsResponse = await fetch(itemsUrl, { method: 'GET' });
      const itemsData = await itemsResponse.json();
      
      if (itemsData.code === "0" || itemsData.code === 0) {
        const itemsByOrderId = new Map();
        if (itemsData.data && Array.isArray(itemsData.data)) {
          itemsData.data.forEach((d: any) => {
            itemsByOrderId.set(d.order_id.toString(), d.order_items || []);
          });
        }
        orders.forEach((order: any) => {
          order.items = itemsByOrderId.get(order.order_id.toString()) || [];
        });
      }
    }

    res.json(orders);
  } catch (err: any) {
    console.error('Miravia Export Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// --- Miravia TEST Endpoints ---

// Helper to get all orders for a year (paginated)
async function getAllMiraviaOrders(appKey: string, appSecret: string, accessToken: string, year: string) {
  let allOrders: any[] = [];
  let offset = 0;
  const limit = 100;
  let hasMore = true;

  while (hasMore && offset < 5000) {
    const apiPath = '/orders/get';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken,
      created_after: `${year}-01-01T00:00:00+00:00`,
      created_before: `${year}-12-31T23:59:59+00:00`,
      limit: limit.toString(),
      offset: offset.toString(),
      sort_direction: 'ASC'
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.code && data.code !== "0") {
      throw new Error(data.message || JSON.stringify(data));
    }

    const orders = data.data?.orders || [];
    allOrders = allOrders.concat(orders);

    if (orders.length < limit) {
      hasMore = false;
    } else {
      offset += limit;
    }
  }
  return allOrders;
}

// 1. Get Orders (Paginated)
app.get('/api/miravia/test/orders', async (req, res) => {
  const { year = '2026' } = req.query;
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const orders = await getAllMiraviaOrders(appKey, appSecret, accessToken, year as string);
    res.json(orders);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 1.1 Get Order Items (for orders in a year)
app.get('/api/miravia/test/order-items', async (req, res) => {
  const { year = '2026' } = req.query;
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const orders = await getAllMiraviaOrders(appKey, appSecret, accessToken, year as string);
    
    let allItems: any[] = [];
    // Fetch items batch by batch (one by one as per docs)
    for (const order of orders) {
      const apiPath = '/order/items/get';
      const params: Record<string, string> = {
        app_key: appKey,
        timestamp: Date.now().toString(),
        sign_method: 'sha256',
        access_token: accessToken,
        order_id: order.order_id.toString()
      };
      const sign = signMiraviaRequest(apiPath, params, appSecret);
      params.sign = sign;
      const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.data) {
        // data.data is usually an array of items for that order
        const items = Array.isArray(data.data) ? data.data : [data.data];
        allItems = allItems.concat(items.map((it: any) => ({ ...it, parent_order_id: order.order_id })));
      }
    }
    res.json(allItems);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Get Payout Status (Paginated)
app.get('/api/miravia/test/payouts', async (req, res) => {
  const { year = '2026' } = req.query;
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/finance/payout/status/get';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken,
      created_after: `${year}-01-01T00:00:00+00:00`
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data.data || data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Query Transaction Details (Split into 180-day chunks)
app.get('/api/miravia/test/transactions', async (req, res) => {
  const { year = '2026' } = req.query;
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    
    // Split year into two 6-month periods to satisfy 180-day limit
    const periods = [
      { start: `${year}-01-01`, end: `${year}-06-30` },
      { start: `${year}-07-01`, end: `${year}-12-31` }
    ];
    
    let allTransactions: any[] = [];
    
    for (const period of periods) {
      const apiPath = '/finance/transaction/details/get';
      const params: Record<string, string> = {
        app_key: appKey,
        timestamp: Date.now().toString(),
        sign_method: 'sha256',
        access_token: accessToken,
        start_time: period.start,
        end_time: period.end,
        limit: '500',
        offset: '0'
      };
      const sign = signMiraviaRequest(apiPath, params, appSecret);
      params.sign = sign;
      const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.data) {
        allTransactions = allTransactions.concat(data.data);
      }
    }
    res.json(allTransactions);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Get Seller Info
app.get('/api/miravia/test/seller', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/seller/get';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Get Shipping Permission
app.get('/api/miravia/test/shipping-permission', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/seller/shipping_permission/get';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Get Products
app.get('/api/miravia/test/products', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/v2/product/get';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken,
      filter: 'all'
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Get Feeds
app.get('/api/miravia/test/feeds', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/feed/getFeed';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Reverse Reason List
app.get('/api/miravia/test/reverse-reasons', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/order/reverse/reason/list';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 9. SOF Providers
app.get('/api/miravia/test/sof-providers', async (req, res) => {
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;
  if (!appKey || !appSecret) return res.status(500).json({ error: 'Miravia credentials not configured' });

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);
    const apiPath = '/order/shipment/sof/providers/get';
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: Date.now().toString(),
      sign_method: 'sha256',
      access_token: accessToken
    };
    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;
    const url = `https://api.miravia.es/rest${apiPath}?${new URLSearchParams(params).toString()}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Miravia API Integration
app.get('/api/miravia/orders', async (req, res) => {
  // Usamos las credenciales del .env o las que me pasaste por defecto si no están
  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;

  if (!appKey || !appSecret) {
    return res.status(500).json({ error: 'Miravia credentials are not configured in the server.' });
  }

  try {
    // Generamos o recuperamos el access token dinámicamente
    // NOTA: getMiraviaAccessToken lanzará un error claro si falta el MIRAVIA_REFRESH_TOKEN
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);

    // Llamada REAL a la API de Miravia
    const apiPath = '/orders/get';
    const timestamp = Date.now().toString();
    
    const statusQuery = req.query.status as string || 'ready_to_ship';
    const createdAfterQuery = req.query.created_after as string;

    // Calculamos la fecha de hace 90 días por defecto si no viene en la query
    let createdAfter = createdAfterQuery;
    if (!createdAfter) {
      const start = new Date();
      start.setDate(start.getDate() - 90);
      createdAfter = start.toISOString().split('T')[0] + "T00:00:00+00:00";
    } else if (createdAfter.length === 10) {
      // Si solo viene YYYY-MM-DD, le añadimos la hora
      createdAfter = createdAfter + "T00:00:00+00:00";
    }
    
    // Parámetros básicos para obtener los pedidos
    const params: Record<string, string> = {
      app_key: appKey,
      timestamp: timestamp,
      sign_method: 'sha256',
      access_token: accessToken,
      created_after: createdAfter,
      limit: '100',
      offset: '0',
    };

    if (statusQuery !== 'all') {
      params.status = statusQuery;
    }

    const sign = signMiraviaRequest(apiPath, params, appSecret);
    params.sign = sign;

    const queryString = new URLSearchParams(params).toString();
    const url = `https://api.miravia.es/rest${apiPath}?${queryString}`;

    const response = await fetch(url, { method: 'GET' });
    const data = await response.json();
    
    if (data.code !== "0" && data.code !== 0) {
      throw new Error(`Miravia API Error: ${data.message || JSON.stringify(data)}`);
    }

    // Si la API no devuelve un array de orders, lo inicializamos vacío para que no rompa el frontend
    const orders = data.data?.orders || [];
    
    // Obtener los items para cada pedido
    if (orders.length > 0) {
      // La API permite consultar múltiples order_ids a la vez (normalmente hasta 50)
      // Vamos a agruparlos en lotes de 50
      const batchSize = 50;
      for (let i = 0; i < orders.length; i += batchSize) {
        const batch = orders.slice(i, i + batchSize);
        const orderIds = batch.map((o: any) => o.order_id);
        
        const itemsApiPath = '/orders/items/get';
        const itemsParams: Record<string, string> = {
          app_key: appKey,
          timestamp: Date.now().toString(),
          sign_method: 'sha256',
          access_token: accessToken,
          order_ids: JSON.stringify(orderIds)
        };
        
        const itemsSign = signMiraviaRequest(itemsApiPath, itemsParams, appSecret);
        itemsParams.sign = itemsSign;
        
        const itemsQueryString = new URLSearchParams(itemsParams).toString();
        const itemsUrl = `https://api.miravia.es/rest${itemsApiPath}?${itemsQueryString}`;
        
        try {
          const itemsResponse = await fetch(itemsUrl, { method: 'GET' });
          const itemsData = await itemsResponse.json();
          
          if (itemsData.code === "0" || itemsData.code === 0) {
            // itemsData.data es un array de objetos, cada uno con order_id y order_items
            const itemsByOrderId = new Map();
            if (Array.isArray(itemsData.data)) {
              itemsData.data.forEach((d: any) => {
                itemsByOrderId.set(d.order_id.toString(), d.order_items || []);
              });
            }
            
            // Asignamos los items a cada pedido del lote
            batch.forEach((order: any) => {
              order.items = itemsByOrderId.get(order.order_id.toString()) || [];
            });
          } else {
            console.error('Error fetching items batch:', itemsData);
            batch.forEach((order: any) => { order.items = []; });
          }
        } catch (e) {
          console.error('Network error fetching items batch:', e);
          batch.forEach((order: any) => { order.items = []; });
        }
      }
    }

    return res.json({ mock: false, orders: orders });
  } catch (err: any) {
    console.error('Miravia API Error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/miravia/generate-labels', async (req, res) => {
  const { orders } = req.body;
  if (!orders || !Array.isArray(orders) || orders.length === 0) {
    return res.status(400).json({ error: 'Orders array is required' });
  }

  const appKey = process.env.MIRAVIA_APP_KEY;
  const appSecret = process.env.MIRAVIA_APP_SECRET;

  if (!appKey || !appSecret) {
    return res.status(500).json({ error: 'Miravia credentials are not configured in the server.' });
  }

  try {
    const accessToken = await getMiraviaAccessToken(appKey, appSecret);

    // 1. Identificar pedidos pendientes que necesitan ser marcados como "Ready to Ship" (fulfill)
    const pendingOrderItemIds: number[] = [];
    orders.forEach(order => {
      // Miravia puede devolver el estado en 'status' o en 'statuses'
      const status = (order.status || (order.statuses && order.statuses[0]) || '').toLowerCase();
      if ((status === 'pending' || status === 'unpacked') && order.items && Array.isArray(order.items)) {
        order.items.forEach((item: any) => {
          if (item.order_item_id) {
            pendingOrderItemIds.push(Number(item.order_item_id));
          }
        });
      }
    });

    // 2. Fulfill los pedidos pendientes si los hay
    if (pendingOrderItemIds.length > 0) {
      const fulfillApiPath = '/v2/order/fulfill';
      const fulfillBatchSize = 50;
      
      for (let i = 0; i < pendingOrderItemIds.length; i += fulfillBatchSize) {
        const batchIds = pendingOrderItemIds.slice(i, i + fulfillBatchSize);
        const payloadObj = { order_item_ids: batchIds };
        
        const timestamp = Date.now().toString();
        const params: any = {
          app_key: appKey,
          timestamp: timestamp,
          sign_method: 'sha256',
          access_token: accessToken,
          payload: JSON.stringify(payloadObj)
        };

        const sign = signMiraviaRequest(fulfillApiPath, params, appSecret);
        params.sign = sign;

        const formBody = new URLSearchParams(params).toString();
        const fulfillUrl = `https://api.miravia.es/rest${fulfillApiPath}`;

        try {
          const fulfillResponse = await fetch(fulfillUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' },
            body: formBody
          });
          const fulfillData = await fulfillResponse.json();
          
          if (fulfillData.code !== "0" && fulfillData.code !== 0) {
            console.warn(`Miravia Fulfill Warning for batch ${i}: ${fulfillData.message || JSON.stringify(fulfillData)}`);
            // No lanzamos error aquí para intentar seguir con el resto, 
            // pero si falla el fulfill, probablemente el document/get también falle para esos items.
          }
        } catch (e) {
          console.error(`Error fulfilling batch ${i}:`, e);
        }
      }
      
      // Esperamos un poco para que Miravia procese el cambio de estado antes de pedir el documento
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // 3. Obtener los documentos (etiquetas) para todos los pedidos seleccionados
    const apiPath = '/order/document/get';
    
    // Extract all order_item_ids for the document request
    const orderItemIds: string[] = [];
    orders.forEach(order => {
      if (order.items && Array.isArray(order.items)) {
        order.items.forEach((item: any) => {
          if (item.order_item_id) {
            orderItemIds.push(item.order_item_id.toString());
          }
        });
      }
    });

    if (orderItemIds.length === 0) {
      throw new Error('No se encontraron order_item_ids en los pedidos seleccionados.');
    }

    const mergedPdf = await PDFDocument.create();
    const batchSize = 50; 
    
    for (let i = 0; i < orderItemIds.length; i += batchSize) {
      const batchIds = orderItemIds.slice(i, i + batchSize);
      
      const timestamp = Date.now().toString();
      const params: any = {
        app_key: appKey,
        timestamp: timestamp,
        sign_method: 'sha256',
        access_token: accessToken,
        doc_type: 'shippingLabel',
        order_item_ids: JSON.stringify(batchIds)
      };

      const sign = signMiraviaRequest(apiPath, params, appSecret);
      params.sign = sign;

      const queryString = new URLSearchParams(params).toString();
      const url = `https://api.miravia.es/rest${apiPath}?${queryString}`;

      const response = await fetch(url, { method: 'GET' });
      const data = await response.json();

      if (data.code !== "0" && data.code !== 0) {
        throw new Error(`Miravia API Error (Document): ${data.message || JSON.stringify(data)}`);
      }

      const base64Pdf = data.data?.document?.file;
      if (!base64Pdf) {
        throw new Error('La API de Miravia no devolvió ningún archivo PDF para estas etiquetas.');
      }

      const pdfBuffer = Buffer.from(base64Pdf, 'base64');
      const pdfDoc = await PDFDocument.load(pdfBuffer);
      const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    const mergedPdfBytes = await mergedPdf.save();
    const finalBase64Pdf = Buffer.from(mergedPdfBytes).toString('base64');

    res.json({ pdfBase64: finalBase64Pdf });

  } catch (err: any) {
    console.error('Miravia Label Generation Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Sendcloud API Endpoints
app.get('/api/sendcloud/parcels', async (req, res) => {
  try {
    const publicKey = process.env.SENDCLOUD_PUBLIC_KEY;
    const secretKey = process.env.SENDCLOUD_SECRET_KEY;

    if (!publicKey || !secretKey) {
      return res.status(400).json({ error: 'Sendcloud credentials not configured in secrets.' });
    }

    const auth = Buffer.from(`${publicKey}:${secretKey}`).toString('base64');
    const response = await fetch('https://panel.sendcloud.sc/api/v2/parcels', {
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Sendcloud API Error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    res.json(data.parcels || []);
  } catch (err: any) {
    console.error('Sendcloud Parcels Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Shopify Update Order (Release Hold)
app.post('/api/shopify/orders/:storeIndex/:orderId/release_hold', async (req, res) => {
  try {
    const { storeIndex, orderId } = req.params;
    const token = await getShopifyToken(storeIndex);
    const shopUrl = process.env[`SHOPIFY_STORE_${storeIndex}_URL`];

    if (!token || !shopUrl) {
      return res.status(400).json({ error: 'Shopify credentials not configured.' });
    }

    const cleanShopUrl = shopUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
    
    // First, find the fulfillment orders for this order
    const foUrl = `https://${cleanShopUrl}/admin/api/2024-01/orders/${orderId}/fulfillment_orders.json`;
    const foResponse = await fetch(foUrl, {
      headers: { 'X-Shopify-Access-Token': token, 'Content-Type': 'application/json' }
    });
    
    if (!foResponse.ok) {
      throw new Error(`Error fetching fulfillment orders: ${await foResponse.text()}`);
    }
    
    const foData = await foResponse.json();
    const heldFulfillmentOrder = foData.fulfillment_orders.find((fo: any) => fo.status === 'on_hold');
    
    if (!heldFulfillmentOrder) {
      return res.json({ success: true, message: 'No fulfillment order on hold found.' });
    }

    // Release the hold
    const releaseUrl = `https://${cleanShopUrl}/admin/api/2024-01/fulfillment_orders/${heldFulfillmentOrder.id}/release_hold.json`;
    const releaseResponse = await fetch(releaseUrl, {
      method: 'POST',
      headers: { 'X-Shopify-Access-Token': token, 'Content-Type': 'application/json' }
    });

    if (!releaseResponse.ok) {
      throw new Error(`Error releasing hold: ${await releaseResponse.text()}`);
    }

    res.json({ success: true });
  } catch (err: any) {
    console.error('Shopify Release Hold Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Sendcloud Retrieval by Order Name
app.get('/api/sendcloud/parcel_by_order/:orderName', async (req, res) => {
  try {
    const { orderName } = req.params;
    const publicKey = process.env.SENDCLOUD_PUBLIC_KEY;
    const secretKey = process.env.SENDCLOUD_SECRET_KEY;

    if (!publicKey || !secretKey) {
      return res.status(400).json({ error: 'Sendcloud credentials not configured.' });
    }

    const auth = Buffer.from(`${publicKey}:${secretKey}`).toString('base64');
    // We search in parcels using external_order_id or similar
    // Sendcloud API v2 doesn't have a direct search by external_order_id in the list endpoint easily without filtering
    // We'll fetch the last 100 parcels and find it
    const response = await fetch('https://panel.sendcloud.sc/api/v2/parcels?limit=100', {
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Sendcloud API Error: ${response.status}`);
    }

    const data = await response.json();
    const parcel = data.parcels.find((p: any) => p.external_order_id === orderName || p.order_number === orderName);
    
    if (!parcel) {
      return res.status(404).json({ error: 'Parcel not found in Sendcloud' });
    }

    res.json(parcel);
  } catch (err: any) {
    console.error('Sendcloud Parcel Search Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error Handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Global Error Handler:', err);
  res.status(500).json({ error: 'Internal Server Error', details: err.message });
});

// --- Server Startup Logic ---

async function startServer() {
  // 1. Lógica de producción/desarrollo (Middleware)
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
    console.log('Modo: PRODUCCIÓN (Sirviendo dist)');
  } else {
    console.log('Modo: DESARROLLO (Cargando Vite)');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  // 2. Arrancar el servidor
  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log('--- CONTROL DE ARRANQUE ---');
    console.log(`Puerto: ${PORT}`);
    console.log(`Entorno: ${process.env.NODE_ENV}`);
    console.log('Servidor escuchando correctamente. Cloud Run debería detectar el servicio ahora.');
  });

  // 3. Conexión a la base de datos totalmente aislada
  try {
    console.log('Intentando conectar a SQL Server en segundo plano...');
    await sql.connect(dbConfig);
    console.log('Base de datos conectada con éxito.');
    await initializeTables();
  } catch (err) {
    console.error('ERROR DB (No crítico para el arranque):', err);
  }
}

startServer();
