const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const funcStart = "  const handlePriceAssistant = async () => {";
const funcEnd = "  const handleLogout = () => {";
const startIdx = content.indexOf(funcStart);
const endIdx = content.indexOf(funcEnd);

if (startIdx !== -1 && endIdx !== -1) {
  content = content.substring(0, startIdx) + content.substring(endIdx);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully removed handlePriceAssistant');
} else {
  console.log('Could not find handlePriceAssistant');
}
