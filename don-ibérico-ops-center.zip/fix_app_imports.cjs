const fs = require('fs');

let content = fs.readFileSync('App.tsx', 'utf8');
content = content.replace("import Tarifas from './src/components/Tarifas/Tarifas';", "import Tarifas from './src/components/Tarifas/Tarifas';\nimport Sales from './src/components/Sales';");
fs.writeFileSync('App.tsx', content);
console.log('Fixed App.tsx imports');
