const fs = require('fs');
const content = fs.readFileSync('migrated_prompt_history/prompt_2026-02-17T08:29:40.219Z.json', 'utf8');
const json = JSON.parse(content);
console.log(Object.keys(json[0].payload));
if (json[0].payload.text) console.log(json[0].payload.text.substring(0, 200));
