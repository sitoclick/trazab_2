import http from 'http';

http.get('http://localhost:3000/api/holded/invoices?paid=1', (res) => {
  let data = '';
  res.on('data', (chunk) => data += chunk);
  res.on('end', () => {
    try {
      const orders = JSON.parse(data);
      console.log(`Total orders: ${orders.length}`);
      const sample = orders.find((o: any) => o.products && o.products.some((p: any) => p.name && p.name.includes('JAMÓN DE CEBO DE CAMPO IBÉRICO')));
      if (sample) {
        console.log('Found sample order:', sample.docNumber);
        const prod = sample.products.find((p: any) => p.name && p.name.includes('JAMÓN DE CEBO DE CAMPO IBÉRICO'));
        console.log('Product in order:', JSON.stringify(prod, null, 2));
      } else {
        console.log('Sample order not found.');
      }
    } catch (e) {
      console.error('Parse error:', e);
    }
  });
}).on('error', (err) => {
  console.error('Error:', err.message);
});
