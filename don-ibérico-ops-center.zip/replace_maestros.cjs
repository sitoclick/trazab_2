const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

// Add import
content = content.replace("import Agentes from './src/components/Agentes/Agentes';", "import Agentes from './src/components/Agentes/Agentes';\nimport Maestros from './src/components/Maestros/Maestros';");

// Remove Maestros state
const stateStart = "  const [maestrosSubTab, setMaestrosSubTab] = useState<'products' | 'clients'>('products');";
const stateEnd = "  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);\n  const [isProductDetailLoading, setIsProductDetailLoading] = useState(false);";
const startIdx1 = content.indexOf(stateStart);
const endIdx1 = content.indexOf(stateEnd);
if (startIdx1 !== -1 && endIdx1 !== -1) {
  content = content.substring(0, startIdx1) + content.substring(endIdx1 + stateEnd.length);
}

// Remove Maestros functions
const handleLoadContactsStart = "const handleLoadHoldedContacts = async () => {";
const handleLoadContactsEnd = "const handleLoadTarifas = async () => {";
const startIdx2 = content.indexOf(handleLoadContactsStart);
const endIdx2 = content.indexOf(handleLoadContactsEnd);
if (startIdx2 !== -1 && endIdx2 !== -1) {
  content = content.substring(0, startIdx2) + content.substring(endIdx2);
}

// Remove Maestros UI
const uiStart = "{activeTab === 'maestros' && (";
const uiEnd = "{activeTab === 'tarifas' && (";
const startIdx3 = content.indexOf(uiStart);
const endIdx3 = content.indexOf(uiEnd);
if (startIdx3 !== -1 && endIdx3 !== -1) {
  content = content.substring(0, startIdx3) + "{activeTab === 'maestros' && (\n          <Maestros user={user} />\n        )}\n\n        " + content.substring(endIdx3);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully replaced Maestros in App.tsx');
