import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER || 'holded',
  password: process.env.DB_PASSWORD || 'erp1234',
  server: process.env.DB_SERVER || 'sitoclick.ddns.net',
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE || 'CARNICAS',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 30000,
  },
};

async function run() {
  try {
    await sql.connect(dbConfig);
    
    const tarifaId = 1; // PVP - 2026

    // Insert missing products that start with P- or U-
    const result = await sql.query`
      INSERT INTO PreciosTarifa (TarifaId, ProductoId, PrecioTarifa)
      SELECT ${tarifaId}, CodigoArticulo, 0
      FROM Articulos
      WHERE CodigoEmpresa = 1 
        AND (CodigoArticulo LIKE 'P-%' OR CodigoArticulo LIKE 'U-%')
        AND NOT EXISTS (
          SELECT 1 FROM PreciosTarifa 
          WHERE TarifaId = ${tarifaId} AND ProductoId = Articulos.CodigoArticulo
        )
    `;
    
    console.log(`Inserted ${result.rowsAffected[0]} missing products into PVP - 2026`);
  } catch (err) {
    console.error(err);
  } finally {
    await (sql as any).close?.();
  }
}

run();
