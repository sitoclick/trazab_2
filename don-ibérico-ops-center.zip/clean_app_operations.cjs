const fs = require('fs');

let content = fs.readFileSync('App.tsx', 'utf8');

const statesToRemove = [
  "const [errorQueryInput, setErrorQueryInput] = useState('');",
  "const [errorChat, setErrorChat] = useState<{sender: 'user'|'bot', text: string}[]>([]);",
  "const [isErrorChatLoading, setIsErrorChatLoading] = useState(false);",
  "const errorChatEndRef = useRef<HTMLDivElement>(null);",
  "const [simpleQueryData, setSimpleQueryData] = useState<any[]>([]);",
  "const [simpleQueryLoading, setSimpleQueryLoading] = useState(false);",
  "const [simpleQueryError, setSimpleQueryError] = useState<string | null>(null);",
  "const [depcPedido, setDepcPedido] = useState('');",
  "const [depcAlbaran, setDepcAlbaran] = useState('');",
  "const [isGeneratingDEPC, setIsGeneratingDEPC] = useState(false);",
  "const [depcError, setDepcError] = useState<string | null>(null);",
  "const [corregirLote, setCorregirLote] = useState('');",
  "const [corregirTipo, setCorregirTipo] = useState('Jamon');",
  "const [corregirPrecinto, setCorregirPrecinto] = useState('');",
  "const [isCorrigiendoPrecinto, setIsCorrigiendoPrecinto] = useState(false);",
  "const [corregirPrecintoMessage, setCorregirPrecintoMessage] = useState<{type: 'success'|'error', text: string} | null>(null);",
  "const [isClearingOrders, setIsClearingOrders] = useState(false);",
  "const [isPickingReportLoading, setIsPickingReportLoading] = useState(false);",
  "const [isPickingSectionOpen, setIsPickingSectionOpen] = useState(false);",
  "const [showPickingPreview, setShowPickingPreview] = useState(false);",
  "const [pickingPreviewData, setPickingPreviewData] = useState<{ enteros: any[], resto: any[] } | null>(null);",
  "const [expandedPickingOrders, setExpandedPickingOrders] = useState<string[]>([]);",
  "const [clearOrdersMessage, setClearOrdersMessage] = useState<{type: 'success'|'error', text: string} | null>(null);",
  "const [pendingOrders, setPendingOrders] = useState<any[]>([]);",
  "const [selectedOrders, setSelectedOrders] = useState<string[]>([]);",
  "const [isLoadingPendingOrders, setIsLoadingPendingOrders] = useState(false);",
  "const [showPendingOrders, setShowPendingOrders] = useState(false);",
  "const [ordersMode, setOrdersMode] = useState<'pending' | 'sent' | 'reservas'>('pending');",
  "const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());",
  "const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);",
  "const [expandedOrders, setExpandedOrders] = useState<string[]>([]);",
  "const [orderLines, setOrderLines] = useState<Record<string, any[]>>({});",
  "const [isLoadingLines, setIsLoadingLines] = useState<Record<string, boolean>>({});",
  "const [expandedLines, setExpandedLines] = useState<string[]>([]);",
  "const [linePesadas, setLinePesadas] = useState<Record<string, any[]>>({});",
  "const [isLoadingLinePesadas, setIsLoadingLinePesadas] = useState<Record<string, boolean>>({});",
  "const [showAsiciForm, setShowAsiciForm] = useState(false);",
  "const [asiciCliente, setAsiciCliente] = useState('B75954792');",
  "const [asiciFechaDesde, setAsiciFechaDesde] = useState('2026-01-03');",
  "const [asiciFechaHasta, setAsiciFechaHasta] = useState('2026-01-20');",
  "const [showCalicerForm, setShowCalicerForm] = useState(false);",
  "const [calicerYear, setCalicerYear] = useState('2026');",
  "const [showPesadasForm, setShowPesadasForm] = useState(false);",
  "const [pesadasEjercicio, setPesadasEjercicio] = useState('2026');",
  "const [pesadasSerie, setPesadasSerie] = useState('ATR26');",
  "const [pesadasNumero, setPesadasNumero] = useState('3');",
  "const [showCambiarPesadasModal, setShowCambiarPesadasModal] = useState(false);",
  "const [isCambiandoPesadas, setIsCambiandoPesadas] = useState(false);",
  "const [cambiarPesadasError, setCambiarPesadasError] = useState<string | null>(null);"
];

statesToRemove.forEach(state => {
  content = content.replace(state + "\n", "");
  content = content.replace("  " + state + "\n", "");
});

// Remove pendingOrdersFilters block
const filtersStart = content.indexOf("  const [pendingOrdersFilters, setPendingOrdersFilters] = useState({");
if (filtersStart !== -1) {
  const filtersEnd = content.indexOf("  });", filtersStart) + 5;
  content = content.substring(0, filtersStart) + content.substring(filtersEnd);
}

// Remove cambiarPesadasData block
const dataStart = content.indexOf("  const [cambiarPesadasData, setCambiarPesadasData] = useState<{");
if (dataStart !== -1) {
  const dataEnd = content.indexOf("  } | null>(null);", dataStart) + 18;
  content = content.substring(0, dataStart) + content.substring(dataEnd);
}

// Remove cambiarPesadasDestino block
const destStart = content.indexOf("  const [cambiarPesadasDestino, setCambiarPesadasDestino] = useState({");
if (destStart !== -1) {
  const destEnd = content.indexOf("  });", destStart) + 5;
  content = content.substring(0, destStart) + content.substring(destEnd);
}

// Remove filteredOrders block
const filteredOrdersStart = content.indexOf("  const filteredOrders = useMemo(() => {");
if (filteredOrdersStart !== -1) {
  const filteredOrdersEnd = content.indexOf("  }, [pendingOrders, pendingOrdersFilters]);", filteredOrdersStart) + 44;
  content = content.substring(0, filteredOrdersStart) + content.substring(filteredOrdersEnd);
}

// Remove handleSort block
const handleSortStart = content.indexOf("  const handleSort = (key: string) => {");
if (handleSortStart !== -1) {
  const handleSortEnd = content.indexOf("  };", handleSortStart) + 4;
  content = content.substring(0, handleSortStart) + content.substring(handleSortEnd);
}

// Remove functions
const funcsToRemove = [
  "const handleOpenCambiarPesadas = (order: any, line: any) => {",
  "const handleCambiarPesadasSubmit = async (e: React.FormEvent) => {",
  "const handleRunPesadasQuery = async (e?: React.FormEvent) => {",
  "const handleRunCalicerQuery = async (e?: React.FormEvent) => {",
  "const handleRunAsiciQuery = async (e?: React.FormEvent) => {",
  "const handleGenerateAllAsici = async () => {",
  "const handleLoadPendingOrders = async (mode: 'pending' | 'sent' | 'reservas' = ordersMode) => {",
  "const handleCorregirPrecinto = async () => {",
  "const handleGenerateDEPC = async () => {",
  "const handleSelectPendingNoPesadas = () => {",
  "const handleGeneratePickingReport = async () => {",
  "const handleViewPicking = async () => {",
  "const handleClearOrders = async () => {",
  "const handleCloseAndPrintSingleOrder = async (order: any) => {",
  "const handleForceClose = async (order: any) => {",
  "const handleRevertToPending = async (order: any) => {",
  "const handleReopenOrder = async (order: any) => {",
  "const handleErrorQuerySubmit = async (e: React.FormEvent) => {",
  "const handleSortOrders = (key: string) => {",
  "const handleToggleOrderSelection = (id: string) => {",
  "const handleSelectAllOrders = () => {",
  "const handleToggleOrderExpand = async (orderId: string, order: any) => {",
  "const handleToggleLineExpand = async (lineId: string, line: any, order: any) => {"
];

funcsToRemove.forEach(funcStart => {
  const startIdx = content.indexOf(funcStart);
  if (startIdx !== -1) {
    let endIdx = content.indexOf("\n  const handle", startIdx + 10);
    if (endIdx === -1) endIdx = content.indexOf("\n  const ", startIdx + 10);
    if (endIdx === -1) endIdx = content.indexOf("\n  //", startIdx + 10);
    if (endIdx !== -1) {
      content = content.substring(0, startIdx) + content.substring(endIdx);
    }
  }
});

fs.writeFileSync('App.tsx', content);
console.log('Cleaned App.tsx');
