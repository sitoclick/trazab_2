const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

// Remove handleDeleteAgente
const handleDeleteAgenteStart = "const handleDeleteAgente = async (id: number) => {";
const handleDeleteAgenteEnd = "const updatePvpTarifaPrices = async (tarifaId: number) => {";
const startIdx1 = content.indexOf(handleDeleteAgenteStart);
const endIdx1 = content.indexOf(handleDeleteAgenteEnd);
if (startIdx1 !== -1 && endIdx1 !== -1) {
  content = content.substring(0, startIdx1) + content.substring(endIdx1);
}

// Remove commission functions
const handleRemoveInvoiceStart = "const handleRemoveInvoiceFromCommissions = async (invoiceId: string) => {";
const handleRemoveInvoiceEnd = "const handleLoadTarifas = async () => {";
const startIdx2 = content.indexOf(handleRemoveInvoiceStart);
const endIdx2 = content.indexOf(handleRemoveInvoiceEnd);
if (startIdx2 !== -1 && endIdx2 !== -1) {
  content = content.substring(0, startIdx2) + content.substring(endIdx2);
}

// Remove useEffects
const useEffectStart1 = "useEffect(() => {\n    fetch('/api/agentes')";
const useEffectEnd1 = "useEffect(() => {\n    fetch('/api/tarifas')";
const startIdx3 = content.indexOf(useEffectStart1);
const endIdx3 = content.indexOf(useEffectEnd1);
if (startIdx3 !== -1 && endIdx3 !== -1) {
  content = content.substring(0, startIdx3) + content.substring(endIdx3);
}

const useEffectStart2 = "useEffect(() => {\n    if (showCommissionsReport";
const useEffectEnd2 = "useEffect(() => {\n    if (activeTab === 'traceability') {";
const startIdx4 = content.indexOf(useEffectStart2);
const endIdx4 = content.indexOf(useEffectEnd2);
if (startIdx4 !== -1 && endIdx4 !== -1) {
  content = content.substring(0, startIdx4) + content.substring(endIdx4);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully removed more functions');
