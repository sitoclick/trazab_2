const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');
const lines = content.split('\n');

// Remove lines 1064 to 1632 (0-indexed: 1063 to 1631)
const newLines = [...lines.slice(0, 1064), ...lines.slice(1632)];

fs.writeFileSync('App.tsx', newLines.join('\n'));
console.log('Successfully removed duplicate block 3');
