import http from 'http';

http.get('http://localhost:3000/api/holded/products', (res) => {
  let data = '';
  res.on('data', (chunk) => data += chunk);
  res.on('end', () => {
    try {
      const products = JSON.parse(data);
      console.log(`Total products: ${products.length}`);
      const sample = products.find((p: any) => p.name && p.name.includes('PALETA DE BELLOTA 100% IBÉRICA DESHUESADA'));
      if (sample) {
        console.log('Found sample product:');
        console.log('ID:', sample.id);
        console.log('SKU:', sample.sku);
        console.log('Name:', sample.name);
        console.log('Attributes:', JSON.stringify(sample.attributes, null, 2));
        console.log('Custom Fields:', JSON.stringify(sample.customFields, null, 2));
      } else {
        console.log('Sample product not found.');
      }
    } catch (e) {
      console.error('Parse error:', e);
    }
  });
}).on('error', (err) => {
  console.error('Error:', err.message);
});
