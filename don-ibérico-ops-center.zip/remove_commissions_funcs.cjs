const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const startStr = "const handleRemoveInvoiceFromCommissions = async (invoiceId: string) => {";
const endStr = "const handleLoadHoldedContacts = async () => {";

const startIdx = content.indexOf(startStr);
const endIdx = content.indexOf(endStr);

if (startIdx !== -1 && endIdx !== -1) {
  const newContent = content.substring(0, startIdx) + content.substring(endIdx);
  fs.writeFileSync('App.tsx', newContent);
  console.log('Successfully removed commission functions');
} else {
  console.log('Could not find start or end index');
}
