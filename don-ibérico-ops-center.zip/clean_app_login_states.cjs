const fs = require('fs');

let appContent = fs.readFileSync('App.tsx', 'utf8');

const linesToRemove = [
  "const [usernameInput, setUsernameInput] = useState('');",
  "const [passwordInput, setPasswordInput] = useState('');",
  "const [loginError, setLoginError] = useState(false);",
  "const [isLoading, setIsLoading] = useState(false);"
];

linesToRemove.forEach(line => {
  appContent = appContent.replace(line + "\\n", "");
  appContent = appContent.replace(line, "");
});

fs.writeFileSync('App.tsx', appContent);
console.log('Cleaned up App.tsx login states');
