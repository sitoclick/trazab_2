import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER || 'holded',
  password: process.env.DB_PASSWORD || 'erp1234',
  server: process.env.DB_SERVER || 'sitoclick.ddns.net',
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE || 'CARNICAS',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 30000,
  },
};

async function run() {
  try {
    await sql.connect(dbConfig);
    
    const tarifaResult = await sql.query`SELECT Id FROM Tarifa WHERE Nombre = 'TARIFA DON IBÉRICO ARTESANOS DEL CERDO IBÉRICO, S. L. 2026'`;
    if (tarifaResult.recordset.length === 0) {
        console.error('Tarifa not found');
        return;
    }
    const tId = tarifaResult.recordset[0].Id;

    const prices = [
      { sku: 'U-EM-CH-LONG', price: 4.25 },
      { sku: 'U-EM-CH-LONG-PIC', price: 4.25 }
    ];

    for (const item of prices) {
      await sql.query`
        INSERT INTO PreciosTarifa (TarifaId, ProductoId, PrecioTarifa)
        VALUES (${tId}, ${item.sku}, ${item.price})
      `;
      console.log(`Inserted price for ${item.sku}: ${item.price}`);
    }
    
    console.log('Done!');
  } catch (err) {
    console.error(err);
  } finally {
    await (sql as any).close?.();
  }
}

run();
