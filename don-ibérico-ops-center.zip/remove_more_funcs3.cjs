const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const handleRemoveInvoiceStart = "const handleRemoveInvoiceFromCommissions = async (invoiceId: string) => {";
const handleRemoveInvoiceEnd = "const handleLoadTarifas = async () => {";
const startIdx2 = content.indexOf(handleRemoveInvoiceStart);
const endIdx2 = content.indexOf(handleRemoveInvoiceEnd);
if (startIdx2 !== -1 && endIdx2 !== -1) {
  content = content.substring(0, startIdx2) + content.substring(endIdx2);
}

const useEffectStart2 = "useEffect(() => {\n    if (showCommissionsReport";
const useEffectEnd2 = "useEffect(() => {\n    if (activeTab === 'traceability') {";
const startIdx4 = content.indexOf(useEffectStart2);
const endIdx4 = content.indexOf(useEffectEnd2);
if (startIdx4 !== -1 && endIdx4 !== -1) {
  content = content.substring(0, startIdx4) + content.substring(endIdx4);
}

const fetchAgentsStart = "const fetchAgents = async () => {";
const fetchAgentsEnd = "const fetchCommissionRules = async () => {";
const startIdx5 = content.indexOf(fetchAgentsStart);
const endIdx5 = content.indexOf(fetchAgentsEnd);
if (startIdx5 !== -1 && endIdx5 !== -1) {
  content = content.substring(0, startIdx5) + content.substring(endIdx5);
}

const fetchCommissionRulesStart = "const fetchCommissionRules = async () => {";
const fetchCommissionRulesEnd = "const handleLoadHoldedContacts = async () => {";
const startIdx6 = content.indexOf(fetchCommissionRulesStart);
const endIdx6 = content.indexOf(fetchCommissionRulesEnd);
if (startIdx6 !== -1 && endIdx6 !== -1) {
  content = content.substring(0, startIdx6) + content.substring(endIdx6);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully removed more functions');
