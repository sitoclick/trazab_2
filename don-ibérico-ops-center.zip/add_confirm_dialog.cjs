const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const confirmState = `  const [confirmDialog, setConfirmDialog] = useState<{isOpen: boolean, message: string, onConfirm: () => void}>({isOpen: false, message: '', onConfirm: () => {}});`;

const insertIdx = content.indexOf("  // Holded State");
if (insertIdx !== -1) {
  content = content.substring(0, insertIdx) + confirmState + "\n\n" + content.substring(insertIdx);
}

const confirmUI = `
      {/* Confirm Dialog */}
      {confirmDialog.isOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-red-50/50">
              <div className="flex items-center gap-3">
                <div className="bg-red-100 p-2 rounded-lg text-red-700">
                  <AlertCircle size={20} />
                </div>
                <h3 className="text-lg font-bold text-slate-800">Confirmación</h3>
              </div>
              <button onClick={() => setConfirmDialog({ ...confirmDialog, isOpen: false })} className="text-slate-400 hover:text-slate-600 transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <p className="text-slate-700">{confirmDialog.message}</p>
            </div>
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
              <Button variant="secondary" onClick={() => setConfirmDialog({ ...confirmDialog, isOpen: false })}>
                Cancelar
              </Button>
              <Button onClick={() => {
                confirmDialog.onConfirm();
                setConfirmDialog({ ...confirmDialog, isOpen: false });
              }}>
                Confirmar
              </Button>
            </div>
          </div>
        </div>
      )}
`;

const uiInsertIdx = content.indexOf("      </main>");
if (uiInsertIdx !== -1) {
  content = content.substring(0, uiInsertIdx) + confirmUI + "\n" + content.substring(uiInsertIdx);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully added confirm dialog');
