const fs = require('fs');

let appContent = fs.readFileSync('App.tsx', 'utf8');

const funcsToRemove = [
  "const handleExportExcel = () => {",
  "const handleExportCSV = () => {"
];

funcsToRemove.forEach(funcStart => {
  const startIdx = appContent.indexOf(funcStart);
  if (startIdx !== -1) {
    let endIdx = appContent.indexOf("\n  const handle", startIdx + 10);
    if (endIdx === -1) endIdx = appContent.indexOf("\n  const ", startIdx + 10);
    if (endIdx === -1) endIdx = appContent.indexOf("\n  //", startIdx + 10);
    if (endIdx !== -1) {
      appContent = appContent.substring(0, startIdx) + appContent.substring(endIdx);
    }
  }
});

// Also remove useEffect for errorChat
const useEffectStart = appContent.indexOf("useEffect(() => {\n    if (errorChatEndRef.current) {");
if (useEffectStart !== -1) {
  const useEffectEnd = appContent.indexOf("  }, [errorChat, isErrorChatLoading]);\n") + 39;
  appContent = appContent.substring(0, useEffectStart) + appContent.substring(useEffectEnd);
}

fs.writeFileSync('App.tsx', appContent);
console.log('Cleaned App.tsx');
