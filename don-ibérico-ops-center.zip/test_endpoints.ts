import 'dotenv/config';

async function run() {
  try {
    const endpoints = [
      'http://localhost:3000/api/orders',
      'http://localhost:3000/api/orders/lines?ejercicioPedido=2026&seriePedido=P26&numeroPedido=175',
      'http://localhost:3000/api/pesadas?ejercicioPedido=2026&seriePedido=P26&numeroPedido=175',
      'http://localhost:3000/api/products'
    ];

    for (const url of endpoints) {
      console.log(`Testing ${url}...`);
      const res = await fetch(url);
      if (!res.ok) {
        console.error(`Error ${res.status}: ${await res.text()}`);
      } else {
        const data = await res.json();
        console.log(`Success, got ${Array.isArray(data) ? data.length : 'an object'} items.`);
      }
    }
  } catch (err) {
    console.error(err);
  }
}

run();
