import 'dotenv/config';

async function run() {
  try {
    const res = await fetch('http://localhost:3000/api/orders/lines?ejercicioPedido=2026&seriePedido=P26&numeroPedido=175');
    const data = await res.json();
    console.log(data);
  } catch (err) {
    console.error(err);
  }
}

run();
