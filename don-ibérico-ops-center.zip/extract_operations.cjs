const fs = require('fs');

let appContent = fs.readFileSync('App.tsx', 'utf8');

// We will extract Operations to src/components/Operations/Operations.tsx
const operationsDir = 'src/components/Operations';
if (!fs.existsSync(operationsDir)) {
  fs.mkdirSync(operationsDir);
}

// 1. Find the JSX block for Operations
const jsxStartStr = "{activeTab === 'operations' && user?.role !== 'Ventas' && (";
const jsxEndStr = "{activeTab === 'traceability' && user?.role !== 'Ventas' && (";

const jsxStartIdx = appContent.indexOf(jsxStartStr);
const jsxEndIdx = appContent.indexOf(jsxEndStr);

if (jsxStartIdx === -1 || jsxEndIdx === -1) {
  console.error("Could not find JSX boundaries");
  process.exit(1);
}

let operationsJsx = appContent.substring(jsxStartIdx + jsxStartStr.length, jsxEndIdx).trim();
// Remove the trailing ")}"
if (operationsJsx.endsWith(")}")) {
  operationsJsx = operationsJsx.substring(0, operationsJsx.length - 2).trim();
}

// 2. Find states to extract
const statesToExtract = [
  "const [errorQueryInput, setErrorQueryInput] = useState('');",
  "const [errorChat, setErrorChat] = useState<{sender: 'user'|'bot', text: string}[]>([]);",
  "const [isErrorChatLoading, setIsErrorChatLoading] = useState(false);",
  "const errorChatEndRef = useRef<HTMLDivElement>(null);",
  "const [simpleQueryData, setSimpleQueryData] = useState<any[]>([]);",
  "const [simpleQueryLoading, setSimpleQueryLoading] = useState(false);",
  "const [simpleQueryError, setSimpleQueryError] = useState<string | null>(null);",
  "const [depcPedido, setDepcPedido] = useState('');",
  "const [depcAlbaran, setDepcAlbaran] = useState('');",
  "const [isGeneratingDEPC, setIsGeneratingDEPC] = useState(false);",
  "const [depcError, setDepcError] = useState<string | null>(null);",
  "const [corregirLote, setCorregirLote] = useState('');",
  "const [corregirTipo, setCorregirTipo] = useState('Jamon');",
  "const [corregirPrecinto, setCorregirPrecinto] = useState('');",
  "const [isCorrigiendoPrecinto, setIsCorrigiendoPrecinto] = useState(false);",
  "const [corregirPrecintoMessage, setCorregirPrecintoMessage] = useState<{type: 'success'|'error', text: string} | null>(null);",
  "const [isClearingOrders, setIsClearingOrders] = useState(false);",
  "const [isPickingReportLoading, setIsPickingReportLoading] = useState(false);",
  "const [isPickingSectionOpen, setIsPickingSectionOpen] = useState(false);",
  "const [showPickingPreview, setShowPickingPreview] = useState(false);",
  "const [pickingPreviewData, setPickingPreviewData] = useState<{ enteros: any[], resto: any[] } | null>(null);",
  "const [expandedPickingOrders, setExpandedPickingOrders] = useState<string[]>([]);",
  "const [clearOrdersMessage, setClearOrdersMessage] = useState<{type: 'success'|'error', text: string} | null>(null);",
  "const [pendingOrders, setPendingOrders] = useState<any[]>([]);",
  "const [selectedOrders, setSelectedOrders] = useState<string[]>([]);",
  "const [isLoadingPendingOrders, setIsLoadingPendingOrders] = useState(false);",
  "const [showPendingOrders, setShowPendingOrders] = useState(false);",
  "const [ordersMode, setOrdersMode] = useState<'pending' | 'sent' | 'reservas'>('pending');",
  "const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());",
  "const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);",
  "const [pendingOrdersFilters, setPendingOrdersFilters] = useState({",
  "const [expandedOrders, setExpandedOrders] = useState<string[]>([]);",
  "const [orderLines, setOrderLines] = useState<Record<string, any[]>>({});",
  "const [isLoadingLines, setIsLoadingLines] = useState<Record<string, boolean>>({});",
  "const [expandedLines, setExpandedLines] = useState<string[]>([]);",
  "const [linePesadas, setLinePesadas] = useState<Record<string, any[]>>({});",
  "const [isLoadingLinePesadas, setIsLoadingLinePesadas] = useState<Record<string, boolean>>({});",
  "const [showAsiciForm, setShowAsiciForm] = useState(false);",
  "const [asiciCliente, setAsiciCliente] = useState('B75954792');",
  "const [asiciFechaDesde, setAsiciFechaDesde] = useState('2026-01-03');",
  "const [asiciFechaHasta, setAsiciFechaHasta] = useState('2026-01-20');",
  "const [showCalicerForm, setShowCalicerForm] = useState(false);",
  "const [calicerYear, setCalicerYear] = useState('2026');",
  "const [showPesadasForm, setShowPesadasForm] = useState(false);",
  "const [pesadasEjercicio, setPesadasEjercicio] = useState('2026');",
  "const [pesadasSerie, setPesadasSerie] = useState('ATR26');",
  "const [pesadasNumero, setPesadasNumero] = useState('3');"
];

// 3. Find functions to extract
const funcsToExtract = [
  "const handleRunPesadasQuery = async (e?: React.FormEvent) => {",
  "const handleRunCalicerQuery = async (e?: React.FormEvent) => {",
  "const handleRunAsiciQuery = async (e?: React.FormEvent) => {",
  "const handleGenerateAllAsici = async () => {",
  "const handleLoadPendingOrders = async (mode: 'pending' | 'sent' | 'reservas' = ordersMode) => {",
  "const handleCorregirPrecinto = async () => {",
  "const handleGenerateDEPC = async () => {",
  "const handleSelectPendingNoPesadas = () => {",
  "const handleGeneratePickingReport = async () => {",
  "const handleViewPicking = async () => {",
  "const handleClearOrders = async () => {",
  "const handleCloseAndPrintSingleOrder = async (order: any) => {",
  "const handleForceClose = async (order: any) => {",
  "const handleRevertToPending = async (order: any) => {",
  "const handleReopenOrder = async (order: any) => {",
  "const handleErrorQuerySubmit = async (e: React.FormEvent) => {",
  "const handleSortOrders = (key: string) => {",
  "const handleToggleOrderSelection = (id: string) => {",
  "const handleSelectAllOrders = () => {",
  "const handleToggleOrderExpand = async (orderId: string, order: any) => {",
  "const handleToggleLineExpand = async (lineId: string, line: any, order: any) => {"
];

// Also extract filteredOrders useMemo
const filteredOrdersCode = `
  const filteredOrders = useMemo(() => {
    return pendingOrders.filter(order => {
      const matchContact = (order.RazonSocial || '').toLowerCase().includes(pendingOrdersFilters.contactName.toLowerCase());
      const matchDoc = (order.NumeroPedido?.toString() || '').toLowerCase().includes(pendingOrdersFilters.docNumber.toLowerCase());
      return matchContact && matchDoc;
    });
  }, [pendingOrders, pendingOrdersFilters]);
`;

// Also extract handleSort
const handleSortCode = `
  const handleSort = (key: string) => {
    setSortConfig(prev => {
      if (prev?.key === key) {
        if (prev.direction === 'asc') return { key, direction: 'desc' };
        return null; // Cycle: asc -> desc -> none
      }
      return { key, direction: 'asc' };
    });
  };
`;

// Let's create the Operations.tsx file content
let operationsComponent = `import React, { useState, useRef, useMemo, useEffect } from 'react';
import { 
  Search, FileText, Download, Mail, CheckCircle, 
  Clock, AlertCircle, ChevronDown, ChevronUp, 
  ExternalLink, FileEdit, RefreshCw, Filter,
  ArrowUpDown, ArrowUp, ArrowDown, Play, Printer,
  Trash2, X, Send, Database, MessageSquare, Plus,
  FileSpreadsheet, Settings, Box, Truck
} from 'lucide-react';
import { Button } from '../Button';
import { GoogleGenAI } from "@google/genai";
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import JsBarcode from 'jsbarcode';
import { CALICER_LOGO, FIRMA_LOGO } from '../../assets/images';

const ASICI_CLIENTS = [
  { id: 'A00234567', name: 'Deshuesado en fábrica' },
  { id: 'A01234567', name: 'Loncheado en fábrica' },
  { id: 'B75954792', name: 'MARLON' },
  { id: 'B37310604', name: 'Bernardino Perez' },
  { id: 'B34102012', name: 'Ind. Carnicas Peñafria' },
  { id: 'B37350725', name: 'Jamoneria de la Cruz' },
  { id: 'B37516804', name: 'Jamoneria de la Cruz 2' },
  { id: 'B37568516', name: 'Jamoneria de la Cruz 3' },
  { id: 'B10468940', name: 'Jamoneria de la Cruz 4' },
  { id: 'B37392685', name: 'Jamoneria de la Cruz 5' },
  { id: 'B10492809', name: 'Jamoneria de la Cruz 6' },
  { id: 'B10492817', name: 'Jamoneria de la Cruz 7' },
  { id: 'B10492825', name: 'Jamoneria de la Cruz 8' },
  { id: 'B10492833', name: 'Jamoneria de la Cruz 9' },
  { id: 'B10492841', name: 'Jamoneria de la Cruz 10' },
  { id: 'B10492858', name: 'Jamoneria de la Cruz 11' },
  { id: 'B10492866', name: 'Jamoneria de la Cruz 12' },
  { id: 'B10492874', name: 'Jamoneria de la Cruz 13' },
  { id: 'B10492882', name: 'Jamoneria de la Cruz 14' },
  { id: 'B10492890', name: 'Jamoneria de la Cruz 15' },
  { id: 'B10492908', name: 'Jamoneria de la Cruz 16' }
];

const getBase64ImageFromUrl = async (imageUrl: string): Promise<string> => {
  const res = await fetch(imageUrl);
  if (!res.ok) throw new Error(\`Failed to fetch image: \${res.statusText}\`);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

interface OperationsProps {
  user: any;
  setConfirmDialog: (dialog: {isOpen: boolean, message: string, onConfirm: () => void}) => void;
}

export default function Operations({ user, setConfirmDialog }: OperationsProps) {
`;

// Extract states
statesToExtract.forEach(state => {
  let fullState = state;
  if (state.includes("pendingOrdersFilters")) {
    fullState = `  const [pendingOrdersFilters, setPendingOrdersFilters] = useState({
    contactName: '',
    docNumber: '',
    status: 'all'
  });`;
  }
  operationsComponent += fullState + "\n";
});

operationsComponent += filteredOrdersCode + "\n";
operationsComponent += handleSortCode + "\n";

// Extract functions
funcsToExtract.forEach(funcStart => {
  const startIdx = appContent.indexOf(funcStart);
  if (startIdx !== -1) {
    let endIdx = appContent.indexOf("\n  const handle", startIdx + 10);
    if (endIdx === -1) endIdx = appContent.indexOf("\n  const ", startIdx + 10);
    if (endIdx === -1) endIdx = appContent.indexOf("\n  //", startIdx + 10);
    if (endIdx !== -1) {
      operationsComponent += appContent.substring(startIdx, endIdx) + "\n\n";
    }
  }
});

// Also need to extract handleToggleOrderExpand and handleToggleLineExpand if they exist
const toggleOrderExpandIdx = appContent.indexOf("const handleToggleOrderExpand = async (orderId: string, order: any) => {");
if (toggleOrderExpandIdx !== -1) {
  const endIdx = appContent.indexOf("\n  const handle", toggleOrderExpandIdx + 10);
  operationsComponent += appContent.substring(toggleOrderExpandIdx, endIdx) + "\n\n";
}

const toggleLineExpandIdx = appContent.indexOf("const handleToggleLineExpand = async (lineId: string, line: any, order: any) => {");
if (toggleLineExpandIdx !== -1) {
  const endIdx = appContent.indexOf("\n  const handle", toggleLineExpandIdx + 10);
  operationsComponent += appContent.substring(toggleLineExpandIdx, endIdx) + "\n\n";
}

operationsComponent += `
  return (
    <>
      ${operationsJsx}
    </>
  );
}
`;

fs.writeFileSync(operationsDir + '/Operations.tsx', operationsComponent);
console.log('Created Operations.tsx');

// Now, remove extracted parts from App.tsx
let newAppContent = appContent;

// Replace JSX
newAppContent = newAppContent.substring(0, jsxStartIdx) + 
  "{activeTab === 'operations' && user?.role !== 'Ventas' && (\n          <Operations user={user} setConfirmDialog={setConfirmDialog} />\n        )}\n        " + 
  newAppContent.substring(jsxEndIdx);

// Add import
if (!newAppContent.includes("import Operations from")) {
  newAppContent = newAppContent.replace("import Sales from './src/components/Sales';", "import Sales from './src/components/Sales';\nimport Operations from './src/components/Operations/Operations';");
}

fs.writeFileSync('App.tsx', newAppContent);
console.log('Updated App.tsx');
