const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const handleRemoveInvoiceStart = "const handleRemoveInvoiceFromCommissions = async (invoiceId: string) => {";
const handleRemoveInvoiceEnd = "const handleDownloadInvoicePDF = async (invoiceId: string, docNumber: string) => {";
const startIdx2 = content.indexOf(handleRemoveInvoiceStart);
const endIdx2 = content.indexOf(handleRemoveInvoiceEnd);
if (startIdx2 !== -1 && endIdx2 !== -1) {
  content = content.substring(0, startIdx2) + content.substring(endIdx2);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully removed commission functions');
