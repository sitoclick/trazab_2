const fs = require('fs');

let opsContent = fs.readFileSync('src/components/Operations/Operations.tsx', 'utf8');

// Fix setIsLoadingAction -> setIsLoadingLines
opsContent = opsContent.replace(/setIsLoadingAction/g, "setIsLoadingLines");

// Add missing imports
const importsToAdd = `
import { GoogleGenAI } from '@google/genai';
import { ArrowRightLeft, Loader2, CheckCircle2, Terminal, Bot, Eye } from 'lucide-react';
`;

const importIdx = opsContent.indexOf("import { CALICER_LOGO");
opsContent = opsContent.substring(0, importIdx) + importsToAdd + opsContent.substring(importIdx);

// Add ai initialization
const aiInit = `\nconst ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });\n`;
const compIdx = opsContent.indexOf("export default function Operations");
opsContent = opsContent.substring(0, compIdx) + aiInit + opsContent.substring(compIdx);

// Add missing states and types
const statesToAdd = `
  const [syncStatus, setSyncStatus] = useState<'idle' | 'running' | 'success' | 'error'>('idle');
  const [syncLogs, setSyncLogs] = useState<any[]>([]);

  const handleSync = async () => {
    if (syncStatus === 'running') return;
    setSyncStatus('running');
    setSyncLogs([{ type: 'info', message: 'Iniciando sincronización con Holded...' }]);
    
    try {
      // Simulate sync
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSyncLogs(prev => [...prev, { type: 'success', message: 'Sincronización completada correctamente.' }]);
      setSyncStatus('success');
      setTimeout(() => setSyncStatus('idle'), 3000);
    } catch (error) {
      setSyncLogs(prev => [...prev, { type: 'error', message: 'Error en la sincronización.' }]);
      setSyncStatus('error');
      setTimeout(() => setSyncStatus('idle'), 3000);
    }
  };
`;

const stateInsertIdx = opsContent.indexOf("  const [isPedidosHoldedOpen, setIsPedidosHoldedOpen] = useState(true);");
opsContent = opsContent.substring(0, stateInsertIdx) + statesToAdd + opsContent.substring(stateInsertIdx);

// Fix ConsoleLine component
const consoleLineComp = `
const ConsoleLine = ({ log }: { log: any }) => (
  <div className={\`text-xs font-mono \${log.type === 'error' ? 'text-red-400' : log.type === 'success' ? 'text-green-400' : 'text-slate-300'}\`}>
    > {log.message}
  </div>
);
`;
opsContent = opsContent.substring(0, compIdx) + consoleLineComp + opsContent.substring(compIdx);

fs.writeFileSync('src/components/Operations/Operations.tsx', opsContent);
console.log('Fixed Operations.tsx imports and states');
