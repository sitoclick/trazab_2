const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const oldCode = `      const startTmp = Math.floor(new Date(salesDateRange.start).getTime() / 1000);
      const endTmp = Math.floor(new Date(salesDateRange.end + 'T23:59:59').getTime() / 1000);
      
      const baseUrl = type === 'paid' ? '/api/holded/invoices?paid=1' : '/api/holded/invoices';
      const url = \`\${baseUrl}\${baseUrl.includes('?') ? '&' : '?'}starttmp=\${startTmp}&endtmp=\${endTmp}\`;`;

const newCode = `      const baseUrl = type === 'paid' ? '/api/holded/invoices?paid=1' : '/api/holded/invoices';
      let url = baseUrl;
      if (salesDateRange.start && salesDateRange.end) {
        const startTmp = Math.floor(new Date(salesDateRange.start).getTime() / 1000);
        const endTmp = Math.floor(new Date(salesDateRange.end + 'T23:59:59').getTime() / 1000);
        url = \`\${baseUrl}\${baseUrl.includes('?') ? '&' : '?'}starttmp=\${startTmp}&endtmp=\${endTmp}\`;
      }`;

content = content.replace(oldCode, newCode);
fs.writeFileSync('App.tsx', content);
console.log('Successfully fixed handleLoadHoldedInvoices');
