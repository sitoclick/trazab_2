import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER || 'holded',
  password: process.env.DB_PASSWORD || 'erp1234',
  server: process.env.DB_SERVER || 'sitoclick.ddns.net',
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE || 'CARNICAS',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 30000,
  },
};

async function run() {
  try {
    await sql.connect(dbConfig);
    
    // Update the duplicate entry
    await sql.query`
      UPDATE PreciosTarifa
      SET ProductoId = '000069'
      WHERE TarifaId = 6 AND ProductoId = '011019' AND PrecioTarifa = 37.50
    `;
    
    console.log('Updated duplicate entry 011019 to 000069');
  } catch (err) {
    console.error(err);
  } finally {
    await (sql as any).close?.();
  }
}

run();
