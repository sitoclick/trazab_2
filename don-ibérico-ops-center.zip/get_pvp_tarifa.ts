import sql from 'mssql';

const dbConfig = {
  user: process.env.DB_USER || 'holded',
  password: process.env.DB_PASSWORD || 'erp1234',
  server: process.env.DB_SERVER || 'sitoclick.ddns.net',
  port: parseInt(process.env.DB_PORT || '1433'),
  database: process.env.DB_DATABASE || 'CARNICAS',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 30000,
  },
};

async function run() {
  try {
    await sql.connect(dbConfig);
    const result = await sql.query`SELECT * FROM Tarifa WHERE Nombre LIKE '%PVP%' OR Nombre LIKE '%2026%'`;
    console.log(JSON.stringify(result.recordset, null, 2));
  } catch (err) {
    console.error(err);
  } finally {
    await (sql as any).close?.();
  }
}

run();
