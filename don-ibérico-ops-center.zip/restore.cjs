const { execSync } = require('child_process');
try {
  execSync('git checkout App.tsx src/components/Traceability/Traceability.tsx', { stdio: 'inherit' });
  console.log('Restored');
} catch (e) {
  console.error(e);
}
