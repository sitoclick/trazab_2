const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

// Remove price assistant states
const statesToRemove = [
  "  const [selectedPriceToEdit, setSelectedPriceToEdit] = useState<any>(null);",
  "  const [expandedTarifaId, setExpandedTarifaId] = useState<number | null>(null);",
  "  const [priceAssistantInput, setPriceAssistantInput] = useState('');",
  "  const [priceAssistantMessages, setPriceAssistantMessages] = useState<ChatMessage[]>([",
  "    { id: '1', sender: 'bot', text: 'Hola, soy tu asistente de precios. Puedo ayudarte a modificar las tarifas de forma masiva. Prueba con: \"Sube 0.50€ a todos los jamones en la tarifa Minorista\".', timestamp: new Date() }",
  "  ]);",
  "  const [isPriceAssistantLoading, setIsPriceAssistantLoading] = useState(false);",
  "  const priceAssistantEndRef = useRef<HTMLDivElement>(null);"
];

for (const state of statesToRemove) {
  content = content.replace(state + "\n", "");
}

// Remove handlePriceAssistantSubmit
const funcStart = "const handlePriceAssistantSubmit = async (e: React.FormEvent) => {";
const funcEnd = "const handleLogout = () => {";
const startIdx = content.indexOf(funcStart);
const endIdx = content.indexOf(funcEnd);

if (startIdx !== -1 && endIdx !== -1) {
  content = content.substring(0, startIdx) + content.substring(endIdx);
}

// Remove useEffect for priceAssistantEndRef
const effectStart = "  useEffect(() => {\n    if (priceAssistantEndRef.current) {\n      priceAssistantEndRef.current.scrollIntoView({ behavior: 'smooth' });\n    }\n  }, [priceAssistantMessages]);";
content = content.replace(effectStart + "\n", "");

fs.writeFileSync('App.tsx', content);
console.log('Successfully removed price assistant code');
