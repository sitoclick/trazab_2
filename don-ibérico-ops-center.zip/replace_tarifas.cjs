const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

// Add import
content = content.replace("import Maestros from './src/components/Maestros/Maestros';", "import Maestros from './src/components/Maestros/Maestros';\nimport Tarifas from './src/components/Tarifas/Tarifas';");

// Remove Tarifas state
const stateStart = "  // Tarifas State";
const stateEnd = "  const [showEditPriceModal, setShowEditPriceModal] = useState(false);";
const startIdx1 = content.indexOf(stateStart);
const endIdx1 = content.indexOf(stateEnd);
if (startIdx1 !== -1 && endIdx1 !== -1) {
  content = content.substring(0, startIdx1) + content.substring(endIdx1 + stateEnd.length);
}

// Remove Tarifas functions
const funcStart = "const handleLoadTarifas = async () => {";
const funcEnd = "const importTarifaFromExcel = (e: React.ChangeEvent<HTMLInputElement>, tarifaId: number) => {";
const startIdx2 = content.indexOf(funcStart);
const endIdx2 = content.indexOf(funcEnd);
if (startIdx2 !== -1 && endIdx2 !== -1) {
  // Find the end of importTarifaFromExcel
  const endOfImportFunc = content.indexOf("};", endIdx2) + 2;
  content = content.substring(0, startIdx2) + content.substring(endOfImportFunc);
}

// Remove Tarifas UI
const uiStart = "{activeTab === 'tarifas' && (";
const uiEnd = "{/* Loading Overlay for Product Detail */}";
const startIdx3 = content.indexOf(uiStart);
const endIdx3 = content.indexOf(uiEnd);
if (startIdx3 !== -1 && endIdx3 !== -1) {
  content = content.substring(0, startIdx3) + "{activeTab === 'tarifas' && (\n          <Tarifas user={user} holdedProducts={holdedProducts} handleLoadHoldedProducts={handleLoadHoldedProducts} />\n        )}\n\n        " + content.substring(endIdx3);
}

// Remove Tarifas from useEffect
const useEffectStart = "} else if (activeTab === 'tarifas') {";
const useEffectEnd = "  }, [activeTab, maestrosSubTab, salesSubTab]);";
const startIdx4 = content.indexOf(useEffectStart);
const endIdx4 = content.indexOf(useEffectEnd);
if (startIdx4 !== -1 && endIdx4 !== -1) {
  content = content.substring(0, startIdx4) + content.substring(endIdx4);
}

fs.writeFileSync('App.tsx', content);
console.log('Successfully replaced Tarifas in App.tsx');
