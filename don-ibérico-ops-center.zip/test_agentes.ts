import fetch from 'node-fetch';

async function test() {
  const res = await fetch('http://localhost:3000/api/agentes');
  const data = await res.json();
  console.log(JSON.stringify(data, null, 2));
}

test();
