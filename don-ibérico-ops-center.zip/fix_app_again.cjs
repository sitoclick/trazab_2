const fs = require('fs');

let content = fs.readFileSync('App.tsx', 'utf8');

const filteredOrdersCode = `
  const filteredOrders = useMemo(() => {
    return pendingOrders.filter(order => {
      const matchContact = (order.RazonSocial || '').toLowerCase().includes(pendingOrdersFilters.contactName.toLowerCase());
      const matchDoc = (order.NumeroPedido?.toString() || '').toLowerCase().includes(pendingOrdersFilters.docNumber.toLowerCase());
      return matchContact && matchDoc;
    });
  }, [pendingOrders, pendingOrdersFilters]);
`;

// Remove filteredOrders from its current position
content = content.replace(filteredOrdersCode, "");

// Insert it after pendingOrdersFilters
const insertIdx = content.indexOf("  const [pendingOrdersFilters, setPendingOrdersFilters] = useState({");
if (insertIdx !== -1) {
  const endIdx = content.indexOf("  });", insertIdx) + 5;
  content = content.substring(0, endIdx) + "\n" + filteredOrdersCode + content.substring(endIdx);
}

// Add Sales import
if (!content.includes("import Sales from './components/Sales';")) {
  content = content.replace("import Tarifas from './components/Tarifas';", "import Tarifas from './components/Tarifas';\nimport Sales from './components/Sales';");
}

fs.writeFileSync('App.tsx', content);
console.log('Fixed App.tsx');
