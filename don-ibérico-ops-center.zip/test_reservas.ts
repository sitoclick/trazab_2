import 'dotenv/config';

async function run() {
  try {
    const res = await fetch('http://localhost:3000/api/orders/reservas');
    const data = await res.json();
    console.log(Array.isArray(data) ? `Got ${data.length} reservas` : data);
  } catch (err) {
    console.error(err);
  }
}

run();
