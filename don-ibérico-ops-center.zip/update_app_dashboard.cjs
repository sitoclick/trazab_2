const fs = require('fs');

let appContent = fs.readFileSync('App.tsx', 'utf8');

// Add imports
const importsToAdd = `
import Login from './src/components/Login';
import Dashboard from './src/components/Dashboard';
`;
const importIdx = appContent.indexOf("import Sales");
appContent = appContent.substring(0, importIdx) + importsToAdd + appContent.substring(importIdx);

// Remove handleLogin
const handleLoginStart = appContent.indexOf("const handleLogin = (e: React.FormEvent) => {");
if (handleLoginStart !== -1) {
  const handleLoginEnd = appContent.indexOf("  const handleLogout = () => {");
  appContent = appContent.substring(0, handleLoginStart) + appContent.substring(handleLoginEnd);
}

// Replace Login render
const loginRenderStart = appContent.indexOf("if (!user) {\n    return (");
if (loginRenderStart !== -1) {
  const loginRenderEnd = appContent.indexOf("  // --- Render Dashboard ---");
  const newLoginRender = `if (!user) {
    return <Login onLoginSuccess={(newUser) => {
      setUser(newUser);
      localStorage.setItem('don_iberico_user', JSON.stringify(newUser));
    }} />;
  }\n\n`;
  appContent = appContent.substring(0, loginRenderStart) + newLoginRender + appContent.substring(loginRenderEnd);
}

// Replace Dashboard render
const dashboardRenderStart = appContent.indexOf("{activeTab === 'dashboard' && (");
if (dashboardRenderStart !== -1) {
  const dashboardRenderEnd = appContent.indexOf("          <Sales user={user} setConfirmDialog={setConfirmDialog} />");
  const newDashboardRender = `{activeTab === 'dashboard' && (
          <Dashboard 
            user={user} 
            setActiveTab={setActiveTab} 
            setIsPedidosOnlineOpen={setIsPedidosOnlineOpen} 
          />
        )}\n\n        {activeTab === 'sales' && (\n`;
  appContent = appContent.substring(0, dashboardRenderStart) + newDashboardRender + appContent.substring(dashboardRenderEnd);
}

fs.writeFileSync('App.tsx', appContent);
console.log('Updated App.tsx with Login and Dashboard components');
