const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

// Fix useEffect
content = content.replace(
  "      handleLoadHoldedProducts();\n      }, [activeTab, maestrosSubTab, salesSubTab]);",
  "      handleLoadHoldedProducts();\n    }\n  }, [activeTab, maestrosSubTab, salesSubTab]);"
);

// Fix missing </main>
content = content.replace(
  "    </div>\n  );\n};\n\nexport default App;",
  "      </main>\n    </div>\n  );\n};\n\nexport default App;"
);

fs.writeFileSync('App.tsx', content);
console.log('Successfully fixed syntax errors in App.tsx');
