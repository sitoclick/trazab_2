const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');
const lines = content.split('\n');
// 1062 is index 1061. 1633 is index 1632.
// Let's find the exact end of filteredSalesInvoices
let endIdx = -1;
for (let i = 1566; i < lines.length; i++) {
  if (lines[i].includes("}, [holdedUnpaidInvoices, holdedPaidInvoices, salesSubTab, unpaidInvoicesFilters, holdedContacts, salesSort]);")) {
    endIdx = i;
    break;
  }
}

if (endIdx !== -1) {
  const newLines = [...lines.slice(0, 1061), ...lines.slice(endIdx + 1)];
  fs.writeFileSync('App.tsx', newLines.join('\n'));
  console.log('Successfully removed duplicate block');
} else {
  console.log('Could not find end of filteredSalesInvoices');
}
