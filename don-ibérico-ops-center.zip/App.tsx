import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Terminal, 
  Printer, 
  FileText, 
  Database, 
  Globe, 
  Server, 
  LogOut, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  Package,
  Tag,
  Info,
  ArrowRightLeft,
  Truck,
  Rss,
  User as UserIcon,
  Search,
  Lock,
  Table as TableIcon,
  RefreshCw,
  MessageSquare,
  X,
  Send,
  Bot,
  Download,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Eye,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  RotateCcw,
  Unlock,
  Users,
  Briefcase,
  Percent,
  Plus,
  Trash2,
  CreditCard,
  Edit,
  Edit2,
  List,
  CornerDownRight,
  Upload,
  ShoppingCart,
  Play
} from 'lucide-react';
import { User, SyncStatus, LogEntry, SystemStatus, ProductionRow, ChatMessage, CommissionRule, SqlAgent, MiraviaOrder, MiraviaOrderItem } from './types';
import { Button } from './components/Button';
import PedidosOnline from './components/PedidosOnline/PedidosOnline';
import Traceability from './src/components/Traceability/Traceability';
import Agentes from './src/components/Agentes/Agentes';
import Maestros from './src/components/Maestros/Maestros';
import Tarifas from './src/components/Tarifas/Tarifas';

import Login from './src/components/Login';
import Dashboard from './src/components/Dashboard';
import Sales from './src/components/Sales';
import Operations from './src/components/Operations/Operations';
import { GoogleGenAI } from "@google/genai";
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import JsBarcode from 'jsbarcode';
import { CALICER_LOGO, FIRMA_LOGO } from './assets/images';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

// --- Helper Components ---

const StatusIndicator: React.FC<{ label: string; status: SystemStatus }> = ({ label, status }) => {
  const getColor = (s: SystemStatus) => {
    switch (s) {
      case 'operational': return 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]';
      case 'degraded': return 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]';
      case 'down': return 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]';
    }
  };

  return (
    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
      <span className="text-sm font-medium text-slate-700 flex items-center gap-2">
        {label.includes('Base de Datos SQL') && <Database size={16} />}
        {label.includes('Shopify') && <Globe size={16} />}
        {label.includes('Miravia') && <Globe size={16} />}
        {label.includes('Impresora') && <Printer size={16} />}
        {label}
      </span>
      <div className={`w-3 h-3 rounded-full ${getColor(status)}`} />
    </div>
  );
};

const ConsoleLine: React.FC<{ entry: LogEntry }> = ({ entry }) => (
  <div className="grid grid-cols-12 gap-2 text-[11px] py-2 border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors items-start">
    {/* FECHA */}
    <div className="col-span-2 text-slate-500 font-mono truncate" title={entry.timestamp}>
      {entry.timestamp.split(' ')[1] || entry.timestamp}
    </div>
    
    {/* DOCUMENTO */}
    <div className="col-span-2 text-slate-300 font-medium truncate" title={entry.document}>
      {entry.document}
    </div>

    {/* ACCIÓN */}
    <div className="col-span-2">
      <span className={`uppercase tracking-wider font-bold text-[9px] px-1.5 py-0.5 rounded-sm ${
        entry.type === 'success' ? 'bg-emerald-900/30 text-emerald-400' :
        entry.type === 'warning' ? 'bg-amber-900/30 text-amber-400' :
        entry.type === 'error' ? 'bg-red-900/30 text-red-400' :
        'bg-blue-900/30 text-blue-400'
      }`}>
        {entry.action}
      </span>
    </div>

    {/* DETALLES */}
    <div className={`col-span-6 break-words whitespace-pre-wrap ${
      entry.type === 'error' ? 'text-red-300' : 'text-slate-400'
    }`}>
      {entry.details}
    </div>
  </div>
);

// --- Constants ---
// ID extracted from: https://docs.google.com/spreadsheets/d/1fxlpi44GeAF_PE4Qz2gf8hyD5xBBYZHvFyYnXDQrdzY/edit?usp=sharing
const LOGS_SHEET_ID = '1fxlpi44GeAF_PE4Qz2gf8hyD5xBBYZHvFyYnXDQrdzY'; 
const SYNC_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwN3Kg93Tadoi9x7K4FJbjsEudbCuMhipBMUe1bUDokQyDdlVVjCGcpHgyDegY3QF_-4A/exec';

const getBase64ImageFromUrl = async (imageUrl: string): Promise<string> => {
  const res = await fetch(imageUrl);
  if (!res.ok) throw new Error(`Failed to fetch image: ${res.statusText}`);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// --- Main Application ---

const ASICI_CLIENTS = [
  { id: 'A00234567', name: 'Deshuesado en fábrica' },
  { id: 'A01234567', name: 'Loncheado en fábrica' },
  { id: 'B75954792', name: 'MARLON' },
  { id: 'B37310604', name: 'Bernardino Perez' },
  { id: 'B34102012', name: 'Ind. Carnicas Peñafria' },
  { id: 'A28885614', name: 'Grasas del centro' }
];

const HOLDED_RATES_MAP: Record<string, string> = {
  '670930f499fddeca06016fb1': 'Tarifa Online',
  '670930fd6795bfbe6c0761f0': 'Tarifa HORECA',
  '6958dc33fcb1c7c9990c89a2': 'Tarifa HORECA - CONTADO',
  '6958dc425ca3e8dc7b0ae862': 'Tarifa Distribución - CONTADO',
  '6958dc780ec73400530a0d0b': 'Tarifa Directos'
};

const App: React.FC = () => {
  // Global State
  const [user, setUser] = useState<User | null>(null);
  const isAdminOrAlicia = user?.role === 'Gerente de Operativa' || user?.role === 'Operadora';
  
  
  
  

  // Widget States
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('idle');
  const [syncLogs, setSyncLogs] = useState<LogEntry[]>([]);
  // const consoleEndRef = useRef<HTMLDivElement>(null); // Removed auto-scroll to bottom as we want newest first

  const [orderInput, setOrderInput] = useState('');
  const [adjustmentInputs, setAdjustmentInputs] = useState<Record<string, { desc: string, amount: string }>>({});

  // SQL Query State
  const [sqlData, setSqlData] = useState<ProductionRow[]>([]);
  const [sqlLoading, setSqlLoading] = useState(false);
  const [sqlError, setSqlError] = useState<string | null>(null);

  // Tab State
  const [activeTab, setActiveTab] = useState<'dashboard' | 'operations' | 'traceability' | 'maestros' | 'tarifas' | 'agents' | 'sales' | 'pedidos_online'>('dashboard');
  const [isPedidosHoldedOpen, setIsPedidosHoldedOpen] = useState(true);
  const [isPedidosOnlineOpen, setIsPedidosOnlineOpen] = useState(true);

  const [isHoldedLoading, setIsHoldedLoading] = useState(false);
  const [holdedError, setHoldedError] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{isOpen: boolean, message: string, onConfirm: () => void}>({isOpen: false, message: '', onConfirm: () => {}});


  // Restored States
  const [holdedProducts, setHoldedProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [uniqueCategoria2, setUniqueCategoria2] = useState<string[]>([]);
  const [uniqueFormato, setUniqueFormato] = useState<string[]>([]);
  const [maestrosSubTab, setMaestrosSubTab] = useState<'products' | 'clients'>('products');
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [isProductDetailLoading, setIsProductDetailLoading] = useState(false);

  



        
      
        
          
            
                




  
  const [expandedInvoices, setExpandedInvoices] = useState<string[]>([]);
  const [invoiceDetails, setInvoiceDetails] = useState<Record<string, any>>({});
  const [isLoadingInvoiceDetails, setIsLoadingInvoiceDetails] = useState<Record<string, boolean>>({});
  const [isLoadingAction, setIsLoadingAction] = useState<Record<string, boolean>>({});
  
  const [salesSubTab, setSalesSubTab] = useState<'pending' | 'overdue' | 'paid' | 'all'>('pending');
  const [holdedPaidInvoices, setHoldedPaidInvoices] = useState<any[]>([]);
  const [holdedUnpaidInvoices, setHoldedUnpaidInvoices] = useState<any[]>([]);
  const [holdedContacts, setHoldedContacts] = useState<any[]>([]);
  const [unpaidInvoicesFilters, setUnpaidInvoicesFilters] = useState({
    contactName: '',
    agentName: '',
    docNumber: ''
  });
  const [salesSort, setSalesSort] = useState<{field: string, direction: 'asc' | 'desc'}>({field: 'dueDate', direction: 'asc'});
  const [salesDateRange, setSalesDateRange] = useState({ start: '', end: '' });

  // Order Lines & Pesadas State
            
  // Holded Invoices Details State

  // ASICI Query State
        
  // Calicer Query State
    
  // Pesadas Query State
        
  // Cambiar Pesadas State
  

    
  
  
  const handleLoadHoldedProducts = async () => {
    setIsHoldedLoading(true);
    setHoldedError(null);
    try {
      const response = await fetch('/api/holded/products');
      if (!response.ok) throw new Error('Error al cargar productos de Holded');
      const data = await response.json();
      const products = Array.isArray(data) ? data : [];
      setHoldedProducts(products);
      
      // Filter products: only those with attribute "Categoría" = "Ibéricos"
      const filtered = products.filter((p: any) => {
        if (!p.attributes || !Array.isArray(p.attributes)) return false;
        return p.attributes.some((attr: any) => 
          attr.name === 'Categoría' && attr.value === 'Ibéricos'
        );
      });
      setFilteredProducts(filtered);
      
      // Extract unique "Categoria2" and "Formato" values from filtered products
      const cat2Set = new Set<string>();
      const formatoSet = new Set<string>();
      filtered.forEach((p: any) => {
        if (p.attributes && Array.isArray(p.attributes)) {
          const cat2Attr = p.attributes.find((attr: any) => attr.name === 'Categoria2');
          if (cat2Attr && cat2Attr.value) {
            cat2Set.add(cat2Attr.value);
          }
          const formatoAttr = p.attributes.find((attr: any) => attr.name === 'Formato');
          if (formatoAttr && formatoAttr.value) {
            formatoSet.add(formatoAttr.value);
          }
        }
      });
      setUniqueCategoria2(Array.from(cat2Set).sort());
      setUniqueFormato(Array.from(formatoSet).sort());
      
    } catch (error: any) {
      console.error("Load Holded Products Error:", error);
      setHoldedError(error.message || 'Error al cargar productos');
    } finally {
      setIsHoldedLoading(false);
    }
  };

  const getAgentForInvoice = (inv: any) => {
    // 1. Try to get from invoice customFields (Comisionista)
    if (inv.customFields && Array.isArray(inv.customFields)) {
      const comisionistaField = inv.customFields.find((f: any) => f.field === 'Comisionista' || f.field === 'Agente Comercial');
      if (comisionistaField && comisionistaField.value) {
        return comisionistaField.value;
      }
    }
    
    // 2. Fallback to contact customFields
    const contact = holdedContacts.find(c => c.id === inv.contactId || c.id === inv.contact);
    if (contact && contact.customFields && Array.isArray(contact.customFields)) {
      const agentField = contact.customFields.find((f: any) => f.field === 'Agente Comercial' || f.field === 'Comisionista');
      if (agentField && agentField.value) {
        return agentField.value;
      }
    }
    
    return '-';
  };

  const filteredSalesInvoices = useMemo(() => {
    const now = Math.floor(Date.now() / 1000);
    const invoices = salesSubTab === 'paid' ? holdedPaidInvoices : 
                     salesSubTab === 'all' ? [...holdedPaidInvoices, ...holdedUnpaidInvoices] : 
                     holdedUnpaidInvoices;
    let result = invoices.filter(inv => {
      // Filter out cancelled invoices (status 3 or 4 usually in Holded, or check if it has a specific status)
      // Also, sometimes cancelled invoices have a specific docType or status. Let's filter out status 3 and 4.
      if (inv.status === 3 || inv.status === 4) return false;
      
      const agent = getAgentForInvoice(inv);
      const matchesContact = !unpaidInvoicesFilters.contactName || inv.contactName.toLowerCase().includes(unpaidInvoicesFilters.contactName.toLowerCase());
      const matchesAgent = !unpaidInvoicesFilters.agentName || agent.toLowerCase().includes(unpaidInvoicesFilters.agentName.toLowerCase());
      const matchesDoc = !unpaidInvoicesFilters.docNumber || (inv.docNumber && inv.docNumber.toLowerCase().includes(unpaidInvoicesFilters.docNumber.toLowerCase()));
      
      if (!(matchesContact && matchesAgent && matchesDoc)) return false;

      // Filter by sub-tab logic
      if (salesSubTab === 'paid' || salesSubTab === 'all') return true;
      
      const isOverdue = inv.dueDate && inv.dueDate < now;
      if (salesSubTab === 'overdue') return isOverdue;
      if (salesSubTab === 'pending') return !isOverdue;
      
      return true;
    });

    // Apply sorting
    result.sort((a, b) => {
      let valA: any, valB: any;
      
      switch (salesSort.field) {
        case 'date':
          valA = a.date || 0;
          valB = b.date || 0;
          break;
        case 'dueDate':
          valA = a.dueDate || 0;
          valB = b.dueDate || 0;
          break;
        case 'contact':
          valA = a.contactName || '';
          valB = b.contactName || '';
          break;
        case 'total':
          valA = a.total || 0;
          valB = b.total || 0;
          break;
        case 'pending':
          valA = a.total - (a.amountPaid || 0);
          valB = b.total - (b.amountPaid || 0);
          break;
        default:
          return 0;
      }

      if (valA < valB) return salesSort.direction === 'asc' ? -1 : 1;
      if (valA > valB) return salesSort.direction === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [holdedUnpaidInvoices, holdedPaidInvoices, salesSubTab, unpaidInvoicesFilters, holdedContacts, salesSort]);

  


  


  


  

  const handleDownloadInvoicePDF = async (invoiceId: string, docNumber: string) => {
    try {
      const response = await fetch(`/api/holded/invoices/${invoiceId}/pdf`);
      if (!response.ok) throw new Error('Error al obtener el PDF de Holded');
      const data = await response.json();
      
      // Holded can return { pdf: "base64" } or { url: "..." } or { data: "base64" }
      const pdfContent = data.pdf || data.data;
      const pdfUrl = data.url;

      if (pdfContent) {
        // Create a link and trigger download
        const link = document.createElement('a');
        // Ensure it has the data:application/pdf;base64, prefix if it's just raw base64
        const href = pdfContent.startsWith('data:') ? pdfContent : `data:application/pdf;base64,${pdfContent}`;
        link.href = href;
        link.download = `Factura_${docNumber || invoiceId}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else if (pdfUrl) {
        window.open(pdfUrl, '_blank');
      } else {
        console.error('PDF Response structure:', data);
        throw new Error('No se encontró el contenido del PDF en la respuesta');
      }
    } catch (error: any) {
      console.error('Download PDF Error:', error);
      console.error('Error al descargar el PDF: ' + error.message);
    }
  };

  const handleViewInvoicePDF = async (invoiceId: string, docNumber: string) => {
    try {
      const response = await fetch(`/api/holded/invoices/${invoiceId}/pdf`);
      if (!response.ok) throw new Error('Error al obtener el PDF de Holded');
      const data = await response.json();
      
      const pdfContent = data.pdf || data.data;
      const pdfUrl = data.url;

      if (pdfContent) {
        const base64Data = pdfContent.startsWith('data:') ? pdfContent.split(',')[1] : pdfContent;
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], {type: 'application/pdf'});
        const blobUrl = URL.createObjectURL(blob);
        window.open(blobUrl, '_blank');
      } else if (pdfUrl) {
        window.open(pdfUrl, '_blank');
      } else {
        throw new Error('No se encontró el contenido del PDF en la respuesta');
      }
    } catch (error: any) {
      console.error('View PDF Error:', error);
      console.error('Error al ver el PDF: ' + error.message);
    }
  };

  const toggleInvoiceExpansion = async (invoiceId: string) => {
    const isExpanded = expandedInvoices.includes(invoiceId);
    
    if (isExpanded) {
      setExpandedInvoices(prev => prev.filter(id => id !== invoiceId));
    } else {
      setExpandedInvoices(prev => [...prev, invoiceId]);
      
      if (!invoiceDetails[invoiceId]) {
        setIsLoadingInvoiceDetails(prev => ({ ...prev, [invoiceId]: true }));
        try {
          const response = await fetch(`/api/holded/invoices/${invoiceId}`);
          if (!response.ok) throw new Error('Error al obtener detalles de la factura');
          const data = await response.json();
          setInvoiceDetails(prev => ({ ...prev, [invoiceId]: data }));
        } catch (error: any) {
          console.error('Fetch Invoice Details Error:', error);
        } finally {
          setIsLoadingInvoiceDetails(prev => ({ ...prev, [invoiceId]: false }));
        }
      }
    }
  };

  const handleExportSalesPDF = () => {
    const doc = new jsPDF();
    const title = salesSubTab === 'pending' ? "Facturas Pendientes de Cobro" : salesSubTab === 'overdue' ? "Facturas Impagadas" : "Facturas Pagadas";
    const dateRangeStr = `Desde: ${salesDateRange.start} Hasta: ${salesDateRange.end}`;
    
    doc.setFontSize(18);
    doc.text(title, 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(dateRangeStr, 14, 30);
    doc.text(`Generado el: ${new Date().toLocaleString()}`, 14, 36);
    
    const tableData = filteredSalesInvoices.map(inv => [
      inv.docNumber || inv.id,
      new Date(inv.date * 1000).toLocaleDateString(),
      inv.contactName ? inv.contactName.split('(')[0].trim() : 'Cliente Desconocido',
      getAgentForInvoice(inv),
      new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(inv.total),
      new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(inv.total - (inv.amountPaid || 0)),
      inv.paid === 1 ? 'Pagado' : (inv.dueDate && inv.dueDate < Math.floor(Date.now() / 1000)) ? 'Impagado' : 'Pendiente'
    ]);
    
    autoTable(doc, {
      startY: 45,
      head: [['Factura', 'Fecha', 'Cliente', 'Agente', 'Total', 'Pendiente', 'Estado']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [153, 27, 27] }, // Red-900
      styles: { fontSize: 8 },
      columnStyles: {
        4: { halign: 'right' },
        5: { halign: 'right' },
        6: { halign: 'center' }
      }
    });
    
    doc.save(`${title.replace(/ /g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
  };

    
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('don_iberico_user');
    setSyncLogs([]);
    setSyncStatus('idle');
    setSqlData([]);
  };

  const handleSync = async () => {
    if (syncStatus === 'running') return;

    setSyncStatus('running');
    // Add temporary log at the top
    const now = new Date();
    const timeString = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
    const tempLog: LogEntry = { 
      timestamp: timeString, 
      document: 'SISTEMA', 
      action: 'INICIO', 
      details: 'Solicitando ejecución de script...', 
      type: 'info' 
    };
    
    setSyncLogs(prev => [tempLog, ...prev]);

    try {
      const response = await fetch(`${SYNC_SCRIPT_URL}?accion=sync`, {
        method: 'GET'
      });
      
      const text = await response.text();
      
      const finishTime = new Date();
      const finishTimeString = `${finishTime.getHours()}:${finishTime.getMinutes()}:${finishTime.getSeconds()}`;
      
      const resultLog: LogEntry = {
        timestamp: finishTimeString,
        document: 'SISTEMA',
        action: 'FIN',
        details: text,
        type: 'success'
      };
      
      setSyncLogs(prev => [resultLog, ...prev]);
      setSyncStatus('success');
      
    } catch (error) {
      console.error("Error executing sync script:", error);
      
      const errorTime = new Date();
      const errorTimeString = `${errorTime.getHours()}:${errorTime.getMinutes()}:${errorTime.getSeconds()}`;
      
      const errorLog: LogEntry = {
        timestamp: errorTimeString,
        document: 'SISTEMA',
        action: 'ERROR',
        details: error instanceof Error ? error.message : 'Error desconocido',
        type: 'error'
      };
      
      setSyncLogs(prev => [errorLog, ...prev]);
      setSyncStatus('error');
    }
  };

  const handleRunQuery = async () => {
    setSqlLoading(true);
    setSqlError(null);
    setSqlData([]);

    try {
      const response = await fetch('/api/production', {
        method: 'GET'
      });

      if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
      const data = await response.json();
      
      if (Array.isArray(data)) {
        setSqlData(data);
      } else if (data.error) {
        throw new Error(data.error);
      } else {
        throw new Error('Formato de respuesta desconocido');
      }

    } catch (error: any) {
      console.error("SQL Error:", error);
      setSqlError(error.message || 'Error al conectar con la base de datos');
      if (error.message.includes('Failed to fetch') || error.message.includes('CORS')) {
         setSqlError('Error de conexión con el servidor local.');
      }
    } finally {
      setSqlLoading(false);
    }
  };

  const handlePrint = () => {
    if (!orderInput) {
      console.error('Por favor, introduce un número de pedido o lote.');
      return;
    }
    // Simulate sending to Ngrok
    console.log(`Enviando orden de impresión para el lote/pedido: ${orderInput} al túnel Ngrok.`);
  };

  
  // --- Render Login ---

  if (!user) {
    return <Login onLoginSuccess={(newUser) => {
      setUser(newUser);
      localStorage.setItem('don_iberico_user', JSON.stringify(newUser));
    }} />;
  }

  // --- Render Dashboard ---

  return (
    <div className="min-h-screen bg-slate-50/50">
      
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-4">
              <img 
                src="https://doniberico.net/cdn/shop/files/logodi.png?v=1769436193&width=100" 
                alt="Don Ibérico Logo" 
                className="h-10 object-contain"
              />
              <div className="hidden sm:block w-px h-8 bg-slate-200"></div>
              <div className="hidden sm:block">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest leading-none font-medium block">Torre de Control</span>
                <span className="text-xs font-bold text-slate-800">Operations Center</span>
              </div>
              
              {/* Tab Navigation */}
              <div className="ml-8 flex space-x-4">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'dashboard' 
                      ? 'bg-slate-100 text-slate-900' 
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  Dashboard
                </button>
                {user?.role !== 'Ventas' && (
                  <>
                    <button
                      onClick={() => setActiveTab('operations')}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === 'operations' 
                          ? 'bg-slate-100 text-slate-900' 
                          : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Operativa
                    </button>
                    <button
                      onClick={() => setActiveTab('traceability')}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === 'traceability' 
                          ? 'bg-slate-100 text-slate-900' 
                          : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Trazabilidad
                    </button>
                    <button
                      onClick={() => setActiveTab('maestros')}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === 'maestros' 
                          ? 'bg-slate-100 text-slate-900' 
                          : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Maestros
                    </button>
                  </>
                )}
                <button
                  onClick={() => setActiveTab('agents')}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'agents' 
                      ? 'bg-slate-100 text-slate-900' 
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  Agentes
                </button>
                {user?.role === 'Ventas' && (
                  <button
                    onClick={() => setActiveTab('maestros')}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeTab === 'maestros' 
                        ? 'bg-slate-100 text-slate-900' 
                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    Maestros
                  </button>
                )}
                <button
                  onClick={() => setActiveTab('tarifas')}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'tarifas' 
                      ? 'bg-slate-100 text-slate-900' 
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  Tarifas
                </button>
                <button
                  onClick={() => setActiveTab('sales')}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'sales' 
                      ? 'bg-slate-100 text-slate-900' 
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  Ventas/Cobros
                </button>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden md:flex flex-col items-end mr-2">
                <span className="text-sm font-medium text-slate-900">{user.name}</span>
                <span className="text-xs text-slate-500">{user.role}</span>
              </div>
              <button 
                onClick={handleLogout}
                className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-full transition-colors"
                title="Cerrar Sesión"
              >
                <LogOut size={20} />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-[98%] mx-auto py-8 px-4 sm:px-6 lg:px-8">
        
        {/* Dashboard View */}
        {activeTab === 'dashboard' && (
          <Dashboard 
            user={user} 
            setActiveTab={setActiveTab} 
            setIsPedidosOnlineOpen={setIsPedidosOnlineOpen} 
          />
        )}

        {activeTab === 'sales' && (
          <Sales user={user} setConfirmDialog={setConfirmDialog} />
        )}

        {activeTab === 'operations' && user?.role !== 'Ventas' && (
          <Operations user={user} setConfirmDialog={setConfirmDialog} />
        )}
        {activeTab === 'traceability' && user?.role !== 'Ventas' && (
          <Traceability user={user} setConfirmDialog={setConfirmDialog} />
        )}
        {activeTab === 'agents' && (
          <Agentes user={user} setConfirmDialog={setConfirmDialog} />
        )}

        {activeTab === 'maestros' && (
          <Maestros user={user} />
        )}

        {activeTab === 'tarifas' && (
          <Tarifas user={user} holdedProducts={holdedProducts} handleLoadHoldedProducts={handleLoadHoldedProducts} />
        )}

        {/* Loading Overlay for Product Detail */}
      {isProductDetailLoading && (
        <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-[2px] z-[110] flex items-center justify-center animate-in fade-in duration-200">
          <div className="bg-white p-6 rounded-2xl shadow-xl flex items-center gap-4">
            <Loader2 size={24} className="animate-spin text-red-900" />
            <p className="font-bold text-slate-800">Cargando detalles...</p>
          </div>
        </div>
      )}

      {/* Confirm Dialog */}
      {confirmDialog.isOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-red-50/50">
              <div className="flex items-center gap-3">
                <div className="bg-red-100 p-2 rounded-lg text-red-700">
                  <AlertCircle size={20} />
                </div>
                <h3 className="text-lg font-bold text-slate-800">Confirmación</h3>
              </div>
              <button onClick={() => setConfirmDialog({ ...confirmDialog, isOpen: false })} className="text-slate-400 hover:text-slate-600 transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <p className="text-slate-700">{confirmDialog.message}</p>
            </div>
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
              <Button variant="secondary" onClick={() => setConfirmDialog({ ...confirmDialog, isOpen: false })}>
                Cancelar
              </Button>
              <Button onClick={() => {
                confirmDialog.onConfirm();
                setConfirmDialog({ ...confirmDialog, isOpen: false });
              }}>
                Confirmar
              </Button>
            </div>
          </div>
        </div>
      )}

      </main>
    </div>
  );
};

export default App;