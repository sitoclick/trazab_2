const fs = require('fs');

let appContent = fs.readFileSync('App.tsx', 'utf8');
let traceContent = fs.readFileSync('src/components/Traceability/Traceability.tsx', 'utf8');

// Extract Modals from App.tsx
const modalsStart = appContent.indexOf("{/* Cambiar Pesadas Modal */}");
const modalsEnd = appContent.indexOf("{/* Confirm Dialog */}");

if (modalsStart !== -1 && modalsEnd !== -1) {
  const modalsJsx = appContent.substring(modalsStart, modalsEnd);
  
  // Insert into Traceability.tsx
  const traceInsertIdx = traceContent.lastIndexOf("  );");
  if (traceInsertIdx !== -1) {
    traceContent = traceContent.substring(0, traceInsertIdx) + "\n" + modalsJsx + "\n" + traceContent.substring(traceInsertIdx);
    fs.writeFileSync('src/components/Traceability/Traceability.tsx', traceContent);
    console.log('Added modals to Traceability.tsx');
  }
  
  // Remove from App.tsx
  appContent = appContent.substring(0, modalsStart) + appContent.substring(modalsEnd);
  fs.writeFileSync('App.tsx', appContent);
  console.log('Removed modals from App.tsx');
} else {
  console.log('Modals not found in App.tsx');
}
