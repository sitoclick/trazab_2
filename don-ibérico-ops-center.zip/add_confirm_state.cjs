const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const confirmState = `  const [confirmDialog, setConfirmDialog] = useState<{isOpen: boolean, message: string, onConfirm: () => void}>({isOpen: false, message: '', onConfirm: () => {}});`;

const searchStr = "  const [holdedError, setHoldedError] = useState<string | null>(null);";
const insertIdx = content.indexOf(searchStr);

if (insertIdx !== -1) {
  content = content.substring(0, insertIdx + searchStr.length) + "\n" + confirmState + content.substring(insertIdx + searchStr.length);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully added confirmDialog state');
} else {
  console.log('Could not find insertion point');
}
