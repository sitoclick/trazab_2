const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const startStr = "const handleLoadTarifas = async () => {";
let firstIdx = content.indexOf(startStr);
let secondIdx = content.indexOf(startStr, firstIdx + 1);

if (firstIdx !== -1 && secondIdx !== -1) {
  // Find where the second block ends. Let's say it ends at "const filteredSalesInvoices = useMemo(() => {"
  const endStr = "const filteredSalesInvoices = useMemo(() => {";
  let secondEndIdx = content.indexOf(endStr, secondIdx);
  
  // Actually, let's just find the end of filteredSalesInvoices
  let endOfFilteredSales = content.indexOf("}, [holdedUnpaidInvoices, holdedPaidInvoices, salesSubTab, unpaidInvoicesFilters, holdedContacts, salesSort]);", secondEndIdx);
  
  if (endOfFilteredSales !== -1) {
    const removeEnd = endOfFilteredSales + "}, [holdedUnpaidInvoices, holdedPaidInvoices, salesSubTab, unpaidInvoicesFilters, holdedContacts, salesSort]);".length;
    content = content.substring(0, secondIdx) + content.substring(removeEnd);
    fs.writeFileSync('App.tsx', content);
    console.log('Successfully removed duplicate block');
  } else {
    console.log('Could not find end of filteredSalesInvoices');
  }
} else {
  console.log('Could not find two instances of handleLoadTarifas');
}
