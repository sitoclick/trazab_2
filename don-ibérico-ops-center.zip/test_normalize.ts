const attributes = [
  {
    "id": "67bebd65de7814063204b191",
    "value": "jamón",
    "name": "Categoria2"
  },
  {
    "id": "69584a1dee75978b800c91e1",
    "value": "pieza",
    "name": "Formato"
  }
];

const getNormalizedField = (fields: any[], targetName: string) => {
  if (!fields || !Array.isArray(fields)) return null;
  const field = fields.find((f: any) => {
    const name = (f.field || f.name || '').toLowerCase().replace(/\s+/g, '').normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    return name === targetName;
  });
  return field && field.value ? String(field.value).trim() : null;
};

console.log('Categoria2:', getNormalizedField(attributes, 'categoria2'));
console.log('Formato:', getNormalizedField(attributes, 'formato'));
