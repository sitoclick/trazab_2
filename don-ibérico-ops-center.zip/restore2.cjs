const fs = require('fs');

const traceabilityFile = fs.readFileSync('src/components/Traceability/Traceability.tsx', 'utf-8');
const tLines = traceabilityFile.split('\n');

const states1 = tLines.slice(16, 205);
const states2 = tLines.slice(205, 208).join('\n');
const asiciClients = tLines.slice(208, 213).join('\n');
const handlers = tLines.slice(213, 1097).join('\n');

const appFile = fs.readFileSync('App.tsx', 'utf-8');
const appLines = appFile.split('\n');

// Find where to insert states1
// It was before handleLoadHoldedContacts
const insertIdx1 = appLines.findIndex(l => l.includes('const handleLoadHoldedContacts = async () => {'));

appLines.splice(insertIdx1, 0, ...states1);

// Now find the broken part
const brokenStart = appLines.findIndex(l => l.includes('const handleLoadHoldedInvoices = async (type: \'pending\' | \'overdue\' | \'paid\') => {'));

const dataLineIdx = appLines.findIndex((l, i) => i > brokenStart && l.includes('const data = await response.json();'));
const errorLineIdx = appLines.findIndex((l, i) => i > dataLineIdx && l.includes('console.error("Load Order Lines Error:", error);'));

const newBlock = `${states2}
      
${asiciClients}
      const data = await response.json();
${handlers}`;

appLines.splice(brokenStart + 3, errorLineIdx - (brokenStart + 3), ...newBlock.split('\n'));

fs.writeFileSync('App.tsx', appLines.join('\n'));
console.log('Restored App.tsx');
