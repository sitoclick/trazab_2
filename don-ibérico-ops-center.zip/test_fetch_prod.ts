import 'dotenv/config';

async function run() {
  try {
    const res = await fetch('http://localhost:3000/api/production');
    const data = await res.json();
    console.log(data);
  } catch (err) {
    console.error(err);
  }
}

run();
