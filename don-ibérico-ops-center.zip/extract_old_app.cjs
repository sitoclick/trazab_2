const fs = require('fs');
const files = fs.readdirSync('migrated_prompt_history');
for (const file of files) {
  const content = fs.readFileSync('migrated_prompt_history/' + file, 'utf8');
  try {
    const json = JSON.parse(content);
    if (json.files && json.files['App.tsx']) {
      fs.writeFileSync('App_old_' + file + '.tsx', json.files['App.tsx']);
      console.log('Saved from', file);
    }
  } catch (e) {
    console.log('Error parsing', file);
  }
}
