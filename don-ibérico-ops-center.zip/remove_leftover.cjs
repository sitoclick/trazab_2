const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const leftover = "    reader.readAsBinaryString(file);\n    e.target.value = ''; // Reset input\n  };\n";
content = content.replace(leftover, "");

fs.writeFileSync('App.tsx', content);
console.log('Successfully removed leftover code');
