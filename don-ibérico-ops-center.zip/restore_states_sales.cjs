const fs = require('fs');

let content = fs.readFileSync('App.tsx', 'utf8');

const statesToRestore = `
  const [errorQueryInput, setErrorQueryInput] = useState('');
  const [errorChat, setErrorChat] = useState<{sender: 'user'|'bot', text: string}[]>([]);
  const [isErrorChatLoading, setIsErrorChatLoading] = useState(false);
  const errorChatEndRef = useRef<HTMLDivElement>(null);

  const [simpleQueryData, setSimpleQueryData] = useState<any[]>([]);
  const [simpleQueryLoading, setSimpleQueryLoading] = useState(false);
  const [simpleQueryError, setSimpleQueryError] = useState<string | null>(null);

  const [depcPedido, setDepcPedido] = useState('');
  const [depcAlbaran, setDepcAlbaran] = useState('');
  const [isGeneratingDEPC, setIsGeneratingDEPC] = useState(false);
  const [depcError, setDepcError] = useState<string | null>(null);

  const [corregirLote, setCorregirLote] = useState('');
  const [corregirTipo, setCorregirTipo] = useState('Jamon');
  const [corregirPrecinto, setCorregirPrecinto] = useState('');
  const [isCorrigiendoPrecinto, setIsCorrigiendoPrecinto] = useState(false);
  const [corregirPrecintoMessage, setCorregirPrecintoMessage] = useState<{type: 'success'|'error', text: string} | null>(null);

  const [isClearingOrders, setIsClearingOrders] = useState(false);
  const [isPickingReportLoading, setIsPickingReportLoading] = useState(false);
  const [isPickingSectionOpen, setIsPickingSectionOpen] = useState(false);
  const [showPickingPreview, setShowPickingPreview] = useState(false);
  const [pickingPreviewData, setPickingPreviewData] = useState<{ enteros: any[], resto: any[] } | null>(null);
  const [expandedPickingOrders, setExpandedPickingOrders] = useState<string[]>([]);

  const [clearOrdersMessage, setClearOrdersMessage] = useState<{type: 'success'|'error', text: string} | null>(null);
  const [pendingOrders, setPendingOrders] = useState<any[]>([]);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [isLoadingPendingOrders, setIsLoadingPendingOrders] = useState(false);
  const [showPendingOrders, setShowPendingOrders] = useState(false);
  const [ordersMode, setOrdersMode] = useState<'pending' | 'sent' | 'reservas'>('pending');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);

  const [pendingOrdersFilters, setPendingOrdersFilters] = useState({
    contactName: '',
    docNumber: '',
    status: 'all'
  });
  
  const [expandedInvoices, setExpandedInvoices] = useState<string[]>([]);
  const [invoiceDetails, setInvoiceDetails] = useState<Record<string, any>>({});
  const [isLoadingInvoiceDetails, setIsLoadingInvoiceDetails] = useState<Record<string, boolean>>({});
  const [isLoadingAction, setIsLoadingAction] = useState<Record<string, boolean>>({});
  
  const [salesSubTab, setSalesSubTab] = useState<'pending' | 'overdue' | 'paid' | 'all'>('pending');
  const [holdedPaidInvoices, setHoldedPaidInvoices] = useState<any[]>([]);
  const [holdedUnpaidInvoices, setHoldedUnpaidInvoices] = useState<any[]>([]);
  const [holdedContacts, setHoldedContacts] = useState<any[]>([]);
  const [unpaidInvoicesFilters, setUnpaidInvoicesFilters] = useState({
    contactName: '',
    agentName: '',
    docNumber: ''
  });
  const [salesSort, setSalesSort] = useState<{field: string, direction: 'asc' | 'desc'}>({field: 'dueDate', direction: 'asc'});
  const [salesDateRange, setSalesDateRange] = useState({ start: '', end: '' });
`;

const insertIdx = content.indexOf("  // Order Lines & Pesadas State");
if (insertIdx !== -1) {
  content = content.substring(0, insertIdx) + statesToRestore + "\n" + content.substring(insertIdx);
  fs.writeFileSync('App.tsx', content);
  console.log('Successfully restored states');
} else {
  console.log('Could not find insertion point');
}
